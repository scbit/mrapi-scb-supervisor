const functions = require("@google-cloud/functions-framework");
const express = require("express");
const admin = require("firebase-admin");
const archiver = require("archiver");
const { getFirestore } = require("firebase-admin/firestore");

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: process.env.GOOGLE_CLOUD_PROJECT || "ia-sentire-customs-broker",
  });
}

const app = express();
app.use(express.json({ limit: "4mb" }));

const PROJECT_ID = process.env.GOOGLE_CLOUD_PROJECT || "ia-sentire-customs-broker";
const DB_ID = process.env.FIRESTORE_DB || "bsscb";
const BASIC_USER = process.env.BASIC_USER || "";
const BASIC_PASS = process.env.BASIC_PASS || "";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const SUPERVISOR_REPORTS_BUCKET = process.env.SUPERVISOR_REPORTS_BUCKET || "";

const db = admin.firestore();
db.settings({ databaseId: DB_ID });
const dbCRM = getFirestore(admin.app(), "bscrmscb");

function requireAuth(req, res, next) {
  if (!BASIC_USER || !BASIC_PASS) return next();

  const header = req.headers.authorization || "";
  const expected = "Basic " + Buffer.from(`${BASIC_USER}:${BASIC_PASS}`).toString("base64");

  if (header !== expected) {
    res.set("WWW-Authenticate", 'Basic realm="SCB Supervisor"');
    return res.status(401).send("Unauthorized");
  }

  next();
}

function ts(value) {
  if (!value) return null;
  if (typeof value.toDate === "function") return value.toDate().toISOString();
  if (value._seconds) return new Date(value._seconds * 1000).toISOString();
  if (typeof value === "string") return value;
  return value;
}

function normalizeDirection(value) {
  const v = String(value || "").toUpperCase();
  if (["IN", "INBOUND", "CLIENT", "CLIENTE"].includes(v)) return "inbound";
  if (["OUT", "OUTBOUND", "SELLER", "VENDEDOR", "BOT"].includes(v)) return "outbound";
  return value || null;
}

function detectMessageActor(raw = {}) {
  const direction = normalizeDirection(raw.direction || raw.dir || raw.type || null);
  const joined = [
    raw.direction, raw.dir, raw.type, raw.source, raw.provider, raw.channel,
    raw.user, raw.userEmail, raw.owner, raw.agent, raw.sentBy,
    raw.profileName, raw.createdBy, raw.author, raw.role
  ].map(v => String(v || "").toLowerCase()).join(" ");

  if (direction === "inbound") return "client";

  const hasHumanUser = !!String(raw.user || raw.userEmail || raw.owner || raw.agent || raw.sentBy || raw.profileName || raw.createdBy || raw.author || "").trim();

  // En Bandeja muchos mensajes salientes aparecen como:
  // direction=OUT + type/source=human, pero sin campo user/email.
  // Si no tomamos "human" como señal humana, el reporte diario los cuenta mal
  // como sin respuesta humana.
  if (direction === "outbound" && (
    joined.includes("human-template") ||
    joined.includes("human_template") ||
    joined.includes("manual-template") ||
    joined.includes("manual_template") ||
    joined.includes(" human ") ||
    joined.startsWith("human ") ||
    joined.endsWith(" human") ||
    joined.includes("out human") ||
    joined.includes("whatsapp human") ||
    (joined.includes("template") && hasHumanUser)
  )) {
    return "human";
  }

  if (
    joined.includes("bot") ||
    joined.includes("automation") ||
    joined.includes("automat") ||
    joined.includes("system") ||
    joined.includes("template") ||
    joined.includes("auto")
  ) {
    return "bot";
  }

  if (direction === "outbound" && hasHumanUser) return "human";
  if (direction === "outbound") return "outbound_unknown";

  if (joined.includes("system")) return "system";
  return "unknown";
}

function actorLabel(actor) {
  if (actor === "client") return "CLIENTE";
  if (actor === "bot") return "BOT";
  if (actor === "human") return "VENDEDOR HUMANO";
  if (actor === "system") return "SISTEMA";
  if (actor === "outbound_unknown") return "SALIDA SIN IDENTIFICAR";
  return "DESCONOCIDO";
}

function normalizeConversation(doc) {
  const d = doc.data() || {};

  return {
    id: doc.id,
    contactId: d.contactId || null,
    contactName: d.contactName || d.name || d.customerName || null,
    dealId: d.dealId || null,
    inboundTo: d.inboundTo || null,
    lineId: d.lineId || d.line || d.whatsappLine || null,
    phone: d.phone || d.customerPhone || d.clientPhone || null,
    stage: d.stage || null,
    mode: d.mode || null,
    lastMessagePreview: d.lastMessagePreview || d.lastMessage || d.lastText || null,
    lastMessageAt: ts(d.lastMessageAt || d.updatedAt || d.createdAt),
    lastInboundAt: ts(d.lastInboundAt),
    lastOutboundAt: ts(d.lastOutboundAt),
    leadPlatform: d.leadPlatform || null,
    sourceChannel: d.sourceChannel || null,
    referralHeadline: d.referralHeadline || null,
    owner: d.owner || d.ownerEmail || d.assignedTo || d.seller || null,
    rawKeys: Object.keys(d).slice(0, 50),
  };
}

function normalizeMessage(doc) {
  const d = doc.data() || {};
  const rawDirection = d.direction || d.dir || d.type || null;
  const direction = normalizeDirection(rawDirection);

  return {
    id: doc.id,
    direction,
    actor: detectMessageActor(d),
    rawDirection,
    from: d.from || null,
    to: d.to || null,
    user: d.user || d.userEmail || d.owner || d.agent || d.sentBy || d.profileName || null,
    text: d.text || d.body || d.message || d.content || d.caption || d.fileName || d.filename || d.attachmentName || "",
    timestamp: ts(d.timestamp || d.createdAt || d.date || d.sentAt),
    source: d.source || null,
    media: d.media || d.attachment || d.attachments || d.file || d.fileUrl || d.mediaUrl || d.documentUrl || d.pdfUrl || null,
    hasAttachment: !!(d.media || d.attachment || d.attachments || d.file || d.fileUrl || d.mediaUrl || d.documentUrl || d.pdfUrl || d.filename || d.fileName || d.attachmentName),
    messageSid: d.messageSid || null,
    referralHeadline: d.referralHeadline || null,
    referralBody: d.referralBody || null,
    rawKeys: Object.keys(d).slice(0, 40),
  };
}

async function getRandomConversations(limit = 10) {
  const snap = await db.collection("conversations")
    .orderBy("lastMessageAt", "desc")
    .limit(limit)
    .get();

  return snap.docs.map(normalizeConversation);
}

async function getConversationMessages(conversationId, limit = 80) {
  let snap;

  try {
    snap = await db.collection(`conversations/${conversationId}/messages`)
      .orderBy("timestamp", "asc")
      .limit(limit)
      .get();
  } catch (err) {
    snap = await db.collection(`conversations/${conversationId}/messages`)
      .limit(limit)
      .get();
  }

  const messages = snap.docs.map(normalizeMessage)
    .filter(m => (m.text || "").trim() || m.media || m.direction);

  messages.sort((a, b) => {
    const ta = a.timestamp ? new Date(a.timestamp).getTime() : 0;
    const tb = b.timestamp ? new Date(b.timestamp).getTime() : 0;
    return ta - tb;
  });

  return messages;
}

function transcriptLine(m, i) {
  const who = actorLabel(m.actor || detectMessageActor(m));
  const user = m.actor === "human" && m.user ? ` (${m.user})` : "";
  const when = m.timestamp || "";
  const text = (m.text || "").replace(/\s+/g, " ").trim();

  return `${i + 1}. [${when}] ${who}${user}: ${text}`;
}

function buildTranscript(messages) {
  return messages.map(transcriptLine).join("\n");
}

async function analyzeWithAI(conversation, messages) {
  if (!OPENAI_API_KEY) {
    throw new Error("Falta configurar OPENAI_API_KEY en Cloud Run.");
  }

  const transcript = buildTranscript(messages).slice(0, 20000);

  const prompt = `
Sos supervisor comercial de Sentire Customs Broker / SCB.
Tu tarea es hacer un diagnóstico comercial práctico del chat, separando CLIENTE, BOT y VENDEDOR HUMANO.
No seas alarmista y no evalúes solo si respondió: evaluá si el vendedor realmente vendió de forma consultiva.

Objetivo principal de este análisis:
Detectar si el vendedor indagó el negocio real del cliente o si respondió de forma operativa sin descubrir potencial comercial.
Un cliente puede preguntar por “una caja”, pero en realidad puede ser importador, distribuidor, comercio, fábrica o comprador recurrente con miedo de importar.
El vendedor debe descubrir eso antes de tratarlo como una consulta chica.

Contexto SCB:
- SCB vende servicios de importación, flete marítimo/aéreo/courier, despacho de aduana, consolidación y búsqueda de productos.
- Una buena respuesta no es solo pedir peso, medidas y FOB. También debe descubrir el negocio del cliente.
- Datos operativos importantes: producto, cantidad, origen, destino, medidas/peso, valor FOB, modalidad aérea/marítima/courier, datos de contacto.
- Datos comerciales importantes: si es para uso propio o reventa, si ya importa, si es distribuidor/comercio/fábrica, volumen potencial, frecuencia de compra, miedo u objeción principal, si necesita proveedor, si quiere prueba o compra recurrente.

Evaluá especialmente:
1. Si el bot respondió y si hizo falta intervención humana.
2. Si el vendedor humano respondió con tono profesional, práctico y comercial.
3. Si pidió datos operativos necesarios.
4. Si indagó el negocio real del cliente.
5. Si preguntó si el cliente ya importa o si tiene miedo/objeciones para importar.
6. Si preguntó volumen potencial, recurrencia o si es para reventa/distribución.
7. Si detectó perfil del cliente: importador, distribuidor, comercio, fábrica, consumidor final, desconocido.
8. Si el vendedor trató una oportunidad potencial como una consulta chica.
9. Si hay oportunidad comercial activa y próxima acción concreta.
10. Si hay una respuesta incorrecta, confusa o que conviene revisar.

Criterio comercial:
- Si el vendedor solo pide datos técnicos/operativos y no pregunta nada del negocio, marcá commercial_discovery_level = "bajo" o "nulo".
- Si pregunta para qué lo quiere, si vende, si importa, volumen o recurrencia, marcá nivel medio/alto según profundidad.
- No castigues al vendedor si solo respondió el bot y todavía no intervino humano; en ese caso indicá que falta intervención humana.
- Sé concreto: decí qué pregunta exacta debería haber hecho el vendedor.

Conversación:
ID: ${conversation.id}
Contacto: ${conversation.contactName || "sin nombre"}
Teléfono: ${conversation.phone || "sin teléfono"}
Línea: ${conversation.lineId || conversation.inboundTo || "sin línea"}
Deal: ${conversation.dealId || "sin deal"}
Stage: ${conversation.stage || "sin stage"}
Origen: ${conversation.leadPlatform || conversation.sourceChannel || "sin origen"}
Anuncio: ${conversation.referralHeadline || "sin anuncio"}

TRANSCRIPCIÓN:
${transcript}

Devolvé SOLO JSON válido con esta estructura:
{
  "overall_score": 0-100,
  "result": "bien" | "regular" | "mal",
  "seller_detected": string o null,
  "customer_intent": string,
  "summary": string,
  "good_points": string[],
  "bad_points": string[],
  "missed_opportunities": string[],
  "next_best_reply": string,
  "risk_level": "bajo" | "medio" | "alto",
  "should_alert_owner": boolean,
  "commercial_discovery_level": "alto" | "medio" | "bajo" | "nulo",
  "did_ask_business_context": boolean,
  "did_ask_import_experience": boolean,
  "did_ask_volume_potential": boolean,
  "did_detect_customer_profile": boolean,
  "customer_profile_guess": "importador" | "distribuidor" | "comercio" | "fabrica" | "consumidor_final" | "desconocido",
  "missed_discovery_questions": string[],
  "commercial_risk": "bajo" | "medio" | "alto",
  "sales_coaching": string,
  "operational_without_discovery": boolean,
  "unexplored_potential": boolean
}
`;

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      input: [
        {
          role: "system",
          content: "Respondé únicamente JSON válido. No agregues markdown."
        },
        {
          role: "user",
          content: prompt
        }
      ]
    })
  });

  const raw = await response.text();

  if (!response.ok) {
    throw new Error(`OpenAI error ${response.status}: ${raw}`);
  }

  const data = JSON.parse(raw);
  const outputText =
    data.output_text ||
    data.output?.flatMap(o => o.content || []).find(c => c.type === "output_text")?.text ||
    "";

  if (!outputText) throw new Error("OpenAI no devolvió texto.");

  const cleaned = outputText.replace(/^```json/i, "").replace(/^```/i, "").replace(/```$/i, "").trim();

  return JSON.parse(cleaned);
}

app.get("/", requireAuth, (req, res) => {
  res.set("content-type", "text/html; charset=utf-8");
  res.send(`<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>SCB Supervisor IA</title>
  <style>
    body{font-family:Arial,sans-serif;margin:0;background:#f6f7f9;color:#111}
    .wrap{max-width:1200px;margin:0 auto;padding:24px}
    .card{background:#fff;border-radius:14px;padding:18px;margin:14px 0;box-shadow:0 2px 12px rgba(0,0,0,.08)}
    button{background:#111;color:#fff;border:0;border-radius:10px;padding:12px 16px;cursor:pointer;font-weight:700;margin:4px}
    input{padding:11px;border:1px solid #ddd;border-radius:10px;min-width:500px}
    pre{white-space:pre-wrap;background:#111;color:#0f0;padding:14px;border-radius:10px;overflow:auto;max-height:700px}
    .muted{color:#666}
    .reportBox{white-space:pre-wrap;background:#f8fafc;border:2px solid #111;border-radius:12px;padding:14px;margin:12px 0;font-family:Arial,sans-serif;line-height:1.45}
    .smallBtn{padding:8px 12px;font-size:13px}
    .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>SCB Supervisor IA</h1>
    <p class="muted">Proyecto: ${PROJECT_ID} · Firestore DB: ${DB_ID} · Modelo: ${OPENAI_MODEL}</p>

    <div class="card">
      <h2>Test manual</h2>
      <button onclick="random()">1) Ver últimas conversaciones</button>
      <br><br>
      <input id="cid" placeholder="ID conversación: +5491155955678__+5491139919733"/>
      <button onclick="messages()">2) Ver mensajes</button>
      <button onclick="analyze()">3) Analizar con IA</button>
      <button onclick="analyzeRandom()">Analizar última con mensajes</button>
      <br><br>
      <h3>Análisis día completo + ZIP</h3>
      <div class="row">
        <input id="dayDate" type="date" style="min-width:160px"/>
        <input id="dayLimit" type="number" value="10" min="1" max="50" style="min-width:90px"/>
        <button onclick="previewDayFull()">1) Contar día completo</button>
        <button onclick="analyzePendingDay()">2) Analizar pendientes</button>
        <button onclick="downloadDayZip()">3) Descargar ZIP completo</button>
      </div>
      <p class="muted">No duplica: si un chat ya fue analizado, se saltea y no vuelve a usar OpenAI. El ZIP baja todo lo acumulado del día.</p>

      <br><br>
      <h3>Reporte CRM + Seguimiento filtrado</h3>
      <div class="row">
        <input id="crmAsOfDate" type="date" style="min-width:160px"/>
        <select id="crmOwner" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:300px">
          <option value="">Todos los vendedores</option>
        </select>
        <select id="crmStage" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:260px">
          <option value="">Todos los stages</option>
        </select>
        <input id="crmLimit" type="number" value="30" min="1" max="100" style="min-width:90px"/>
        <button onclick="crmOverdueSummary()">1) Ver vencidos CRM</button>
        <button onclick="analyzeCrmLinkedChats()">2) Analizar chats vinculados</button>
        <button onclick="downloadCrmZip()">3) Descargar ZIP CRM profesional</button>
        <button onclick="loadCrmFilters()">Actualizar filtros</button>
      </div>
      <p class="muted">Los vendedores y stages se cargan automáticamente desde el CRM. Elegí filtros antes de consultar para evitar leer datos de más.</p>

      <br><br>
      <h3>Reporte CRM por movimiento de stage</h3>
      <div class="row">
        <input id="stageReportDate" type="date" style="min-width:160px"/>
        <select id="stageReportStage" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:260px">
          <option value="Horno">Horno</option>
        </select>
        <select id="stageReportOwner" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:300px">
          <option value="">Todos los vendedores</option>
        </select>
        <input id="stageReportLimit" type="number" value="100" min="1" max="300" style="min-width:90px"/>
        <button onclick="crmStageArrivalsReport()">Ver reporte</button>
        <button onclick="downloadCrmStageArrivalsZip()">Descargar ZIP</button>
        <button onclick="crmStageOpportunitiesReport()">Analizar cómo llegaron al Horno</button>
        <button onclick="downloadCrmStageOpportunitiesZip()">Descargar ZIP informe Horno</button>
      </div>
      <p class="muted">Cuenta tratos que hoy están en el stage elegido y fueron actualizados en el día. El informe “Cómo llegaron al Horno” usa IA solo en chats vinculados que no tengan cache previa y arma un ZIP ejecutivo.</p>

      <br><br>
      <h3>Supervisor horario manual</h3>
      <div class="row">
        <input id="hourlyDate" type="date" style="min-width:160px"/>
        <select id="hourlyHour" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:180px">
          <option value="9">09:00 a 10:00</option>
          <option value="10">10:00 a 11:00</option>
          <option value="11">11:00 a 12:00</option>
          <option value="12">12:00 a 13:00</option>
          <option value="13">13:00 a 14:00</option>
          <option value="14">14:00 a 15:00</option>
          <option value="15">15:00 a 16:00</option>
          <option value="16">16:00 a 17:00</option>
        </select>
        <input id="hourlyLateMinutes" type="number" value="30" min="5" max="180" style="min-width:110px"/>
        <input id="hourlyLimit" type="number" value="80" min="1" max="200" style="min-width:90px"/>
        <button onclick="manualHourlySupervisor()">Ejecutar supervisor horario</button>
        <button onclick="downloadManualHourlySupervisorZip()">Descargar ZIP horario</button>
      </div>
      <p class="muted">Manual, sin Cloud Scheduler. Separa cliente, bot y vendedor humano. Calcula quién respondió, quién no, bot-only, demoras y usa IA solo en una muestra limitada de respuestas humanas para detectar respuestas a revisar.</p>

      <br><br>
      <h3>Supervisor diario gerencial</h3>
      <div class="row">
        <input id="dailySupervisorDate" type="date" style="min-width:160px"/>
        <input id="dailyBusinessStartHour" type="number" value="9" min="0" max="23" style="min-width:90px" title="Hora inicio atención"/>
        <input id="dailyBusinessEndHour" type="number" value="17" min="1" max="24" style="min-width:90px" title="Hora fin atención"/>
        <input id="dailySupervisorLateMinutes" type="number" value="30" min="5" max="180" style="min-width:110px"/>
        <input id="dailySupervisorLimit" type="number" value="200" min="1" max="500" style="min-width:90px"/>
      </div>
      <div class="row" style="margin-top:10px;align-items:flex-start">
        <div>
          <div style="font-weight:700;margin:0 0 6px 4px">Usuarios CRM</div>
          <select id="dailySupervisorOwners" multiple size="7" style="padding:10px;border:1px solid #ddd;border-radius:10px;min-width:420px;max-width:620px"></select>
          <div class="muted" style="font-size:12px;margin:5px 0 0 4px">Sin selección = todos. Elegí 1 usuario o varios para armar un grupo.</div>
        </div>
        <div style="padding-top:25px">
          <button class="smallBtn" onclick="selectAllDailySupervisorOwners()">Seleccionar todos</button>
          <button class="smallBtn" onclick="clearDailySupervisorOwners()">Limpiar selección</button>
        </div>
      </div>
      <div class="row" style="margin-top:10px">
        <button onclick="manualDailySupervisor()">Ejecutar supervisor diario</button>
        <button onclick="downloadManualDailySupervisorZip()">Descargar ZIP diario</button>
      </div>
      <p class="muted">Resumen gerencial dentro del horario laboral elegido. Se puede ejecutar para todos, para un usuario CRM individual o para varios usuarios como grupo.</p>

      <div style="margin-top:18px;padding:14px;border:1px solid #ddd;border-radius:12px;background:#fafafa">
        <div style="font-weight:800;margin-bottom:8px">Reportes diarios ya generados</div>
        <div class="row">
          <select id="savedDailyReports" style="padding:11px;border:1px solid #ddd;border-radius:10px;min-width:620px;max-width:850px">
            <option value="">Cargando reportes guardados...</option>
          </select>
          <button class="smallBtn" onclick="loadSavedDailyReports()">Actualizar lista</button>
          <button onclick="openSavedDailyReport()">Abrir reporte guardado</button>
          <button onclick="downloadSavedDailyReportHtml()">Descargar HTML listo para email</button>
        </div>
        <p class="muted" style="margin-bottom:0">Abrir un reporte guardado NO vuelve a leer chats y NO llama a OpenAI. Lee únicamente el reporte ya terminado y sus archivos del bucket.</p>
      </div>

      <br><br>
      <h3>Preguntas abiertas sobre chats del día</h3>
      <div class="row">
        <input id="qaDate" type="date" style="min-width:160px"/>
        <input id="qaLateMinutes" type="number" value="60" min="5" max="1440" style="min-width:120px"/>
      </div>
      <br>
      <textarea id="qaQuestion" placeholder="Ej: mensajes que respondieron tarde / tiempo promedio de respuesta / clientes que están colgados" style="width:100%;min-height:90px;padding:12px;border:1px solid #ddd;border-radius:10px;font-family:Arial"></textarea>
      <br>
      <button onclick="askDayQuestion()">Preguntar sobre el día</button>
      <button onclick="downloadDayQuestionZip()">Descargar ZIP por cliente</button>
      <p class="muted">No usa OpenAI. Calcula métricas reales desde los chats del día: demora de respuesta, promedio y clientes colgados.</p>



    </div>

    <div class="card">
      <h2>Resultado</h2>
      <div id="managerReportBox" class="reportBox" style="display:none;"></div>
      <button id="copyReportBtn" class="smallBtn" style="display:none;" onclick="copyManagerReport()">Copiar reporte</button>
      <pre id="out">Esperando...</pre>
    </div>
  </div>

<script>

function renderManagerReport(data){
  const box = document.getElementById("managerReportBox");
  const btn = document.getElementById("copyReportBtn");

  if (data && data.managerReport) {
    box.style.display = "block";
    btn.style.display = "inline-block";
    box.textContent = data.managerReport;
  } else {
    box.style.display = "none";
    btn.style.display = "none";
    box.textContent = "";
  }
}

function copyManagerReport(){
  const txt = document.getElementById("managerReportBox").textContent || "";
  navigator.clipboard.writeText(txt);
  alert("Reporte copiado");
}

function show(x){
  if (typeof x === "object") renderManagerReport(x);
  document.getElementById("out").textContent = typeof x === "string" ? x : JSON.stringify(x,null,2);
}

async function call(url){
  show("Cargando...");
  const r = await fetch(url);
  const t = await r.text();
  try { show(JSON.parse(t)); } catch(e) { show(t); }
}
async function random(){ await call("/api/manual/random-conversations?limit=10"); }
async function messages(){
  const raw = document.getElementById("cid").value.trim();
  if (!raw) return show("Pegá un ID de conversación.");
  await call("/api/conversation/" + encodeURIComponent(raw) + "/messages?limit=100");
}
async function analyze(){
  const raw = document.getElementById("cid").value.trim();
  if (!raw) return show("Pegá un ID de conversación.");
  await call("/api/conversation/" + encodeURIComponent(raw) + "/analyze?limit=100");
}
async function analyzeRandom(){ await call("/api/manual/analyze-random?limit=100"); }

async function previewDayFull(){
  const date = document.getElementById("dayDate").value;
  if (!date) return show("Elegí una fecha.");
  await call("/api/report/day-status?date=" + encodeURIComponent(date));
}

async function analyzePendingDay(){
  const date = document.getElementById("dayDate").value;
  const limit = document.getElementById("dayLimit").value || "10";
  if (!date) return show("Elegí una fecha.");
  const ok = confirm("Va a analizar hasta " + limit + " chats PENDIENTES del día " + date + ". Los ya analizados NO se vuelven a procesar. ¿Continuar?");
  if (!ok) return;
  await call("/api/report/analyze-pending-day?date=" + encodeURIComponent(date) + "&limit=" + encodeURIComponent(limit));
}

function downloadDayZip(){
  const date = document.getElementById("dayDate").value;
  if (!date) return show("Elegí una fecha.");
  window.open("/api/report/day/" + encodeURIComponent(date) + "/download", "_blank");
}


function escapeHtmlClient(v){
  return String(v == null ? "" : v)
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");
}

async function loadCrmFilters(){
  try {
    const r = await fetch("/api/crm/filters");
    const data = await r.json();

    if (!data.ok) {
      show(data);
      return;
    }

    const ownerSelect = document.getElementById("crmOwner");
    const stageSelect = document.getElementById("crmStage");
    const stageReportOwnerSelect = document.getElementById("stageReportOwner");
    const stageReportStageSelect = document.getElementById("stageReportStage");
    const dailySupervisorOwnersSelect = document.getElementById("dailySupervisorOwners");

    const currentOwner = ownerSelect.value || "";
    const currentStage = stageSelect.value || "";
    const currentStageReportOwner = stageReportOwnerSelect ? (stageReportOwnerSelect.value || "") : "";
    const currentStageReportStage = stageReportStageSelect ? (stageReportStageSelect.value || "Horno") : "Horno";
    const currentDailyOwners = dailySupervisorOwnersSelect ? [...dailySupervisorOwnersSelect.selectedOptions].map(o => o.value) : [];

    const ownerOptions = (data.owners || []).map(o => {
      const value = o.email || o.value || "";
      const label = (o.name ? o.name + " - " : "") + value;
      return '<option value="' + escapeHtmlClient(value) + '">' + escapeHtmlClient(label) + '</option>';
    }).join("");

    const stageOptions = (data.stages || []).map(s => '<option value="' + escapeHtmlClient(s) + '">' + escapeHtmlClient(s) + '</option>').join("");

    ownerSelect.innerHTML = '<option value="">Todos los vendedores</option>' + ownerOptions;
    stageSelect.innerHTML = '<option value="">Todos los stages</option>' + stageOptions;

    if (stageReportOwnerSelect) {
      stageReportOwnerSelect.innerHTML = '<option value="">Todos los vendedores</option>' + ownerOptions;
    }
    if (dailySupervisorOwnersSelect) {
      dailySupervisorOwnersSelect.innerHTML = ownerOptions;
      [...dailySupervisorOwnersSelect.options].forEach(o => { o.selected = currentDailyOwners.includes(o.value); });
    }
    if (stageReportStageSelect) {
      stageReportStageSelect.innerHTML = stageOptions || '<option value="Horno">Horno</option>';
    }

    if ([...ownerSelect.options].some(o => o.value === currentOwner)) ownerSelect.value = currentOwner;
    if ([...stageSelect.options].some(o => o.value === currentStage)) stageSelect.value = currentStage;
    if (stageReportOwnerSelect && [...stageReportOwnerSelect.options].some(o => o.value === currentStageReportOwner)) stageReportOwnerSelect.value = currentStageReportOwner;
    if (stageReportStageSelect && [...stageReportStageSelect.options].some(o => o.value === currentStageReportStage)) stageReportStageSelect.value = currentStageReportStage;
    if (stageReportStageSelect && !stageReportStageSelect.value && [...stageReportStageSelect.options].some(o => o.value === "Horno")) stageReportStageSelect.value = "Horno";
  } catch(e) {
    show("Error cargando filtros CRM: " + e.message);
  }
}

async function crmOverdueSummary(){
  const asOf = document.getElementById("crmAsOfDate").value;
  const limit = document.getElementById("crmLimit").value || "30";
  const owner = document.getElementById("crmOwner").value.trim();
  const stage = document.getElementById("crmStage").value.trim();

  const params = new URLSearchParams();
  params.set("limit", limit);
  if (asOf) params.set("asOf", asOf);
  if (owner) params.set("owner", owner);
  if (stage) params.set("stage", stage);

  await call("/api/crm/overdue-summary?" + params.toString());
}


async function analyzeCrmLinkedChats(){
  const asOf = document.getElementById("crmAsOfDate").value || new Date().toISOString().slice(0,10);
  const limit = document.getElementById("crmLimit").value || "10";
  const owner = document.getElementById("crmOwner").value.trim();
  const stage = document.getElementById("crmStage").value.trim();

  const ok = confirm("Va a buscar tratos vencidos con esos filtros y analizar con IA solo los chats vinculados que no tengan review. ¿Continuar?");
  if (!ok) return;

  const params = new URLSearchParams();
  params.set("asOf", asOf);
  params.set("limit", limit);
  if (owner) params.set("owner", owner);
  if (stage) params.set("stage", stage);

  await call("/api/crm/analyze-linked-chats?" + params.toString());
}

function downloadCrmZip(){
  const asOf = document.getElementById("crmAsOfDate").value || new Date().toISOString().slice(0,10);
  const owner = document.getElementById("crmOwner").value.trim();
  const stage = document.getElementById("crmStage").value.trim();
  const limit = document.getElementById("crmLimit").value || "100";

  const params = new URLSearchParams();
  params.set("asOf", asOf);
  params.set("limit", limit);
  if (owner) params.set("owner", owner);
  if (stage) params.set("stage", stage);

  window.open("/api/crm/overdue-professional-zip?" + params.toString(), "_blank");
}

async function crmStageArrivalsReport(){
  const date = document.getElementById("stageReportDate").value || new Date().toISOString().slice(0,10);
  const stage = document.getElementById("stageReportStage").value.trim() || "Horno";
  const owner = document.getElementById("stageReportOwner").value.trim();
  const limit = document.getElementById("stageReportLimit").value || "100";

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("stage", stage);
  params.set("limit", limit);
  params.set("refresh", "1");
  if (owner) params.set("owner", owner);

  await call("/api/crm/stage-arrivals?" + params.toString());
}

function downloadCrmStageArrivalsZip(){
  const date = document.getElementById("stageReportDate").value || new Date().toISOString().slice(0,10);
  const stage = document.getElementById("stageReportStage").value.trim() || "Horno";
  const owner = document.getElementById("stageReportOwner").value.trim();
  const limit = document.getElementById("stageReportLimit").value || "100";

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("stage", stage);
  params.set("limit", limit);
  if (owner) params.set("owner", owner);

  window.open("/api/crm/stage-arrivals/download?" + params.toString(), "_blank");
}

async function crmStageOpportunitiesReport(){
  const date = document.getElementById("stageReportDate").value || new Date().toISOString().slice(0,10);
  const stage = document.getElementById("stageReportStage").value.trim() || "Horno";
  const owner = document.getElementById("stageReportOwner").value.trim();
  const limit = document.getElementById("stageReportLimit").value || "30";

  const ok = confirm("Va a analizar chats vinculados de los tratos que llegaron al stage seleccionado para explicar cómo llegaron al Horno y detectar posibilidad de cierre. Usa cache si ya existe. ¿Continuar?");
  if (!ok) return;

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("stage", stage);
  params.set("limit", limit);
  params.set("analyze", "1");
  params.set("refresh", "1");
  if (owner) params.set("owner", owner);

  await call("/api/crm/stage-opportunities?" + params.toString());
}

function downloadCrmStageOpportunitiesZip(){
  const date = document.getElementById("stageReportDate").value || new Date().toISOString().slice(0,10);
  const stage = document.getElementById("stageReportStage").value.trim() || "Horno";
  const owner = document.getElementById("stageReportOwner").value.trim();
  const limit = document.getElementById("stageReportLimit").value || "30";

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("stage", stage);
  params.set("limit", limit);
  if (owner) params.set("owner", owner);

  window.open("/api/crm/stage-opportunities/download?" + params.toString(), "_blank");
}

async function manualHourlySupervisor(){
  const date = document.getElementById("hourlyDate").value || new Date().toISOString().slice(0,10);
  const hour = document.getElementById("hourlyHour").value || "9";
  const lateMinutes = document.getElementById("hourlyLateMinutes").value || "30";
  const limit = document.getElementById("hourlyLimit").value || "80";

  const ok = confirm("Va a ejecutar el supervisor horario manual para " + date + " de " + hour + ":00 a " + (Number(hour)+1) + ":00. Puede usar IA solo en respuestas humanas sin cache. ¿Continuar?");
  if (!ok) return;

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("hour", hour);
  params.set("lateMinutes", lateMinutes);
  params.set("limit", limit);
  params.set("analyze", "1");
  params.set("refresh", "1");

  await call("/api/supervisor/hourly-manual?" + params.toString());
}

function downloadManualHourlySupervisorZip(){
  const date = document.getElementById("hourlyDate").value || new Date().toISOString().slice(0,10);
  const hour = document.getElementById("hourlyHour").value || "9";
  const lateMinutes = document.getElementById("hourlyLateMinutes").value || "30";
  const limit = document.getElementById("hourlyLimit").value || "80";

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("hour", hour);
  params.set("lateMinutes", lateMinutes);
  params.set("limit", limit);

  window.open("/api/supervisor/hourly-manual/download?" + params.toString(), "_blank");
}

function getDailySupervisorOwners(){
  const el = document.getElementById("dailySupervisorOwners");
  if (!el) return [];
  return [...el.selectedOptions].map(o => o.value).filter(Boolean);
}

function selectAllDailySupervisorOwners(){
  const el = document.getElementById("dailySupervisorOwners");
  if (!el) return;
  [...el.options].forEach(o => { o.selected = true; });
}

function clearDailySupervisorOwners(){
  const el = document.getElementById("dailySupervisorOwners");
  if (!el) return;
  [...el.options].forEach(o => { o.selected = false; });
}

function appendDailySupervisorOwners(params){
  getDailySupervisorOwners().forEach(owner => params.append("owner", owner));
}

async function manualDailySupervisor(){
  const date = document.getElementById("dailySupervisorDate").value || new Date().toISOString().slice(0,10);
  const startHour = document.getElementById("dailyBusinessStartHour").value || "9";
  const endHour = document.getElementById("dailyBusinessEndHour").value || "17";
  const lateMinutes = document.getElementById("dailySupervisorLateMinutes").value || "30";
  const limit = document.getElementById("dailySupervisorLimit").value || "200";

  const selectedOwners = getDailySupervisorOwners();
  const ownerLabel = selectedOwners.length ? (selectedOwners.length === 1 ? selectedOwners[0] : selectedOwners.length + " usuarios CRM") : "todos los vendedores";
  const ok = confirm("Va a iniciar el supervisor diario en cola para " + date + " · " + ownerLabel + ". Procesará tandas cortas y guardará el avance para evitar que se tilde. ¿Continuar?");
  if (!ok) return;

  const params = new URLSearchParams({ date, businessStartHour:startHour, businessEndHour:endHour, lateMinutes, limit });
  appendDailySupervisorOwners(params);
  show("Iniciando cola del reporte diario...");
  const startResponse = await fetch("/api/supervisor/daily-queue/start?" + params.toString());
  const startData = await startResponse.json();
  if (!startData.ok) return show(startData);

  const jobId = startData.jobId;
  if (startData.status === "completed") {
    show({
      ok: true,
      reused: true,
      status: "completed",
      jobId,
      reportId: startData.reportId || null,
      message: "Este reporte ya estaba generado. Se abrió el guardado sin volver a consultar chats ni usar IA."
    });
    await loadSavedDailyReports(jobId);
    return openSavedDailyReport(jobId);
  }

  let finished = false;
  while (!finished) {
    const processResponse = await fetch("/api/supervisor/daily-queue/process?jobId=" + encodeURIComponent(jobId) + "&batchSize=5");
    const processData = await processResponse.json();
    if (!processData.ok) return show(processData);
    show(processData);
    finished = processData.status === "completed";
  }

  await call("/api/supervisor/daily-queue/status?jobId=" + encodeURIComponent(jobId));
}

function downloadManualDailySupervisorZip(){
  const date = document.getElementById("dailySupervisorDate").value || new Date().toISOString().slice(0,10);
  const startHour = document.getElementById("dailyBusinessStartHour").value || "9";
  const endHour = document.getElementById("dailyBusinessEndHour").value || "17";
  const lateMinutes = document.getElementById("dailySupervisorLateMinutes").value || "30";
  const limit = document.getElementById("dailySupervisorLimit").value || "200";

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("businessStartHour", startHour);
  params.set("businessEndHour", endHour);
  params.set("lateMinutes", lateMinutes);
  params.set("limit", limit);
  appendDailySupervisorOwners(params);

  window.open("/api/supervisor/daily-manual/download?" + params.toString(), "_blank");
}

async function loadSavedDailyReports(selectJobId){
  try {
    const r = await fetch("/api/supervisor/daily-queue/saved-reports?limit=150");
    const data = await r.json();
    const el = document.getElementById("savedDailyReports");
    if (!el) return;
    if (!data.ok) {
      el.innerHTML = '<option value="">Error cargando reportes</option>';
      return;
    }
    const reports = data.reports || [];
    el.innerHTML = '<option value="">Seleccioná un reporte ya generado...</option>' + reports.map(x => {
      const owners = (x.ownerFilters || []);
      const mode = x.filterMode === "all" ? "TODOS" : x.filterMode === "individual" ? (owners[0] || "INDIVIDUAL") : ("GRUPO " + owners.length);
      const sellers = Number(x.sellerCount || 0);
      const included = Number(x.includedCount || 0);
      const label = x.date + " · " + mode + " · " + (x.businessHours || "09:00-17:00") + " · " + included + " chats · " + sellers + " vendedor(es)";
      return '<option value="' + escapeHtmlClient(x.jobId) + '">' + escapeHtmlClient(label) + '</option>';
    }).join("");
    if (selectJobId && [...el.options].some(o => o.value === selectJobId)) el.value = selectJobId;
  } catch(e) {
    const el = document.getElementById("savedDailyReports");
    if (el) el.innerHTML = '<option value="">Error: ' + escapeHtmlClient(e.message) + '</option>';
  }
}

async function openSavedDailyReport(forcedJobId){
  const el = document.getElementById("savedDailyReports");
  const jobId = forcedJobId || (el ? el.value : "");
  if (!jobId) return show("Elegí un reporte guardado.");
  show("Abriendo reporte guardado...");
  const r = await fetch("/api/supervisor/daily-queue/saved-report?jobId=" + encodeURIComponent(jobId));
  const t = await r.text();
  try { show(JSON.parse(t)); } catch(e) { show(t); }
}

function downloadSavedDailyReportHtml(){
  const el = document.getElementById("savedDailyReports");
  const jobId = el ? el.value : "";
  if (!jobId) return show("Elegí un reporte guardado.");
  window.open("/api/supervisor/daily-queue/artifact/download?jobId=" + encodeURIComponent(jobId) + "&type=managerHtml", "_blank");
}

setTimeout(() => { loadCrmFilters(); loadSavedDailyReports(); }, 500);

async function askDayQuestion(){
  const date = document.getElementById("qaDate").value;
  const question = document.getElementById("qaQuestion").value.trim();
  const lateMinutes = document.getElementById("qaLateMinutes").value || "60";

  if (!date) return show("Elegí una fecha.");
  if (!question) return show("Escribí una pregunta.");

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("question", question);
  params.set("lateMinutes", lateMinutes);

  await call("/api/qa/day?" + params.toString());
}

function downloadDayQuestionZip(){
  const date = document.getElementById("qaDate").value;
  const question = document.getElementById("qaQuestion").value.trim();
  const lateMinutes = document.getElementById("qaLateMinutes").value || "60";

  if (!date) return show("Elegí una fecha.");
  if (!question) return show("Escribí una pregunta.");

  const params = new URLSearchParams();
  params.set("date", date);
  params.set("question", question);
  params.set("lateMinutes", lateMinutes);

  window.open("/api/qa/day/download?" + params.toString(), "_blank");
}

</script>
</body>
</html>`);
});

app.get("/health", (req, res) => {
  res.json({
    ok: true,
    service: "supervisor-mensaje-ai-v3",
    projectId: PROJECT_ID,
    firestoreDb: DB_ID,
    target: "helloHttp",
    hasOpenAIKey: !!OPENAI_API_KEY,
    model: OPENAI_MODEL,
    time: new Date().toISOString(),
  });
});

app.get("/api/manual/random-conversations", requireAuth, async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit || 10), 50);
    const conversations = await getRandomConversations(limit);
    res.json({ ok: true, collection: "conversations", count: conversations.length, conversations });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/conversation/:id/messages", requireAuth, async (req, res) => {
  try {
    const id = decodeURIComponent(req.params.id);
    const limit = Math.min(Number(req.query.limit || 100), 200);

    const convDoc = await db.collection("conversations").doc(id).get();
    if (!convDoc.exists) {
      return res.status(404).json({ ok: false, error: "Conversación no encontrada.", id });
    }

    const conversation = normalizeConversation(convDoc);
    const messages = await getConversationMessages(id, limit);

    res.json({
      ok: true,
      conversation,
      messagesPath: `conversations/${id}/messages`,
      messagesCount: messages.length,
      transcript: buildTranscript(messages),
      messages
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/conversation/:id/analyze", requireAuth, async (req, res) => {
  try {
    const id = decodeURIComponent(req.params.id);
    const limit = Math.min(Number(req.query.limit || 100), 200);

    const convDoc = await db.collection("conversations").doc(id).get();
    if (!convDoc.exists) {
      return res.status(404).json({ ok: false, error: "Conversación no encontrada.", id });
    }

    const conversation = normalizeConversation(convDoc);
    const messages = await getConversationMessages(id, limit);

    if (!messages.length) {
      return res.json({
        ok: false,
        error: "No encontré mensajes.",
        conversation,
        messagesPath: `conversations/${id}/messages`
      });
    }

    const aiReview = await analyzeWithAI(conversation, messages);

    res.json({
      ok: true,
      conversation,
      messagesPath: `conversations/${id}/messages`,
      messagesCount: messages.length,
      aiReview,
      transcript: buildTranscript(messages)
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/manual/analyze-random", requireAuth, async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit || 100), 200);
    const conversations = await getRandomConversations(20);

    for (const conversation of conversations) {
      const messages = await getConversationMessages(conversation.id, limit);
      if (messages.length >= 2) {
        const aiReview = await analyzeWithAI(conversation, messages);

        return res.json({
          ok: true,
          conversation,
          messagesPath: `conversations/${conversation.id}/messages`,
          messagesCount: messages.length,
          aiReview,
          transcript: buildTranscript(messages)
        });
      }
    }

    res.json({ ok: false, error: "No encontré conversaciones con mensajes." });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


function fullDayStart(dateStr) {
  return new Date(dateStr + "T00:00:00.000Z");
}

function fullDayEnd(dateStr) {
  return new Date(dateStr + "T23:59:59.999Z");
}

function fullDayReviewDocId(dateStr, conversationId) {
  return dateStr + "__" + String(conversationId || "").replace(/[^a-zA-Z0-9_-]/g, "_");
}

function safeFileName(value) {
  return String(value || "sin_nombre")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9_-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 90) || "sin_nombre";
}

async function getAllConversationsForDay(dateStr, max = 1000) {
  const fromDate = fullDayStart(dateStr);
  const toDate = fullDayEnd(dateStr);

  let snap;
  try {
    snap = await db.collection("conversations")
      .where("lastMessageAt", ">=", fromDate)
      .where("lastMessageAt", "<=", toDate)
      .orderBy("lastMessageAt", "desc")
      .limit(max)
      .get();
  } catch (err) {
    snap = await db.collection("conversations")
      .orderBy("lastMessageAt", "desc")
      .limit(max)
      .get();
  }

  return snap.docs
    .map(normalizeConversation)
    .filter(c => {
      if (!c.lastMessageAt) return false;
      const t = new Date(c.lastMessageAt).getTime();
      return t >= fromDate.getTime() && t <= toDate.getTime();
    });
}

function reviewReason(aiReview) {
  if (!aiReview) return "";
  if (Array.isArray(aiReview.bad_points) && aiReview.bad_points.length) {
    return aiReview.bad_points.slice(0, 2).join(" | ");
  }
  return aiReview.summary || "";
}

function buildFullManagerReport(dateStr, reviewed, totalChats) {
  const bad = reviewed.filter(r => r.result === "mal");
  const regular = reviewed.filter(r => r.result === "regular");
  const good = reviewed.filter(r => r.result === "bien");

  return "📊 Reporte Supervisor SCB\n" +
    "Día: " + dateStr + "\n" +
    "Chats del día: " + totalChats + "\n" +
    "Chats analizados acumulados: " + reviewed.length + "\n" +
    "Pendientes: " + Math.max(totalChats - reviewed.length, 0) + "\n\n" +
    "🔴 Malos: " + bad.length + "\n" +
    "🟡 Regulares: " + regular.length + "\n" +
    "🟢 Buenos: " + good.length + "\n\n" +
    bad.concat(regular).slice(0, 80).map((r, i) => {
      return (i + 1) + ") Chat: " + r.conversationId + "\n" +
        "Cliente: " + (r.contactName || r.phone || "sin dato") + "\n" +
        "Resultado: " + String(r.result || "ERROR").toUpperCase() +
        " · Score: " + (r.score || "-") + "/100" +
        " · Riesgo: " + (r.risk || "-") + "\n" +
        "Motivo: " + (r.reason || r.error || "-") + "\n";
    }).join("\n");
}

async function getCachedReviewsForDay(dateStr) {
  const snap = await db.collection("supervisor_reviews")
    .where("date", "==", dateStr)
    .limit(1000)
    .get();

  const reviews = snap.docs.map(d => d.data() || {});
  reviews.sort((a, b) => {
    const order = { mal: 0, regular: 1, bien: 2 };
    const ro = (order[a.result] ?? 9) - (order[b.result] ?? 9);
    if (ro !== 0) return ro;
    return (new Date(b.lastMessageAt || 0).getTime()) - (new Date(a.lastMessageAt || 0).getTime());
  });
  return reviews;
}

function reviewTxt(r) {
  const ai = r.aiReview || {};
  return [
    "SCB Supervisor IA",
    "=================",
    "",
    "Chat ID: " + (r.conversationId || ""),
    "Cliente: " + (r.contactName || r.phone || "sin dato"),
    "Fecha último mensaje: " + (r.lastMessageAt || ""),
    "Resultado: " + String(r.result || "ERROR").toUpperCase(),
    "Score: " + (r.score || "-") + "/100",
    "Riesgo: " + (r.risk || "-"),
    "",
    "Resumen:",
    ai.summary || r.reason || r.error || "",
    "",
    "Puntos buenos:",
    ...(ai.good_points || []).map(x => "- " + x),
    "",
    "Problemas detectados:",
    ...(ai.bad_points || []).map(x => "- " + x),
    "",
    "Oportunidades perdidas:",
    ...(ai.missed_opportunities || []).map(x => "- " + x),
    "",
    "Respuesta sugerida:",
    ai.next_best_reply || r.nextBestReply || ""
  ].join("\n");
}

function htmlEscape(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function reviewHtml(r) {
  const ai = r.aiReview || {};
  const color = r.result === "bien" ? "#0f9d58" : r.result === "regular" ? "#d49b00" : "#db4437";
  const list = arr => "<ul>" + (arr || []).map(x => "<li>" + htmlEscape(x) + "</li>").join("") + "</ul>";

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Review ${htmlEscape(r.contactName || r.conversationId)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f6f7f9;color:#111;padding:24px}
.card{background:#fff;border:2px solid #111;border-radius:14px;padding:22px;max-width:1100px;margin:auto}
.result{color:${color};font-weight:800;text-transform:uppercase}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}
.reply{border:1px solid #ddd;border-radius:10px;padding:14px;background:#fafafa}
</style>
</head>
<body>
<div class="card">
<h1>Resultado: <span class="result">${htmlEscape(r.result || "error")}</span> · Score ${htmlEscape(r.score || "-")}/100 · Riesgo ${htmlEscape(r.risk || "-")}</h1>
<p><b>Cliente:</b> ${htmlEscape(r.contactName || r.phone || "sin dato")}</p>
<p><b>Chat:</b> ${htmlEscape(r.conversationId || "")}</p>
<p>${htmlEscape(ai.summary || r.reason || r.error || "")}</p>
<div class="grid">
<div><h2>✅ Puntos buenos</h2>${list(ai.good_points)}</div>
<div><h2>⚠️ Problemas detectados</h2>${list(ai.bad_points)}</div>
</div>
<h2>💸 Oportunidades perdidas</h2>
${list(ai.missed_opportunities)}
<h2>💬 Respuesta sugerida</h2>
<div class="reply">${htmlEscape(ai.next_best_reply || r.nextBestReply || "")}</div>
</div>
</body>
</html>`;
}

function summaryHtml(dateStr, totalChats, reviewed, managerReport) {
  const rows = reviewed.map(r => {
    const color = r.result === "bien" ? "#0f9d58" : r.result === "regular" ? "#d49b00" : "#db4437";
    return `<tr>
<td>${htmlEscape(r.contactName || r.phone || "sin dato")}</td>
<td>${htmlEscape(r.conversationId || "")}</td>
<td style="color:${color};font-weight:bold">${htmlEscape(r.result || "error")}</td>
<td>${htmlEscape(r.score || "-")}</td>
<td>${htmlEscape(r.risk || "-")}</td>
<td>${htmlEscape(r.reason || r.error || "")}</td>
</tr>`;
  }).join("");

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Reporte Supervisor SCB ${htmlEscape(dateStr)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f6f7f9;color:#111;padding:24px}
.card{background:#fff;border-radius:14px;padding:22px;box-shadow:0 2px 12px rgba(0,0,0,.08)}
pre{white-space:pre-wrap;background:#111;color:#0f0;padding:14px;border-radius:10px}
table{border-collapse:collapse;width:100%;background:#fff}
td,th{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}
th{background:#f0f0f0}
</style>
</head>
<body>
<div class="card">
<h1>Reporte Supervisor SCB - ${htmlEscape(dateStr)}</h1>
<p><b>Chats del día:</b> ${htmlEscape(totalChats)}</p>
<p><b>Chats analizados:</b> ${htmlEscape(reviewed.length)}</p>
<pre>${htmlEscape(managerReport)}</pre>
<table>
<thead><tr><th>Cliente</th><th>Chat</th><th>Resultado</th><th>Score</th><th>Riesgo</th><th>Motivo</th></tr></thead>
<tbody>${rows}</tbody>
</table>
</div>
</body>
</html>`;
}

app.get("/api/report/day-status", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || "").slice(0, 10);
    if (!date) return res.status(400).json({ ok: false, error: "Falta date" });

    const conversations = await getAllConversationsForDay(date, 1000);
    const cachedReviews = await getCachedReviewsForDay(date);
    const cachedIds = new Set(cachedReviews.map(r => r.conversationId));

    const pending = conversations.filter(c => !cachedIds.has(c.id));

    res.json({
      ok: true,
      mode: "status_only_no_openai",
      date,
      totalChatsInDay: conversations.length,
      alreadyAnalyzed: cachedReviews.length,
      pendingToAnalyze: pending.length,
      note: "No llama a OpenAI. Solo cuenta Firestore y cache.",
      pendingPreview: pending.slice(0, 50).map(c => ({
        conversationId: c.id,
        contactName: c.contactName || null,
        phone: c.phone || null,
        lastMessageAt: c.lastMessageAt || null,
        lineId: c.lineId || c.inboundTo || null
      }))
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/report/analyze-pending-day", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || "").slice(0, 10);
    const limit = Math.min(Number(req.query.limit || 10), 50);
    if (!date) return res.status(400).json({ ok: false, error: "Falta date" });

    const conversations = await getAllConversationsForDay(date, 1000);
    const cachedReviewsBefore = await getCachedReviewsForDay(date);
    const cachedIds = new Set(cachedReviewsBefore.map(r => r.conversationId));
    const pending = conversations.filter(c => !cachedIds.has(c.id)).slice(0, limit);

    const processedNow = [];

    for (const conversation of pending) {
      const reviewId = fullDayReviewDocId(date, conversation.id);
      const reviewRef = db.collection("supervisor_reviews").doc(reviewId);

      try {
        const messages = await getConversationMessages(conversation.id, 100);

        if (!messages || messages.length < 2) {
          const item = {
            ok: false,
            date,
            conversationId: conversation.id,
            contactName: conversation.contactName || null,
            phone: conversation.phone || null,
            lineId: conversation.lineId || conversation.inboundTo || null,
            lastMessageAt: conversation.lastMessageAt || null,
            error: "Sin mensajes suficientes",
            createdAt: admin.firestore.FieldValue.serverTimestamp()
          };
          await reviewRef.set(item, { merge: true });
          processedNow.push(item);
          continue;
        }

        const aiReview = await analyzeWithAI(conversation, messages);

        const item = {
          ok: true,
          date,
          conversationId: conversation.id,
          contactName: conversation.contactName || null,
          phone: conversation.phone || null,
          lineId: conversation.lineId || conversation.inboundTo || null,
          lastMessageAt: conversation.lastMessageAt || null,
          stage: conversation.stage || null,
          sourceChannel: conversation.sourceChannel || conversation.leadPlatform || null,
          result: aiReview.result,
          score: aiReview.overall_score,
          risk: aiReview.risk_level,
          reason: reviewReason(aiReview),
          nextBestReply: aiReview.next_best_reply,
          aiReview,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        };

        await reviewRef.set(item, { merge: true });
        processedNow.push(item);
      } catch (err) {
        const item = {
          ok: false,
          date,
          conversationId: conversation.id,
          contactName: conversation.contactName || null,
          phone: conversation.phone || null,
          lineId: conversation.lineId || conversation.inboundTo || null,
          lastMessageAt: conversation.lastMessageAt || null,
          error: err.message,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        };
        await reviewRef.set(item, { merge: true });
        processedNow.push(item);
      }
    }

    const allReviews = await getCachedReviewsForDay(date);
    const good = allReviews.filter(r => r.result === "bien");
    const regular = allReviews.filter(r => r.result === "regular");
    const bad = allReviews.filter(r => r.result === "mal");
    const managerReport = buildFullManagerReport(date, allReviews, conversations.length);

    await db.collection("supervisor_reports").doc("day__" + date).set({
      ok: true,
      type: "daily",
      date,
      totalChatsInDay: conversations.length,
      analyzedCount: allReviews.length,
      pendingToAnalyze: Math.max(conversations.length - allReviews.length, 0),
      summary: { bad: bad.length, regular: regular.length, good: good.length },
      managerReport,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.json({
      ok: true,
      mode: "analyze_only_pending_no_duplicates",
      date,
      totalChatsInDay: conversations.length,
      processedNow: processedNow.length,
      analyzedAccumulated: allReviews.length,
      pendingToAnalyze: Math.max(conversations.length - allReviews.length, 0),
      summary: { bad: bad.length, regular: regular.length, good: good.length },
      managerReport,
      processedNow,
      reviewedAccumulated: allReviews
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/report/day/:date/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.params.date || "").slice(0, 10);
    if (!date) return res.status(400).send("Falta fecha");

    const conversations = await getAllConversationsForDay(date, 1000);
    const reviewed = await getCachedReviewsForDay(date);

    const managerReport = buildFullManagerReport(date, reviewed, conversations.length);

    await db.collection("supervisor_reports").doc("day__" + date).set({
      ok: true,
      type: "daily",
      date,
      totalChatsInDay: conversations.length,
      analyzedCount: reviewed.length,
      pendingToAnalyze: Math.max(conversations.length - reviewed.length, 0),
      managerReport,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="supervisor-report-${date}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(managerReport, { name: "resumen-general.txt" });
    archive.append(summaryHtml(date, conversations.length, reviewed, managerReport), { name: "resumen-general.html" });
    archive.append(JSON.stringify({ date, totalChatsInDay: conversations.length, analyzedCount: reviewed.length, pendingToAnalyze: Math.max(conversations.length - reviewed.length, 0), managerReport, reviewed }, null, 2), { name: "data.json" });

    reviewed.forEach((r, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      const result = safeFileName(r.result || "error");
      const client = safeFileName(r.contactName || r.phone || r.conversationId || "chat");
      archive.append(reviewTxt(r), { name: `chats/${prefix}_${result}_${client}.txt` });
      archive.append(reviewHtml(r), { name: `chats/${prefix}_${result}_${client}.html` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP: " + err.message);
  }
});


// =====================================================
// CRM OVERDUE REPORT — bscrmscb — OWNER/STAGE FILTERED
// =====================================================

function crmTs(value) {
  if (!value) return null;
  if (typeof value.toDate === "function") return value.toDate().toISOString();
  if (typeof value.toMillis === "function") return new Date(value.toMillis()).toISOString();
  if (value._seconds) return new Date(value._seconds * 1000).toISOString();
  if (value.seconds) return new Date(value.seconds * 1000).toISOString();
  if (typeof value === "number") return new Date(value).toISOString();
  if (typeof value === "string") {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return d.toISOString();
    return value;
  }
  return null;
}

function crmText(data, keys) {
  const d = data || {};
  for (const k of keys) {
    const v = d[k];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
}

function crmNumber(data, keys) {
  const d = data || {};
  for (const k of keys) {
    const n = Number(d[k]);
    if (Number.isFinite(n)) return n;
  }
  return 0;
}

function crmNorm(value) {
  return String(value || "").trim().toLowerCase();
}

function crmNormalizeDeal(doc) {
  const d = doc.data() || {};
  const stage = crmText(d, ["stage", "status", "estado", "pipelineStage"]);
  const dueDate =
    crmTs(d.dueDate) ||
    crmTs(d.nextDueDate) ||
    crmTs(d.fechaVencimiento) ||
    crmTs(d.vencimiento) ||
    crmTs(d.nextFollowUpAt) ||
    crmTs(d.followUpDate);

  const stageLower = crmNorm(stage);
  const isClosed =
    d.isClosed === true ||
    d.closed === true ||
    ["perdido", "descartado", "closed", "won", "lost", "cerrado", "ganado", "ganado courier", "ganado maritimo", "ganado marítimo"].includes(stageLower) ||
    stageLower.startsWith("ganado ");

  return {
    id: doc.id,
    title: crmText(d, ["title", "name", "dealName", "nombre"]) || doc.id,
    contactId: crmText(d, ["contactId", "contact_id"]),
    owner: crmText(d, ["owner", "ownerEmail", "assignedTo", "seller", "vendedor", "responsible"]),
    stage,
    value: crmNumber(d, ["value", "amount", "valor"]),
    dueDate,
    notes: crmText(d, ["notes", "note", "lastNote"]),
    conversationId: crmText(d, ["conversationId", "waConversationId", "chatId", "whatsappConversationId"]),
    updatedAt: crmTs(d.updatedAt || d.lastActivityAt || d.createdAt),
    createdAt: crmTs(d.createdAt),
    isClosed
  };
}

function crmNormalizeContact(doc) {
  if (!doc || !doc.exists) return null;
  const d = doc.data() || {};
  return {
    id: doc.id,
    name: crmText(d, ["name", "contactName", "clientName", "cliente"]) || doc.id,
    company: crmText(d, ["company", "companyName", "empresa"]),
    phone: crmText(d, ["phone", "whatsapp", "mobile", "phoneNumber", "waPhone"]),
    email: crmText(d, ["email", "mail"]),
    owner: crmText(d, ["owner", "ownerName", "ownerDisplayName", "ownerEmail", "assignedTo", "assignedToName", "seller", "sellerName", "vendedor", "responsible"])
  };
}

function crmDaysOverdue(dueIso, asOfDateStr) {
  if (!dueIso) return null;
  const due = new Date(dueIso);
  const asOf = new Date(String(asOfDateStr || new Date().toISOString().slice(0,10)).slice(0,10) + "T23:59:59.999Z");
  const diff = Math.floor((asOf.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}

async function crmGetContact(contactId) {
  const id = String(contactId || "").trim();
  if (!id) return null;
  const doc = await dbCRM.collection("contacts").doc(id).get();
  return crmNormalizeContact(doc);
}

async function crmGetDealNotes(dealId, limit = 5) {
  const id = String(dealId || "").trim();
  if (!id) return [];
  try {
    const snap = await dbCRM.collection("deals").doc(id).collection("notes").orderBy("createdAt", "desc").limit(limit).get();
    return snap.docs.map(doc => {
      const d = doc.data() || {};
      return {
        id: doc.id,
        note: d.note || d.text || d.body || d.content || "",
        user: d.user || d.author || d.userEmail || d.createdBy || "",
        createdAt: crmTs(d.createdAt || d.timestamp || d.date)
      };
    });
  } catch (err) {
    return [];
  }
}

async function crmFindConversationForDeal(deal) {
  if (!deal) return null;

  if (deal.conversationId) {
    const doc = await db.collection("conversations").doc(String(deal.conversationId)).get();
    if (doc.exists) return normalizeConversation(doc);
  }

  if (deal.id) {
    try {
      const snap = await db.collection("conversations").where("dealId", "==", deal.id).limit(1).get();
      if (!snap.empty) return normalizeConversation(snap.docs[0]);
    } catch (err) {}
  }

  if (deal.contactId) {
    try {
      const snap = await db.collection("conversations").where("contactId", "==", deal.contactId).limit(1).get();
      if (!snap.empty) return normalizeConversation(snap.docs[0]);
    } catch (err) {}
  }

  return null;
}

async function crmQueryDealsFiltered(owner, stage) {
  let ref = dbCRM.collection("deals");
  const cleanOwner = String(owner || "").trim();
  const cleanStage = String(stage || "").trim();

  if (cleanOwner) ref = ref.where("owner", "==", cleanOwner);
  if (cleanStage) ref = ref.where("stage", "==", cleanStage);

  const maxRead = cleanOwner || cleanStage ? 1000 : 500;
  const snap = await ref.limit(maxRead).get();
  return snap.docs.map(crmNormalizeDeal);
}

async function crmBuildOverdueData(asOf, limit = 30, filters = {}) {
  const owner = String(filters.owner || "").trim();
  const stage = String(filters.stage || "").trim();
  const allDeals = await crmQueryDealsFiltered(owner, stage);

  const overdue = allDeals
    .filter(d => !d.isClosed && d.dueDate)
    .map(d => ({ ...d, overdueDays: crmDaysOverdue(d.dueDate, asOf) }))
    .filter(d => d.overdueDays && d.overdueDays > 0)
    .sort((a, b) => (b.overdueDays || 0) - (a.overdueDays || 0));

  const selected = overdue.slice(0, limit);

  for (const deal of selected) {
    deal.contact = await crmGetContact(deal.contactId);
    deal.dealNotes = await crmGetDealNotes(deal.id, 5);
    deal.conversation = await crmFindConversationForDeal(deal);
    deal.chatReview = null;

    if (deal.conversation?.id) {
      try {
        const cached = await findCachedReviewForConversation(deal.conversation.id, asOf);
        if (cached) deal.chatReview = cached.data || null;
      } catch (err) {}
    }
  }

  const byOwner = {};
  const byStage = {};
  for (const d of overdue) {
    const o = d.owner || "sin asignar";
    const s = d.stage || "sin stage";
    byOwner[o] = byOwner[o] || { owner: o, overdue: 0, maxDaysOverdue: 0 };
    byStage[s] = byStage[s] || { stage: s, overdue: 0, maxDaysOverdue: 0 };
    byOwner[o].overdue += 1;
    byOwner[o].maxDaysOverdue = Math.max(byOwner[o].maxDaysOverdue, d.overdueDays || 0);
    byStage[s].overdue += 1;
    byStage[s].maxDaysOverdue = Math.max(byStage[s].maxDaysOverdue, d.overdueDays || 0);
  }

  return {
    asOf,
    filters: { owner, stage },
    summary: {
      totalDealsRead: allDeals.length,
      totalOpenWithDueDate: allDeals.filter(d => !d.isClosed && d.dueDate).length,
      totalOverdue: overdue.length,
      overdue_1_7: overdue.filter(d => d.overdueDays >= 1 && d.overdueDays <= 7).length,
      overdue_8_30: overdue.filter(d => d.overdueDays >= 8 && d.overdueDays <= 30).length,
      overdue_30_plus: overdue.filter(d => d.overdueDays > 30).length
    },
    byOwner: Object.values(byOwner).sort((a,b) => b.overdue - a.overdue),
    byStage: Object.values(byStage).sort((a,b) => b.overdue - a.overdue),
    worstOverdue: selected
  };
}

function crmBuildManagerReport(data) {
  const s = data.summary || {};
  const f = data.filters || {};
  const ownerRows = (data.byOwner || []).slice(0,20).map((o,i) => `${i+1}) ${o.owner}: ${o.overdue} vencidos · máximo ${o.maxDaysOverdue} días`).join("\n");
  const stageRows = (data.byStage || []).slice(0,20).map((x,i) => `${i+1}) ${x.stage}: ${x.overdue} vencidos · máximo ${x.maxDaysOverdue} días`).join("\n");

  const dealRows = (data.worstOverdue || []).slice(0,50).map((d,i) => {
    const client = d.contact?.name || d.title || "Sin cliente";
    const notes = Array.isArray(d.dealNotes) && d.dealNotes.length
      ? d.dealNotes.slice(0,3).map(n => `- ${n.createdAt || ""} · ${n.user || "system"}: ${n.note || ""}`).join("\n")
      : (d.notes ? "- " + d.notes : "- Sin notas detectadas");
    const chat = d.conversation?.id || "-";
    const review = d.chatReview ? `Score chat: ${d.chatReview.score || "-"}/100 · ${d.chatReview.result || "-"} · ${d.chatReview.risk || "-"}` : "Score chat: sin análisis IA todavía";
    return `${i+1}) ${client}
Deal: ${d.id}
Trato: ${d.title || "-"}
Responsable: ${d.owner || d.contact?.owner || "sin asignar"}
Stage: ${d.stage || "-"}
Vencido hace: ${d.overdueDays} días
Due date: ${d.dueDate || "-"}
Chat: ${chat}
${review}
Notas:
${notes}
`;
  }).join("\n");

  return `📊 Reporte CRM + Seguimiento SCB
Fecha de corte: ${data.asOf}
Filtro vendedor: ${f.owner || "todos"}
Filtro stage: ${f.stage || "todos"}

Tratos leídos: ${s.totalDealsRead || 0}
Tratos abiertos con vencimiento: ${s.totalOpenWithDueDate || 0}
Tratos vencidos: ${s.totalOverdue || 0}

1 a 7 días: ${s.overdue_1_7 || 0}
8 a 30 días: ${s.overdue_8_30 || 0}
Más de 30 días: ${s.overdue_30_plus || 0}

👥 Vencidos por vendedor:
${ownerRows || "-"}

📌 Vencidos por stage:
${stageRows || "-"}

⚠️ Casos críticos:

${dealRows || "Sin casos críticos"}`;
}

function crmDealTxt(d) {
  const notes = Array.isArray(d.dealNotes) && d.dealNotes.length
    ? d.dealNotes.map(n => `- ${n.createdAt || ""} · ${n.user || "system"}: ${n.note || ""}`).join("\n")
    : (d.notes ? "- " + d.notes : "- Sin notas detectadas");
  return `SCB CRM — Trato vencido
=======================

Cliente: ${d.contact?.name || d.title || "Sin cliente"}
Deal ID: ${d.id}
Trato: ${d.title || "-"}
Owner: ${d.owner || d.contact?.owner || "sin asignar"}
Stage: ${d.stage || "-"}
Valor: ${d.value || 0}
Due date: ${d.dueDate || "-"}
Vencido hace: ${d.overdueDays || "-"} días
Chat vinculado: ${d.conversation?.id || "-"}
Review IA chat: ${d.chatReview ? `${d.chatReview.result || "-"} · Score ${d.chatReview.score || "-"} · Riesgo ${d.chatReview.risk || "-"}` : "sin análisis"}

Notas:
${notes}

JSON:
${JSON.stringify(d, null, 2)}`;
}

function crmSummaryHtml(data, managerReport) {
  const rows = (data.worstOverdue || []).map(d => `<tr>
<td>${htmlEscape(d.contact?.name || d.title || "Sin cliente")}</td>
<td>${htmlEscape(d.title || "-")}</td>
<td>${htmlEscape(d.owner || d.contact?.owner || "sin asignar")}</td>
<td>${htmlEscape(d.stage || "-")}</td>
<td>${htmlEscape(d.overdueDays || "-")}</td>
<td>${htmlEscape(d.conversation?.id || "-")}</td>
<td>${htmlEscape(d.chatReview ? ((d.chatReview.score || "-") + " / " + (d.chatReview.result || "-")) : "sin análisis")}</td>
</tr>`).join("");

  return `<!doctype html><html><head><meta charset="utf-8"/>
<title>Reporte CRM SCB ${htmlEscape(data.asOf)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f6f7f9;color:#111;padding:24px}
.card{background:#fff;border-radius:14px;padding:22px;box-shadow:0 2px 12px rgba(0,0,0,.08)}
pre{white-space:pre-wrap;background:#111;color:#0f0;padding:14px;border-radius:10px}
table{border-collapse:collapse;width:100%;background:#fff}
td,th{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}
th{background:#f0f0f0}
</style></head><body><div class="card">
<h1>Reporte CRM + Seguimiento SCB - ${htmlEscape(data.asOf)}</h1>
<pre>${htmlEscape(managerReport)}</pre>
<table>
<thead><tr><th>Cliente</th><th>Trato</th><th>Owner</th><th>Stage</th><th>Días vencido</th><th>Chat</th><th>Review IA</th></tr></thead>
<tbody>${rows}</tbody>
</table>
</div></body></html>`;
}


async function crmGetFilters() {
  const ownersMap = new Map();
  const stagesSet = new Set();

  try {
    const usersSnap = await dbCRM.collection("users").orderBy("name", "asc").limit(300).get();

    usersSnap.forEach(doc => {
      const u = doc.data() || {};
      const email = String(u.email || "").trim().toLowerCase();
      if (!email) return;

      ownersMap.set(email, {
        id: doc.id,
        name: u.name || "",
        email,
        role: u.role || ""
      });
    });
  } catch (err) {
    console.log("[CRM FILTERS] users error:", err.message);
  }

  try {
    const cfgSnap = await dbCRM.collection("automation_configs").limit(300).get();

    cfgSnap.forEach(doc => {
      const d = doc.data() || {};
      [d.stage, d.replyStage, d.noReplyStage].forEach(v => {
        const s = String(v || "").trim();
        if (s) stagesSet.add(s);
      });
    });
  } catch (err) {
    console.log("[CRM FILTERS] automation_configs error:", err.message);
  }

  try {
    const dealsSnap = await dbCRM.collection("deals").limit(1000).get();

    dealsSnap.forEach(doc => {
      const d = doc.data() || {};

      const stage = String(d.stage || d.status || d.estado || d.pipelineStage || "").trim();
      if (stage) stagesSet.add(stage);

      const owner = String(d.owner || d.ownerEmail || d.assignedTo || d.seller || d.vendedor || d.responsible || "").trim().toLowerCase();
      if (owner && !ownersMap.has(owner)) {
        ownersMap.set(owner, {
          id: owner,
          name: "",
          email: owner,
          role: ""
        });
      }
    });
  } catch (err) {
    console.log("[CRM FILTERS] deals error:", err.message);
  }

  return {
    owners: Array.from(ownersMap.values()).sort((a, b) =>
      String(a.name || a.email).localeCompare(String(b.name || b.email))
    ),
    stages: Array.from(stagesSet.values()).sort((a, b) =>
      String(a).localeCompare(String(b))
    )
  };
}

app.get("/api/crm/filters", requireAuth, async (req, res) => {
  try {
    const filters = await crmGetFilters();
    res.json({ ok: true, ...filters });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


async function findCachedReviewForConversation(conversationId, preferredDate) {
  const id = String(conversationId || "").trim();
  if (!id) return null;

  // First exact date key, used by daily reports.
  if (preferredDate) {
    try {
      const doc = await db.collection("supervisor_reviews")
        .doc(fullDayReviewDocId(preferredDate, id))
        .get();

      if (doc.exists) return { id: doc.id, data: doc.data() || {} };
    } catch (err) {}
  }

  // Then any previous review for that conversation.
  try {
    const snap = await db.collection("supervisor_reviews")
      .where("conversationId", "==", id)
      .limit(1)
      .get();

    if (!snap.empty) {
      return {
        id: snap.docs[0].id,
        data: snap.docs[0].data() || {}
      };
    }
  } catch (err) {}

  return null;
}

async function saveSupervisorReviewFromCrm({ asOf, deal, conversation, aiReview, error }) {
  const reviewId = fullDayReviewDocId(asOf, conversation.id);
  const reviewRef = db.collection("supervisor_reviews").doc(reviewId);

  const item = {
    ok: !error,
    date: asOf,
    conversationId: conversation.id,
    dealId: deal.id,
    crmDealId: deal.id,
    crmDealTitle: deal.title || null,
    crmOwner: deal.owner || null,
    crmStage: deal.stage || null,
    crmDueDate: deal.dueDate || null,
    crmOverdueDays: deal.overdueDays || null,
    contactName: conversation.contactName || deal.contact?.name || deal.title || null,
    phone: conversation.phone || deal.contact?.phone || null,
    lineId: conversation.lineId || conversation.inboundTo || null,
    lastMessageAt: conversation.lastMessageAt || null,
    stage: conversation.stage || deal.stage || null,
    sourceChannel: conversation.sourceChannel || conversation.leadPlatform || null,
    source: "crm_linked_chat"
  };

  if (error) {
    item.error = error;
  } else {
    item.result = aiReview.result;
    item.score = aiReview.overall_score;
    item.risk = aiReview.risk_level;
    item.reason = reviewReason(aiReview);
    item.nextBestReply = aiReview.next_best_reply;
    item.aiReview = aiReview;
  }

  const dbItem = {
    ...item,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  };

  await reviewRef.set(dbItem, { merge: true });

  // Importante: no devolvemos FieldValue.serverTimestamp() dentro del objeto.
  // Ese valor no puede guardarse más tarde dentro de arrays como data.rows[].review.updatedAt.
  return { id: reviewId, data: { ...item, updatedAt: new Date().toISOString() } };
}


app.get("/api/crm/overdue-summary", requireAuth, async (req, res) => {
  try {
    const asOf = String(req.query.asOf || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const limit = Math.min(Number(req.query.limit || 30), 100);
    const owner = String(req.query.owner || "").trim();
    const stage = String(req.query.stage || "").trim();

    const data = await crmBuildOverdueData(asOf, limit, { owner, stage });
    const managerReport = crmBuildManagerReport(data);
    const reportId = "crm_overdue__" + asOf + "__" + safeFileName(owner || "all") + "__" + safeFileName(stage || "all");

    await db.collection("supervisor_reports").doc(reportId).set({
      ok: true,
      type: "crm_overdue",
      asOf,
      filters: data.filters,
      summary: data.summary,
      byOwner: data.byOwner,
      byStage: data.byStage,
      worstOverdue: data.worstOverdue,
      managerReport,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.json({ ok: true, ...data, managerReport });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.get("/api/crm/analyze-linked-chats", requireAuth, async (req, res) => {
  try {
    const asOf = String(req.query.asOf || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const limit = Math.min(Number(req.query.limit || 10), 30);
    const owner = String(req.query.owner || "").trim();
    const stage = String(req.query.stage || "").trim();

    const data = await crmBuildOverdueData(asOf, limit, { owner, stage });

    const processed = [];
    const skipped = [];
    const errors = [];

    for (const deal of data.worstOverdue || []) {
      const conversation = deal.conversation;

      if (!conversation || !conversation.id) {
        skipped.push({
          dealId: deal.id,
          title: deal.title,
          owner: deal.owner || null,
          stage: deal.stage || null,
          reason: "Sin chat vinculado"
        });
        continue;
      }

      const cached = await findCachedReviewForConversation(conversation.id, asOf);

      if (cached) {
        processed.push({
          dealId: deal.id,
          title: deal.title,
          conversationId: conversation.id,
          fromCache: true,
          reviewId: cached.id,
          review: cached.data
        });
        continue;
      }

      try {
        const messages = await getConversationMessages(conversation.id, 100);

        if (!messages || messages.length < 2) {
          const saved = await saveSupervisorReviewFromCrm({
            asOf,
            deal,
            conversation,
            aiReview: null,
            error: "Sin mensajes suficientes"
          });

          processed.push({
            dealId: deal.id,
            title: deal.title,
            conversationId: conversation.id,
            fromCache: false,
            reviewId: saved.id,
            review: saved.data
          });
          continue;
        }

        // Reutiliza el analizador de chat existente del Supervisor.
        const aiReview = await analyzeWithAI(conversation, messages);

        const saved = await saveSupervisorReviewFromCrm({
          asOf,
          deal,
          conversation,
          aiReview,
          error: null
        });

        processed.push({
          dealId: deal.id,
          title: deal.title,
          conversationId: conversation.id,
          fromCache: false,
          reviewId: saved.id,
          review: saved.data
        });
      } catch (err) {
        errors.push({
          dealId: deal.id,
          title: deal.title,
          conversationId: conversation.id,
          error: err.message
        });
      }
    }

    // Rebuild report so it includes newly saved chat reviews.
    const updatedData = await crmBuildOverdueData(asOf, limit, { owner, stage });
    const managerReport = crmBuildManagerReport(updatedData);

    const reportId = "crm_overdue_with_chat_ai__" + asOf + "__" + safeFileName(owner || "all") + "__" + safeFileName(stage || "all");

    await db.collection("supervisor_reports").doc(reportId).set({
      ok: true,
      type: "crm_overdue_with_chat_ai",
      asOf,
      filters: updatedData.filters,
      summary: updatedData.summary,
      byOwner: updatedData.byOwner,
      byStage: updatedData.byStage,
      processedCount: processed.length,
      skippedCount: skipped.length,
      errorCount: errors.length,
      worstOverdue: updatedData.worstOverdue,
      managerReport,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.json({
      ok: true,
      mode: "crm_analyze_linked_chats_using_existing_analyzeWithAI",
      asOf,
      filters: { owner, stage },
      processedCount: processed.length,
      skippedCount: skipped.length,
      errorCount: errors.length,
      processed,
      skipped,
      errors,
      updatedSummary: updatedData.summary,
      managerReport
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});



function crmReviewScore(review) {
  const n = Number(review?.score ?? review?.overall_score ?? review?.aiReview?.overall_score);
  return Number.isFinite(n) ? n : null;
}

function crmReviewRisk(review) {
  return String(review?.risk || review?.risk_level || review?.aiReview?.risk_level || "").toLowerCase();
}

function crmExecutiveRank(review) {
  const score = crmReviewScore(review);
  const risk = crmReviewRisk(review);
  const alert = review?.should_alert_owner === true || review?.aiReview?.should_alert_owner === true;

  if (risk === "alto" || alert || (score !== null && score < 45)) return 3;
  if (risk === "medio" || (score !== null && score < 70)) return 2;
  return 1;
}

function crmExecutiveLabel(rank) {
  if (rank >= 3) return "CRITICO";
  if (rank === 2) return "REVISAR";
  return "OK";
}

function crmExecutiveEmoji(rank) {
  if (rank >= 3) return "🔴";
  if (rank === 2) return "🟠";
  return "🟢";
}

function crmExecutiveReason(review) {
  const ai = review?.aiReview || {};
  const bad = Array.isArray(ai.bad_points) ? ai.bad_points.filter(Boolean) : [];
  if (bad.length) return bad.slice(0, 2).join(" / ");
  return review?.reason || ai.summary || review?.error || "-";
}

function crmExecutiveAction(review) {
  const ai = review?.aiReview || {};
  return ai.next_best_reply || review?.nextBestReply || "Contactar al cliente, actualizar nota y definir próxima acción en CRM.";
}

function crmBuildRowsFromDeals(data) {
  const deals = data?.worstOverdue || [];
  return deals.map(d => {
    const review = d.chatReview || {};
    const rank = review && Object.keys(review).length ? crmExecutiveRank(review) : 2;
    const score = crmReviewScore(review);
    const ai = review.aiReview || {};
    const notes = Array.isArray(d.dealNotes) && d.dealNotes.length
      ? d.dealNotes
      : [];

    return {
      rank,
      label: crmExecutiveLabel(rank),
      emoji: crmExecutiveEmoji(rank),
      dealId: d.id,
      title: d.title || "-",
      value: d.value || 0,
      client: d.contact?.name || d.title || "Sin cliente",
      company: d.contact?.company || "",
      phone: d.contact?.phone || d.phone || "",
      email: d.contact?.email || "",
      owner: d.owner || d.contact?.owner || "sin asignar",
      stage: d.stage || "-",
      dueDate: d.dueDate || "-",
      overdueDays: d.overdueDays || 0,
      conversationId: d.conversation?.id || "-",
      score: score,
      result: review.result || ai.result || "sin análisis",
      risk: review.risk || ai.risk_level || "sin análisis",
      reason: review && Object.keys(review).length ? crmExecutiveReason(review) : "Chat sin análisis IA todavía.",
      action: review && Object.keys(review).length ? crmExecutiveAction(review) : "Analizar chat vinculado o contactar al cliente y actualizar CRM.",
      summary: ai.summary || review.reason || "",
      good: Array.isArray(ai.good_points) ? ai.good_points : [],
      bad: Array.isArray(ai.bad_points) ? ai.bad_points : [],
      missed: Array.isArray(ai.missed_opportunities) ? ai.missed_opportunities : [],
      nextBestReply: ai.next_best_reply || review.nextBestReply || "",
      notes,
      rawDeal: d
    };
  }).sort((a, b) => {
    if (b.rank !== a.rank) return b.rank - a.rank;
    const as = a.score === null ? 999 : a.score;
    const bs = b.score === null ? 999 : b.score;
    if (as !== bs) return as - bs;
    return b.overdueDays - a.overdueDays;
  });
}

function crmProfessionalExecutiveText(data, rows) {
  const s = data.summary || {};
  const critical = rows.filter(r => r.rank >= 3);
  const review = rows.filter(r => r.rank === 2);
  const ok = rows.filter(r => r.rank === 1);
  const scored = rows.filter(r => r.score !== null);
  const avgScore = scored.length ? Math.round(scored.reduce((sum, r) => sum + r.score, 0) / scored.length) : "-";
  const totalValue = rows.reduce((sum, r) => sum + (Number(r.value) || 0), 0);

  const top = rows.slice(0, 20).map((r, i) => {
    return `${i + 1}) ${r.emoji} ${r.label} — ${r.client}
   Trato: ${r.title}
   Vendedor: ${r.owner}
   Stage: ${r.stage}
   Vencido: ${r.overdueDays} días
   Valor CRM: ${r.value || "-"}
   Score: ${r.score ?? "-"}/100 · Resultado: ${String(r.result).toUpperCase()} · Riesgo: ${String(r.risk).toUpperCase()}
   Motivo: ${r.reason}
   Acción sugerida: ${r.action}
`;
  }).join("\n");

  return `📊 REPORTE GERENCIAL PROFESIONAL — CRM + WHATSAPP + IA
Fecha de corte: ${data.asOf}
Filtro vendedor: ${data.filters?.owner || "Todos"}
Filtro stage: ${data.filters?.stage || "Todos"}

RESUMEN EJECUTIVO
- Tratos leídos: ${s.totalDealsRead || 0}
- Tratos abiertos con vencimiento: ${s.totalOpenWithDueDate || 0}
- Tratos vencidos: ${s.totalOverdue || 0}
- Casos incluidos en ZIP: ${rows.length}
- Score promedio de atención: ${avgScore}/100
- Valor total CRM incluido: ${totalValue || "-"}

VENCIMIENTOS
- 1 a 7 días: ${s.overdue_1_7 || 0}
- 8 a 30 días: ${s.overdue_8_30 || 0}
- Más de 30 días: ${s.overdue_30_plus || 0}

SEMÁFORO
🔴 Críticos: ${critical.length}
🟠 Para revisar: ${review.length}
🟢 Correctos: ${ok.length}

LECTURA RÁPIDA
${critical.length ? "Hay casos críticos que requieren revisión inmediata." : "No se detectaron casos críticos en esta tanda."}
${review.length ? "Hay oportunidades con seguimiento incompleto o score medio." : "No hay volumen relevante de casos intermedios."}
${rows.some(r => r.conversationId === "-") ? "Existen tratos sin chat vinculado; revisar integración CRM/Bandeja." : "Los casos exportados tienen vínculo con chat o información asociada."}

TOP CASOS PRIORITARIOS
${top || "Sin casos para mostrar."}

ACCIONES PARA EL JEFE DE VENTAS
1) Revisar primero los casos 🔴 CRÍTICOS.
2) Pedir al vendedor actualización de nota y próxima fecha en CRM.
3) Confirmar si el cliente fue contactado después del último mensaje.
4) Si el trato sigue activo, llamar o enviar la respuesta sugerida.
5) Si no responde, mover a la etapa correcta para limpiar pipeline.`;
}

function crmCaseTxt(row) {
  const notesText = row.notes.length
    ? row.notes.map(n => `- ${n.createdAt || ""} · ${n.user || "system"}: ${n.note || ""}`).join("\n")
    : "- Sin notas detectadas";

  const list = arr => arr && arr.length ? arr.map(x => "- " + x).join("\n") : "- Sin datos";

  return `SCB — REPORTE INDIVIDUAL CRM + WHATSAPP + IA
=================================================

${row.emoji} ESTADO: ${row.label}

CLIENTE
Cliente: ${row.client}
Empresa: ${row.company || "-"}
Teléfono: ${row.phone || "-"}
Email: ${row.email || "-"}

TRATO CRM
Deal ID: ${row.dealId}
Trato: ${row.title}
Vendedor: ${row.owner}
Stage: ${row.stage}
Valor CRM: ${row.value || "-"}
Due date: ${row.dueDate}
Vencido hace: ${row.overdueDays} días

CHAT / IA
Chat ID: ${row.conversationId}
Score: ${row.score ?? "-"}/100
Resultado: ${String(row.result).toUpperCase()}
Riesgo: ${String(row.risk).toUpperCase()}

MOTIVO PRINCIPAL
${row.reason}

RESUMEN IA
${row.summary || "-"}

PUNTOS BUENOS
${list(row.good)}

PROBLEMAS DETECTADOS
${list(row.bad)}

OPORTUNIDADES PERDIDAS
${list(row.missed)}

NOTAS CRM
${notesText}

ACCIÓN SUGERIDA
${row.action}

RESPUESTA SUGERIDA AL CLIENTE
${row.nextBestReply || row.action}

`;
}

function crmCaseHtml(row) {
  const color = row.rank >= 3 ? "#dc2626" : row.rank === 2 ? "#d97706" : "#16a34a";
  const notesHtml = row.notes.length
    ? row.notes.map(n => `<li><b>${htmlEscape(n.createdAt || "")}</b> · ${htmlEscape(n.user || "system")}: ${htmlEscape(n.note || "")}</li>`).join("")
    : "<li>Sin notas detectadas</li>";

  const list = arr => arr && arr.length
    ? "<ul>" + arr.map(x => "<li>" + htmlEscape(x) + "</li>").join("") + "</ul>"
    : "<p class='muted'>Sin datos</p>";

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>${htmlEscape(row.client)} - ${htmlEscape(row.label)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;max-width:1100px;margin:auto;box-shadow:0 8px 28px rgba(0,0,0,.10)}
.badge{display:inline-block;background:${color};color:#fff;padding:8px 12px;border-radius:999px;font-weight:800}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}
.box{border:1px solid #e5e7eb;border-radius:14px;padding:16px;background:#fafafa}
h1{margin-bottom:6px}
h2{margin-top:0;font-size:18px}
.metric{font-size:28px;font-weight:800}
.muted{color:#6b7280}
.reply{white-space:pre-wrap;border-left:5px solid ${color};background:#f9fafb;padding:14px;border-radius:10px}
ul{margin-top:6px}
@media(max-width:800px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="card">
<span class="badge">${htmlEscape(row.emoji + " " + row.label)}</span>
<h1>${htmlEscape(row.client)}</h1>
<p class="muted">Trato: ${htmlEscape(row.title)} · Vendedor: ${htmlEscape(row.owner)} · Stage: ${htmlEscape(row.stage)}</p>

<div class="grid">
  <div class="box">
    <h2>CRM</h2>
    <p><b>Deal ID:</b> ${htmlEscape(row.dealId)}</p>
    <p><b>Valor:</b> ${htmlEscape(row.value || "-")}</p>
    <p><b>Due date:</b> ${htmlEscape(row.dueDate)}</p>
    <p><b>Vencido:</b> <span class="metric">${htmlEscape(row.overdueDays)}</span> días</p>
  </div>
  <div class="box">
    <h2>WhatsApp / IA</h2>
    <p><b>Chat:</b> ${htmlEscape(row.conversationId)}</p>
    <p><b>Score:</b> <span class="metric">${htmlEscape(row.score ?? "-")}</span>/100</p>
    <p><b>Resultado:</b> ${htmlEscape(String(row.result).toUpperCase())}</p>
    <p><b>Riesgo:</b> ${htmlEscape(String(row.risk).toUpperCase())}</p>
  </div>
</div>

<div class="box">
  <h2>Motivo principal</h2>
  <p>${htmlEscape(row.reason)}</p>
</div>

<div class="box">
  <h2>Resumen IA</h2>
  <p>${htmlEscape(row.summary || "-")}</p>
</div>

<div class="grid">
  <div class="box">
    <h2>✅ Puntos buenos</h2>
    ${list(row.good)}
  </div>
  <div class="box">
    <h2>⚠️ Problemas detectados</h2>
    ${list(row.bad)}
  </div>
</div>

<div class="box">
  <h2>💸 Oportunidades perdidas</h2>
  ${list(row.missed)}
</div>

<div class="box">
  <h2>📝 Notas CRM</h2>
  <ul>${notesHtml}</ul>
</div>

<div class="box">
  <h2>🎯 Acción sugerida</h2>
  <div class="reply">${htmlEscape(row.action)}</div>
</div>

<div class="box">
  <h2>💬 Respuesta sugerida al cliente</h2>
  <div class="reply">${htmlEscape(row.nextBestReply || row.action)}</div>
</div>
</div>
</body>
</html>`;
}

function crmProfessionalSummaryHtml(data, rows, executiveText) {
  const rowHtml = rows.map(r => {
    const color = r.rank >= 3 ? "#dc2626" : r.rank === 2 ? "#d97706" : "#16a34a";
    return `<tr>
<td style="font-weight:bold;color:${color}">${htmlEscape(r.emoji + " " + r.label)}</td>
<td>${htmlEscape(r.client)}</td>
<td>${htmlEscape(r.title)}</td>
<td>${htmlEscape(r.owner)}</td>
<td>${htmlEscape(r.stage)}</td>
<td>${htmlEscape(r.overdueDays)}</td>
<td>${htmlEscape(r.score ?? "-")}</td>
<td>${htmlEscape(r.risk)}</td>
<td>${htmlEscape(r.reason)}</td>
</tr>`;
  }).join("");

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Reporte Gerencial CRM SCB ${htmlEscape(data.asOf)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;background:#fff;margin-top:18px}
td,th{border:1px solid #e5e7eb;padding:9px;text-align:left;vertical-align:top;font-size:13px}
th{background:#f9fafb}
</style>
</head>
<body>
<div class="card">
<h1>Reporte Gerencial CRM + WhatsApp + IA</h1>
<pre>${htmlEscape(executiveText)}</pre>
<table>
<thead><tr><th>Estado</th><th>Cliente</th><th>Trato</th><th>Vendedor</th><th>Stage</th><th>Días vencido</th><th>Score</th><th>Riesgo</th><th>Motivo</th></tr></thead>
<tbody>${rowHtml}</tbody>
</table>
</div>
</body>
</html>`;
}

app.get("/api/crm/overdue-professional-zip", requireAuth, async (req, res) => {
  try {
    const asOf = String(req.query.asOf || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const owner = String(req.query.owner || "").trim();
    const stage = String(req.query.stage || "").trim();
    const limit = Math.min(Number(req.query.limit || 100), 300);

    const data = await crmBuildOverdueData(asOf, limit, { owner, stage });
    const rows = crmBuildRowsFromDeals(data);
    const executiveText = crmProfessionalExecutiveText(data, rows);
    const summaryHtml = crmProfessionalSummaryHtml(data, rows, executiveText);

    const reportId = "crm_professional_zip__" + asOf + "__" + safeFileName(owner || "all") + "__" + safeFileName(stage || "all");

    await db.collection("supervisor_reports").doc(reportId).set({
      ok: true,
      type: "crm_professional_zip",
      asOf,
      filters: data.filters,
      summary: data.summary,
      rows,
      executiveReport: executiveText,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="crm-profesional-${asOf}-${safeFileName(owner || "all")}-${safeFileName(stage || "all")}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(executiveText, { name: "00_RESUMEN_GERENCIAL.txt" });
    archive.append(summaryHtml, { name: "00_RESUMEN_GERENCIAL.html" });
    archive.append(JSON.stringify({ ...data, executiveRows: rows, executiveReport: executiveText }, null, 2), { name: "00_DATA.json" });

    rows.forEach((row, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      const folder = row.rank >= 3 ? "01_CRITICOS" : row.rank === 2 ? "02_REVISAR" : "03_OK";
      const fileBase = `${prefix}_${row.overdueDays || 0}dias_${safeFileName(row.owner)}_${safeFileName(row.client)}`;
      archive.append(crmCaseTxt(row), { name: `${folder}/${fileBase}.txt` });
      archive.append(crmCaseHtml(row), { name: `${folder}/${fileBase}.html` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP profesional CRM: " + err.message);
  }
});


app.get("/api/crm/overdue-summary/download", requireAuth, async (req, res) => {
  try {
    const asOf = String(req.query.asOf || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const owner = String(req.query.owner || "").trim();
    const stage = String(req.query.stage || "").trim();
    const limit = Math.min(Number(req.query.limit || 100), 300);

    const data = await crmBuildOverdueData(asOf, limit, { owner, stage });
    const managerReport = crmBuildManagerReport(data);
    const reportId = "crm_overdue__" + asOf + "__" + safeFileName(owner || "all") + "__" + safeFileName(stage || "all");

    await db.collection("supervisor_reports").doc(reportId).set({
      ok: true,
      type: "crm_overdue",
      asOf,
      filters: data.filters,
      summary: data.summary,
      byOwner: data.byOwner,
      byStage: data.byStage,
      worstOverdue: data.worstOverdue,
      managerReport,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="crm-overdue-report-${asOf}-${safeFileName(owner || "all")}-${safeFileName(stage || "all")}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(managerReport, { name: "resumen-crm.txt" });
    archive.append(crmSummaryHtml(data, managerReport), { name: "resumen-crm.html" });
    archive.append(JSON.stringify({ ...data, managerReport }, null, 2), { name: "data.json" });

    (data.worstOverdue || []).forEach((d, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      archive.append(crmDealTxt(d), { name: `tratos/${prefix}_${d.overdueDays || 0}dias_${safeFileName(d.owner || "sin_owner")}_${safeFileName(d.contact?.name || d.title || d.id)}.txt` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP CRM: " + err.message);
  }
});


// =====================================================
// CRM STAGE ARRIVALS REPORT — NO OPENAI
// Counts deals currently in a selected CRM stage and updated/moved during the selected day.
// Uses supervisor_reports cache to avoid repeated Firestore reads.
// =====================================================

function crmStageDayRangeArgentina(dateStr) {
  // Argentina is UTC-03. Firestore timestamps are UTC, but gerencial reports are by local AR day.
  return {
    from: new Date(dateStr + "T03:00:00.000Z"),
    to: new Date(new Date(dateStr + "T03:00:00.000Z").getTime() + 24 * 60 * 60 * 1000 - 1)
  };
}

function crmStageMovementDocId(date, stage, owner) {
  return "crm_stage_arrivals__" + date + "__" + safeFileName(stage || "all") + "__" + safeFileName(owner || "all");
}

function crmStagePickMovementAt(data) {
  return crmTs(
    data.stageChangedAt ||
    data.stageUpdatedAt ||
    data.enteredStageAt ||
    data.lastStageChangeAt ||
    data.stageMovedAt ||
    data.movedAt ||
    data.updatedAt ||
    data.lastActivityAt ||
    data.createdAt
  );
}

function crmNormalizeStageArrivalDeal(doc) {
  const d = doc.data() || {};
  return {
    id: doc.id,
    title: crmText(d, ["title", "name", "dealName", "nombre"]) || doc.id,
    contactId: crmText(d, ["contactId", "contact_id"]),
    owner: crmText(d, ["owner", "ownerEmail", "assignedTo", "seller", "vendedor", "responsible"]),
    stage: crmText(d, ["stage", "status", "estado", "pipelineStage"]),
    value: crmNumber(d, ["value", "amount", "valor"]),
    dueDate: crmTs(d.dueDate || d.nextDueDate || d.fechaVencimiento || d.vencimiento || d.nextFollowUpAt || d.followUpDate),
    updatedAt: crmTs(d.updatedAt || d.lastActivityAt || d.createdAt),
    createdAt: crmTs(d.createdAt),
    movementAt: crmStagePickMovementAt(d),
    movementSourceField: d.stageChangedAt ? "stageChangedAt" :
      d.stageUpdatedAt ? "stageUpdatedAt" :
      d.enteredStageAt ? "enteredStageAt" :
      d.lastStageChangeAt ? "lastStageChangeAt" :
      d.stageMovedAt ? "stageMovedAt" :
      d.movedAt ? "movedAt" :
      d.updatedAt ? "updatedAt" :
      d.lastActivityAt ? "lastActivityAt" :
      d.createdAt ? "createdAt" : "none",
    conversationId: crmText(d, ["conversationId", "waConversationId", "chatId", "whatsappConversationId"]),
    contactName: crmText(d, ["contactName", "clientName", "cliente", "company", "companyName"]),
    phone: crmText(d, ["phone", "whatsapp", "mobile", "phoneNumber", "waPhone"]),
    notes: crmText(d, ["notes", "note", "lastNote"])
  };
}

function crmStageInDay(iso, fromDate, toDate) {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return Number.isFinite(t) && t >= fromDate.getTime() && t <= toDate.getTime();
}

async function crmFetchStageArrivalsDeals({ date, stage, owner, limit }) {
  const { from, to } = crmStageDayRangeArgentina(date);
  const docsById = new Map();
  const errors = [];
  const movementFields = ["stageChangedAt", "stageUpdatedAt", "enteredStageAt", "lastStageChangeAt", "stageMovedAt", "movedAt", "updatedAt"];

  for (const field of movementFields) {
    try {
      const snap = await dbCRM.collection("deals")
        .where("stage", "==", stage)
        .where(field, ">=", from)
        .where(field, "<=", to)
        .limit(limit)
        .get();
      snap.docs.forEach(doc => docsById.set(doc.id, doc));
      if (docsById.size >= limit) break;
    } catch (err) {
      errors.push({ field, error: err.message });
    }
  }

  let queryMode = "stage_plus_movement_date";

  if (!docsById.size) {
    try {
      const snap = await dbCRM.collection("deals")
        .where("stage", "==", stage)
        .limit(Math.max(limit, 300))
        .get();
      snap.docs.forEach(doc => docsById.set(doc.id, doc));
      queryMode = "fallback_stage_only_filtered_locally";
    } catch (err) {
      errors.push({ field: "stage_only", error: err.message });
    }
  }

  let deals = Array.from(docsById.values()).map(crmNormalizeStageArrivalDeal)
    .filter(d => crmNorm(d.stage) === crmNorm(stage))
    .filter(d => crmStageInDay(d.movementAt || d.updatedAt || d.createdAt, from, to));

  const cleanOwner = String(owner || "").trim();
  if (cleanOwner) {
    deals = deals.filter(d => crmNorm(d.owner) === crmNorm(cleanOwner));
  }

  deals.sort((a, b) => new Date(b.movementAt || b.updatedAt || 0).getTime() - new Date(a.movementAt || a.updatedAt || 0).getTime());
  deals = deals.slice(0, limit);

  return { deals, queryMode, errors, fromIso: from.toISOString(), toIso: to.toISOString() };
}

function crmBuildStageArrivalsData({ date, stage, owner, limit, fetched }) {
  const deals = fetched.deals || [];
  const byOwnerMap = new Map();
  let totalValue = 0;
  let valueCount = 0;

  for (const d of deals) {
    const key = d.owner || "sin vendedor";
    const current = byOwnerMap.get(key) || { owner: key, count: 0, totalValue: 0 };
    current.count += 1;
    if (Number.isFinite(Number(d.value))) {
      current.totalValue += Number(d.value);
      totalValue += Number(d.value);
      valueCount += 1;
    }
    byOwnerMap.set(key, current);
  }

  const byOwner = Array.from(byOwnerMap.values()).sort((a, b) => b.count - a.count || String(a.owner).localeCompare(String(b.owner)));

  return {
    ok: true,
    type: "crm_stage_arrivals",
    date,
    stage,
    filters: { owner: owner || "", limit },
    dateRangeArgentina: { from: fetched.fromIso, to: fetched.toIso },
    queryMode: fetched.queryMode,
    count: deals.length,
    totalValue,
    valueCount,
    byOwner,
    deals,
    queryWarnings: fetched.errors || [],
    generatedAt: new Date().toISOString(),
    accuracyNote: "Este reporte cuenta tratos que actualmente están en el stage elegido y cuyo campo de movimiento/actualización cae dentro del día seleccionado. Para exactitud histórica perfecta, el CRM debe guardar cada cambio de stage en una colección de movimientos."
  };
}

function crmStageMoney(n) {
  const num = Number(n || 0);
  if (!Number.isFinite(num) || num === 0) return "-";
  return "USD " + Math.round(num).toLocaleString("es-AR");
}

function crmBuildStageArrivalsReport(data) {
  const ownerRows = (data.byOwner || []).length
    ? data.byOwner.map((x, i) => `${i + 1}) ${x.owner}: ${x.count} trato(s) · ${crmStageMoney(x.totalValue)}`).join("\n")
    : "-";

  const dealRows = (data.deals || []).length
    ? data.deals.map((d, i) => `${i + 1}) ${d.title || d.contactName || d.id}
   Vendedor: ${d.owner || "-"}
   Valor: ${crmStageMoney(d.value)}
   Entró/actualizado: ${d.movementAt || d.updatedAt || "-"}
   Campo usado: ${d.movementSourceField || "-"}
   Due date: ${d.dueDate || "-"}
   Deal ID: ${d.id}
   Chat: ${d.conversationId || "-"}`).join("\n\n")
    : "Sin tratos detectados para ese criterio.";

  return `📊 REPORTE CRM — LLEGADAS A STAGE
Fecha: ${data.date} (día Argentina)
Stage consultado: ${data.stage}
Filtro vendedor: ${data.filters?.owner || "Todos"}

RESUMEN EJECUTIVO
- Tratos detectados: ${data.count}
- Valor total cargado: ${crmStageMoney(data.totalValue)}
- Tratos con valor cargado: ${data.valueCount}
- Modo de consulta: ${data.queryMode}

RESUMEN POR VENDEDOR
${ownerRows}

DETALLE DE TRATOS
${dealRows}

LECTURA GERENCIAL
${data.count ? "- Hubo movimiento comercial hacia el stage consultado durante el día." : "- No se detectaron tratos que hayan llegado/actualizado ese stage en el día."}
${data.totalValue ? "- El valor total cargado permite medir volumen comercial enviado a este stage." : "- Hay que revisar carga de valores CRM si se quiere medir monto total."}

NOTA DE EXACTITUD
${data.accuracyNote}`;
}

function crmStageArrivalsHtml(data, reportText) {
  const rows = (data.deals || []).map((d, i) => `<tr>
<td>${i + 1}</td>
<td>${htmlEscape(d.title || d.contactName || d.id)}</td>
<td>${htmlEscape(d.owner || "-")}</td>
<td>${htmlEscape(crmStageMoney(d.value))}</td>
<td>${htmlEscape(d.movementAt || d.updatedAt || "-")}</td>
<td>${htmlEscape(d.movementSourceField || "-")}</td>
<td>${htmlEscape(d.dueDate || "-")}</td>
<td>${htmlEscape(d.id)}</td>
</tr>`).join("");

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>CRM Stage ${htmlEscape(data.stage)} ${htmlEscape(data.date)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}
.box{border:1px solid #e5e7eb;border-radius:14px;padding:16px;background:#fafafa}
.metric{font-size:30px;font-weight:800}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff;margin-top:18px}
td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}
th{background:#f9fafb}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="card">
<h1>Reporte CRM — Llegadas a ${htmlEscape(data.stage)}</h1>
<p><b>Fecha:</b> ${htmlEscape(data.date)} · <b>Vendedor:</b> ${htmlEscape(data.filters?.owner || "Todos")}</p>
<div class="grid">
  <div class="box"><h3>Tratos</h3><div class="metric">${htmlEscape(data.count)}</div></div>
  <div class="box"><h3>Valor total</h3><div class="metric">${htmlEscape(crmStageMoney(data.totalValue))}</div></div>
  <div class="box"><h3>Con valor cargado</h3><div class="metric">${htmlEscape(data.valueCount)}</div></div>
</div>
<pre>${htmlEscape(reportText)}</pre>
<table>
<thead><tr><th>#</th><th>Trato</th><th>Vendedor</th><th>Valor</th><th>Entró/actualizado</th><th>Campo usado</th><th>Due date</th><th>Deal ID</th></tr></thead>
<tbody>${rows || '<tr><td colspan="8">Sin tratos detectados.</td></tr>'}</tbody>
</table>
</div>
</body>
</html>`;
}

async function crmGetStageArrivalsReport({ date, stage, owner, limit, useCache }) {
  const reportId = crmStageMovementDocId(date, stage, owner);

  if (useCache) {
    const cached = await db.collection("supervisor_reports").doc(reportId).get();
    if (cached.exists) {
      const data = cached.data() || {};
      return { ...data, fromCache: true, reportId };
    }
  }

  const fetched = await crmFetchStageArrivalsDeals({ date, stage, owner, limit });
  const data = crmBuildStageArrivalsData({ date, stage, owner, limit, fetched });
  const managerReport = crmBuildStageArrivalsReport(data);

  await db.collection("supervisor_reports").doc(reportId).set({
    ...data,
    managerReport,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { ...data, managerReport, fromCache: false, reportId };
}

app.get("/api/crm/stage-arrivals", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const stage = String(req.query.stage || "Horno").trim() || "Horno";
    const owner = String(req.query.owner || "").trim();
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 300);
    const refresh = String(req.query.refresh || "") === "1";

    const data = await crmGetStageArrivalsReport({ date, stage, owner, limit, useCache: !refresh });

    res.json({
      ok: true,
      mode: "crm_stage_arrivals_no_openai",
      reportId: data.reportId,
      fromCache: !!data.fromCache,
      date: data.date,
      stage: data.stage,
      filters: data.filters,
      count: data.count,
      totalValue: data.totalValue,
      valueCount: data.valueCount,
      byOwner: data.byOwner,
      dealsPreview: (data.deals || []).slice(0, 100),
      managerReport: data.managerReport,
      accuracyNote: data.accuracyNote,
      note: "No usa OpenAI. Lee CRM y guarda el resultado en supervisor_reports."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/crm/stage-arrivals/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const stage = String(req.query.stage || "Horno").trim() || "Horno";
    const owner = String(req.query.owner || "").trim();
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 300);
    const refresh = String(req.query.refresh || "") === "1";

    const data = await crmGetStageArrivalsReport({ date, stage, owner, limit, useCache: !refresh });
    const reportText = data.managerReport || crmBuildStageArrivalsReport(data);
    const reportHtml = crmStageArrivalsHtml(data, reportText);

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="crm-stage-${safeFileName(stage)}-${date}-${safeFileName(owner || "all")}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(reportText, { name: "00_RESUMEN_GERENCIAL.txt" });
    archive.append(reportHtml, { name: "00_RESUMEN_GERENCIAL.html" });
    archive.append(JSON.stringify(data, null, 2), { name: "00_DATA.json" });

    (data.deals || []).forEach((d, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      const txt = `SCB — TRATO CRM EN STAGE ${data.stage}
========================================

Fecha reporte: ${data.date}
Deal ID: ${d.id}
Trato: ${d.title || "-"}
Cliente: ${d.contactName || "-"}
Vendedor: ${d.owner || "-"}
Stage: ${d.stage || "-"}
Valor: ${crmStageMoney(d.value)}
Entró/actualizado: ${d.movementAt || d.updatedAt || "-"}
Campo usado: ${d.movementSourceField || "-"}
Due date: ${d.dueDate || "-"}
Chat: ${d.conversationId || "-"}
Teléfono: ${d.phone || "-"}
Notas: ${d.notes || "-"}
`;
      archive.append(txt, { name: `tratos/${prefix}_${safeFileName(d.owner || "sin_vendedor")}_${safeFileName(d.title || d.contactName || d.id)}.txt` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP de stage CRM: " + err.message);
  }
});


// =====================================================
// CRM STAGE OPPORTUNITIES — USES EXISTING CHAT AI + CACHE
// Explains how each deal got to the selected stage and estimates closing potential.
// =====================================================

function crmStageOpportunitiesDocId(date, stage, owner) {
  return "crm_stage_opportunities__" + date + "__" + safeFileName(stage || "all") + "__" + safeFileName(owner || "all");
}

function crmReviewArray(review, key) {
  const direct = review?.[key];
  const nested = review?.aiReview?.[key];
  const value = Array.isArray(direct) ? direct : (Array.isArray(nested) ? nested : []);
  return value.filter(Boolean).map(x => String(x));
}

function crmReviewText(review, key) {
  return String(review?.[key] || review?.aiReview?.[key] || "").trim();
}

function crmClosingPotential(deal, review) {
  const score = crmReviewScore(review);
  const risk = crmReviewRisk(review);
  const missed = crmReviewArray(review, "missed_opportunities");
  const bad = crmReviewArray(review, "bad_points");
  const summary = crmReviewText(review, "summary");
  const intent = crmReviewText(review, "customer_intent");
  const nextBestReply = review?.nextBestReply || crmReviewText(review, "next_best_reply");

  let points = 45;
  const reasons = [];

  if (crmNorm(deal.stage).includes("horno")) {
    points += 15;
    reasons.push("Está en Horno, etapa comercial avanzada.");
  }

  if (Number.isFinite(score)) {
    if (score >= 80) { points += 20; reasons.push("Chat con buena calidad comercial."); }
    else if (score >= 65) { points += 10; reasons.push("Chat aceptable, con posibilidad de empuje comercial."); }
    else { points -= 15; reasons.push("Chat flojo: puede afectar el cierre."); }
  } else {
    reasons.push("Sin score IA disponible.");
  }

  if (risk === "alto") { points -= 25; reasons.push("Riesgo alto detectado en la conversación."); }
  else if (risk === "medio") { points -= 8; reasons.push("Riesgo medio: requiere seguimiento cercano."); }
  else if (risk === "bajo") { points += 10; reasons.push("Riesgo bajo detectado."); }

  if (missed.length >= 3) { points -= 15; reasons.push("Tiene varias oportunidades perdidas o puntos sin resolver."); }
  else if (missed.length === 1 || missed.length === 2) { points -= 6; reasons.push("Hay oportunidades pendientes para corregir."); }

  if (Number(deal.value || 0) > 0) {
    points += 5;
    reasons.push("Tiene valor cargado en CRM.");
  }

  if (deal.dueDate) {
    reasons.push("Tiene fecha de seguimiento/cierre cargada.");
  } else {
    points -= 5;
    reasons.push("No tiene due date cargado; puede quedar colgado.");
  }

  points = Math.max(0, Math.min(100, Math.round(points)));

  let level = "Media";
  if (points >= 75) level = "Alta";
  else if (points < 50) level = "Baja";

  return {
    level,
    score: points,
    reasons,
    howArrived: summary || intent || "No hay resumen IA disponible para explicar cómo llegó.",
    customerIntent: intent || "-",
    missedOpportunities: missed,
    badPoints: bad,
    nextAction: nextBestReply || "Revisar chat y definir próximo paso comercial con fecha concreta."
  };
}

async function crmBuildStageOpportunityRows({ date, stage, owner, limit, analyzeMissing }) {
  const stageData = await crmGetStageArrivalsReport({ date, stage, owner, limit, useCache: true });
  const rows = [];
  const processed = [];
  const skipped = [];
  const errors = [];

  for (const deal of (stageData.deals || []).slice(0, limit)) {
    let conversation = null;
    let cached = null;
    let review = null;
    let messagesCount = 0;
    let fromCache = false;

    try {
      conversation = await crmFindConversationForDeal(deal);

      if (!conversation || !conversation.id) {
        const closing = crmClosingPotential(deal, null);
        skipped.push({ dealId: deal.id, title: deal.title, reason: "Sin chat vinculado" });
        rows.push({ deal, conversation: null, review: null, closing, fromCache: false, status: "sin_chat" });
        continue;
      }

      cached = await findCachedReviewForConversation(conversation.id, date);

      if (cached) {
        review = cached.data;
        fromCache = true;
      } else if (analyzeMissing) {
        const messages = await getConversationMessages(conversation.id, 100);
        messagesCount = messages.length;

        if (!messages || messages.length < 2) {
          const saved = await saveSupervisorReviewFromCrm({
            asOf: date,
            deal,
            conversation,
            aiReview: null,
            error: "Sin mensajes suficientes"
          });
          review = saved.data;
          processed.push({ dealId: deal.id, conversationId: conversation.id, reviewId: saved.id, status: "sin_mensajes" });
        } else {
          const aiReview = await analyzeWithAI(conversation, messages);
          const saved = await saveSupervisorReviewFromCrm({
            asOf: date,
            deal,
            conversation,
            aiReview,
            error: null
          });
          review = saved.data;
          processed.push({ dealId: deal.id, conversationId: conversation.id, reviewId: saved.id, status: "analizado" });
        }
      }

      const closing = crmClosingPotential(deal, review);
      rows.push({
        deal,
        conversation,
        review,
        closing,
        fromCache,
        messagesCount,
        status: review ? (fromCache ? "cache" : "analizado") : "sin_review"
      });
    } catch (err) {
      errors.push({ dealId: deal.id, title: deal.title, error: err.message });
      const closing = crmClosingPotential(deal, review);
      rows.push({ deal, conversation, review, closing, fromCache, status: "error", error: err.message });
    }
  }

  rows.sort((a, b) => (b.closing?.score || 0) - (a.closing?.score || 0));

  return { stageData, rows, processed, skipped, errors };
}

function crmBuildStageOpportunitiesReport(data) {
  const rows = data.rows || [];
  const alta = rows.filter(r => r.closing?.level === "Alta").length;
  const media = rows.filter(r => r.closing?.level === "Media").length;
  const baja = rows.filter(r => r.closing?.level === "Baja").length;

  const byOwner = new Map();
  for (const r of rows) {
    const owner = r.deal?.owner || "sin vendedor";
    const item = byOwner.get(owner) || { owner, alta: 0, media: 0, baja: 0, total: 0 };
    item.total += 1;
    if (r.closing?.level === "Alta") item.alta += 1;
    else if (r.closing?.level === "Media") item.media += 1;
    else item.baja += 1;
    byOwner.set(owner, item);
  }

  const ownerRows = Array.from(byOwner.values())
    .sort((a, b) => b.alta - a.alta || b.total - a.total)
    .map((x, i) => `${i + 1}) ${x.owner}: ${x.total} trato(s) · Alta ${x.alta} · Media ${x.media} · Baja ${x.baja}`)
    .join("\n");

  const dealRows = rows.map((r, i) => {
    const d = r.deal || {};
    const c = r.closing || {};
    return `${i + 1}) ${d.title || d.contactName || d.id}
   Vendedor: ${d.owner || "-"}
   Valor: ${crmStageMoney(d.value)}
   Posibilidad de cierre: ${c.level || "-"} (${c.score ?? "-"}/100)
   Cómo llegó: ${c.howArrived || "-"}
   Intención del cliente: ${c.customerIntent || "-"}
   Próxima acción: ${c.nextAction || "-"}
   Puntos a corregir: ${(c.missedOpportunities || []).slice(0, 3).join(" | ") || "-"}
   Chat: ${r.conversation?.id || d.conversationId || "-"}
   Estado análisis: ${r.status || "-"}`;
  }).join("\n\n");

  return `🔥 REPORTE CRM — CÓMO LLEGARON AL HORNO
Fecha: ${data.date} (día Argentina)
Stage: ${data.stage}
Filtro vendedor: ${data.filters?.owner || "Todos"}

RESUMEN EJECUTIVO
- Tratos evaluados: ${rows.length}
- Posibilidad alta de cierre: ${alta}
- Posibilidad media: ${media}
- Posibilidad baja: ${baja}
- Chats analizados ahora: ${data.processedCount || 0}
- Casos reutilizados desde cache: ${data.cacheCount || 0}
- Sin chat vinculado: ${data.skippedCount || 0}
- Errores: ${data.errorCount || 0}

RESUMEN POR VENDEDOR
${ownerRows || "-"}

DETALLE GERENCIAL
${dealRows || "Sin tratos detectados."}

LECTURA PARA JEFE DE VENTAS
- Los casos Alta deberían tener seguimiento inmediato con propuesta concreta, llamada o cierre de condición pendiente.
- Los casos Media necesitan destrabar objeciones, datos faltantes o fecha de próximo paso.
- Los casos Baja conviene auditarlos porque pueden estar en Horno por carga CRM, pero sin señal clara de cierre en el chat.

NOTA
Este reporte reutiliza analyzeWithAI() y supervisor_reviews. No reanaliza chats que ya tienen cache.`;
}

function crmStageOpportunitiesHtml(data, reportText) {
  const rows = (data.rows || []).map((r, i) => {
    const d = r.deal || {};
    const c = r.closing || {};
    return `<tr>
<td>${i + 1}</td>
<td>${htmlEscape(d.title || d.contactName || d.id)}</td>
<td>${htmlEscape(d.owner || "-")}</td>
<td>${htmlEscape(crmStageMoney(d.value))}</td>
<td>${htmlEscape(c.level || "-")}</td>
<td>${htmlEscape(String(c.score ?? "-"))}</td>
<td>${htmlEscape(c.howArrived || "-")}</td>
<td>${htmlEscape(c.nextAction || "-")}</td>
<td>${htmlEscape(r.conversation?.id || d.conversationId || "-")}</td>
</tr>`;
  }).join("");

  return `<!doctype html><html><head><meta charset="utf-8"/>
<title>CRM Cómo llegaron al Horno ${htmlEscape(data.date)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}
.box{border:1px solid #e5e7eb;border-radius:14px;padding:16px;background:#fafafa}.metric{font-size:30px;font-weight:800}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff;margin-top:18px}td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}th{background:#f9fafb}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
</style></head><body><div class="card">
<h1>Reporte CRM — Cómo llegaron al ${htmlEscape(data.stage)}</h1>
<p><b>Fecha:</b> ${htmlEscape(data.date)} · <b>Vendedor:</b> ${htmlEscape(data.filters?.owner || "Todos")}</p>
<div class="grid">
<div class="box"><h3>Evaluados</h3><div class="metric">${data.rows?.length || 0}</div></div>
<div class="box"><h3>Alta</h3><div class="metric">${(data.rows || []).filter(r => r.closing?.level === "Alta").length}</div></div>
<div class="box"><h3>Media</h3><div class="metric">${(data.rows || []).filter(r => r.closing?.level === "Media").length}</div></div>
<div class="box"><h3>Baja</h3><div class="metric">${(data.rows || []).filter(r => r.closing?.level === "Baja").length}</div></div>
</div>
<pre>${htmlEscape(reportText)}</pre>
<table><thead><tr><th>#</th><th>Trato</th><th>Vendedor</th><th>Valor</th><th>Cierre</th><th>Score</th><th>Cómo llegó</th><th>Próxima acción</th><th>Chat</th></tr></thead><tbody>${rows || '<tr><td colspan="9">Sin tratos detectados.</td></tr>'}</tbody></table>
</div></body></html>`;
}

async function crmGetStageOpportunitiesReport({ date, stage, owner, limit, analyzeMissing, useCache }) {
  const reportId = crmStageOpportunitiesDocId(date, stage, owner);

  if (useCache && !analyzeMissing) {
    const cached = await db.collection("supervisor_reports").doc(reportId).get();
    if (cached.exists) {
      const data = cached.data() || {};
      return { ...data, fromCache: true, reportId };
    }
  }

  const built = await crmBuildStageOpportunityRows({ date, stage, owner, limit, analyzeMissing });
  const rows = built.rows || [];
  const cacheCount = rows.filter(r => r.fromCache).length;

  const data = {
    ok: true,
    type: "crm_stage_opportunities",
    date,
    stage,
    filters: { owner: owner || "", limit },
    stageCount: built.stageData?.count || 0,
    rows,
    processedCount: built.processed.length,
    cacheCount,
    skippedCount: built.skipped.length,
    errorCount: built.errors.length,
    processed: built.processed,
    skipped: built.skipped,
    errors: built.errors,
    generatedAt: new Date().toISOString()
  };

  const managerReport = crmBuildStageOpportunitiesReport(data);

  await db.collection("supervisor_reports").doc(reportId).set({
    ...data,
    managerReport,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { ...data, managerReport, fromCache: false, reportId };
}

app.get("/api/crm/stage-opportunities", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const stage = String(req.query.stage || "Horno").trim() || "Horno";
    const owner = String(req.query.owner || "").trim();
    const limit = Math.min(Math.max(Number(req.query.limit || 30), 1), 50);
    const analyzeMissing = String(req.query.analyze || "") === "1";
    const refresh = String(req.query.refresh || "") === "1";

    const data = await crmGetStageOpportunitiesReport({ date, stage, owner, limit, analyzeMissing, useCache: !refresh });

    res.json({
      ok: true,
      mode: "crm_stage_opportunities_using_existing_analyzeWithAI_and_cache",
      reportId: data.reportId,
      fromCache: !!data.fromCache,
      date: data.date,
      stage: data.stage,
      filters: data.filters,
      stageCount: data.stageCount,
      processedCount: data.processedCount,
      cacheCount: data.cacheCount,
      skippedCount: data.skippedCount,
      errorCount: data.errorCount,
      opportunitiesPreview: (data.rows || []).slice(0, 50),
      managerReport: data.managerReport,
      note: "Usa IA solo si el chat vinculado no tiene supervisor_reviews. Reutiliza analyzeWithAI()."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/crm/stage-opportunities/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const stage = String(req.query.stage || "Horno").trim() || "Horno";
    const owner = String(req.query.owner || "").trim();
    const limit = Math.min(Math.max(Number(req.query.limit || 30), 1), 50);
    const analyzeMissing = String(req.query.analyze || "") === "1";
    const refresh = String(req.query.refresh || "") === "1";

    const data = await crmGetStageOpportunitiesReport({ date, stage, owner, limit, analyzeMissing, useCache: !refresh });
    const reportText = data.managerReport || crmBuildStageOpportunitiesReport(data);
    const reportHtml = crmStageOpportunitiesHtml(data, reportText);

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="crm-como-llegaron-${safeFileName(stage)}-${date}-${safeFileName(owner || "all")}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(reportText, { name: "00_RESUMEN_COMO_LLEGARON_AL_HORNO.txt" });
    archive.append(reportHtml, { name: "00_RESUMEN_COMO_LLEGARON_AL_HORNO.html" });
    archive.append(JSON.stringify(data, null, 2), { name: "00_DATA.json" });

    (data.rows || []).forEach((r, idx) => {
      const d = r.deal || {};
      const c = r.closing || {};
      const prefix = String(idx + 1).padStart(2, "0");
      const txt = `SCB — CÓMO LLEGÓ AL ${data.stage}
========================================

Fecha reporte: ${data.date}
Deal ID: ${d.id || "-"}
Trato: ${d.title || "-"}
Cliente: ${d.contactName || "-"}
Vendedor: ${d.owner || "-"}
Valor: ${crmStageMoney(d.value)}
Stage: ${d.stage || "-"}
Entró/actualizado: ${d.movementAt || d.updatedAt || "-"}
Chat: ${r.conversation?.id || d.conversationId || "-"}
Estado análisis: ${r.status || "-"}

POSIBILIDAD DE CIERRE
${c.level || "-"} (${c.score ?? "-"}/100)

CÓMO LLEGÓ
${c.howArrived || "-"}

INTENCIÓN DEL CLIENTE
${c.customerIntent || "-"}

RAZONES
${(c.reasons || []).map(x => "- " + x).join("\n") || "-"}

PUNTOS A CORREGIR
${(c.missedOpportunities || []).map(x => "- " + x).join("\n") || "-"}

PRÓXIMA ACCIÓN RECOMENDADA
${c.nextAction || "-"}

JSON
${JSON.stringify(r, null, 2)}
`;
      archive.append(txt, { name: `tratos/${prefix}_${safeFileName(c.level || "sin_score")}_${safeFileName(d.owner || "sin_vendedor")}_${safeFileName(d.title || d.contactName || d.id)}.txt` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP de informe Horno CRM: " + err.message);
  }
});



// =====================================================
// MANUAL HOURLY SUPERVISOR — NO SCHEDULER
// Separates client, bot and human. Uses AI only for limited human responses and cache.
// =====================================================

function supervisorHourlyDocId(date, hour) {
  return "hourly_manual__" + date + "__" + String(hour).padStart(2, "0");
}

function supervisorHourlyReviewDocId(date, hour, conversationId) {
  return "hourly_review__" + date + "__" + String(hour).padStart(2, "0") + "__" + String(conversationId || "").replace(/[^a-zA-Z0-9_-]/g, "_");
}

function supervisorHourlyRangeArgentina(dateStr, hourValue) {
  const h = Math.min(Math.max(Number(hourValue || 9), 0), 23);
  const localStart = dateStr + "T" + String(h).padStart(2, "0") + ":00:00.000-03:00";
  const from = new Date(localStart);
  const to = new Date(from.getTime() + 60 * 60 * 1000 - 1);
  return { from, to, hour: h, label: String(h).padStart(2, "0") + ":00 a " + String(h + 1).padStart(2, "0") + ":00" };
}

function supervisorInRange(iso, from, to) {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return Number.isFinite(t) && t >= from.getTime() && t <= to.getTime();
}

async function supervisorGetConversationsInHour(date, hour, limit) {
  const range = supervisorHourlyRangeArgentina(date, hour);
  const snap = await db.collection("conversations")
    .where("lastMessageAt", ">=", range.from)
    .where("lastMessageAt", "<=", range.to)
    .orderBy("lastMessageAt", "desc")
    .limit(limit)
    .get();

  return {
    range,
    conversations: snap.docs.map(normalizeConversation).filter(c => supervisorInRange(c.lastMessageAt, range.from, range.to))
  };
}

function supervisorMessageActor(m) {
  return m.actor || detectMessageActor(m);
}


function supervisorCleanPhone(value) {
  return String(value || "").replace(/\D+/g, "");
}

function supervisorPhoneCandidates(conversation) {
  const set = new Set();
  const add = (v) => {
    const raw = String(v || "").trim();
    const digits = supervisorCleanPhone(raw);
    if (digits) {
      set.add(digits);
      set.add("+" + digits);
      if (digits.startsWith("549")) set.add(digits.slice(3));
      if (digits.startsWith("54")) set.add(digits.slice(2));
    }
  };

  add(conversation?.phone);
  add(conversation?.contactId);

  const id = String(conversation?.id || "");
  if (id.includes("__")) add(id.split("__")[0]);
  else add(id);

  return Array.from(set).filter(Boolean).slice(0, 8);
}

function supervisorOwnerFromObject(data) {
  const raw = crmText(data || {}, [
    "ownerName", "ownerDisplayName", "assignedToName", "sellerName", "vendedorName",
    "owner", "ownerEmail", "assignedTo", "seller", "vendedor", "responsible", "agentName", "agent"
  ]);
  return raw.replace(/\s+/g, " ").trim();
}

async function supervisorFindCrmContactOwnerByPhone(conversation, cache) {
  const phones = supervisorPhoneCandidates(conversation);
  if (!phones.length) return null;

  const cacheKey = "phone::" + phones.join("|");
  if (cache && cache.has(cacheKey)) return cache.get(cacheKey);

  const fields = ["phone", "whatsapp", "mobile", "phoneNumber", "waPhone", "normalizedPhone", "phoneE164"];

  for (const phone of phones) {
    try {
      const doc = await dbCRM.collection("contacts").doc(phone).get();
      if (doc.exists) {
        const d = doc.data() || {};
        const owner = supervisorOwnerFromObject(d);
        if (owner) {
          const found = { owner, source: "crm_contact_doc_id", contactId: doc.id };
          if (cache) cache.set(cacheKey, found);
          return found;
        }
      }
    } catch (err) {}
  }

  for (const field of fields) {
    for (const phone of phones) {
      try {
        const snap = await dbCRM.collection("contacts").where(field, "==", phone).limit(1).get();
        if (!snap.empty) {
          const d = snap.docs[0].data() || {};
          const owner = supervisorOwnerFromObject(d);
          if (owner) {
            const found = { owner, source: "crm_contact_" + field, contactId: snap.docs[0].id };
            if (cache) cache.set(cacheKey, found);
            return found;
          }
        }
      } catch (err) {}
    }
  }

  if (cache) cache.set(cacheKey, null);
  return null;
}

async function supervisorResolveHourlyOwner(conversation, messages, row, cache) {
  const human = [...(messages || [])].reverse().find(m => supervisorMessageActor(m) === "human" && m.user);
  if (human?.user) return { owner: human.user, source: "human_message_user" };

  if (conversation?.owner) return { owner: conversation.owner, source: "conversation_owner" };

  if (conversation?.dealId) {
    const dealKey = "deal::" + conversation.dealId;
    try {
      let found = cache?.get(dealKey);
      if (found === undefined) {
        const doc = await dbCRM.collection("deals").doc(String(conversation.dealId)).get();
        if (doc.exists) {
          const d = doc.data() || {};
          const owner = supervisorOwnerFromObject(d);
          found = owner ? { owner, source: "crm_deal", dealId: doc.id } : null;
        } else {
          found = null;
        }
        if (cache) cache.set(dealKey, found);
      }
      if (found?.owner) return found;
    } catch (err) {}
  }

  if (conversation?.contactId) {
    const contactKey = "contact::" + conversation.contactId;
    try {
      let found = cache?.get(contactKey);
      if (found === undefined) {
        const doc = await dbCRM.collection("contacts").doc(String(conversation.contactId)).get();
        if (doc.exists) {
          const d = doc.data() || {};
          const owner = supervisorOwnerFromObject(d);
          found = owner ? { owner, source: "crm_contact_id", contactId: doc.id } : null;
        } else {
          found = null;
        }
        if (cache) cache.set(contactKey, found);
      }
      if (found?.owner) return found;
    } catch (err) {}
  }

  const byPhone = await supervisorFindCrmContactOwnerByPhone(conversation, cache);
  if (byPhone?.owner) return byPhone;

  const fallback = row?.owner || row?.seller || "";
  if (fallback && fallback !== "sin vendedor" && fallback !== "No detectado") {
    return { owner: fallback, source: "row_fallback" };
  }

  return { owner: "No detectado", source: "not_found" };
}

function supervisorSellerName(conversation, messages) {
  const human = [...(messages || [])].reverse().find(m => supervisorMessageActor(m) === "human" && m.user);
  return human?.user || conversation.owner || "";
}

function supervisorAnalyzeHourlyConversation(conversation, messages, range, lateMinutes) {
  const all = (messages || [])
    .filter(m => m.timestamp)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const inWindow = all.filter(m => supervisorInRange(m.timestamp, range.from, range.to));
  const inbound = inWindow.filter(m => supervisorMessageActor(m) === "client");
  const bot = inWindow.filter(m => supervisorMessageActor(m) === "bot");
  const human = inWindow.filter(m => supervisorMessageActor(m) === "human");
  const outboundUnknown = inWindow.filter(m => supervisorMessageActor(m) === "outbound_unknown");
  const seller = supervisorSellerName(conversation, all);

  const lastInWindow = inWindow[inWindow.length - 1] || null;
  const lastClientInWindow = [...inWindow].reverse().find(m => supervisorMessageActor(m) === "client") || null;
  const lastHumanInWindow = [...inWindow].reverse().find(m => supervisorMessageActor(m) === "human") || null;
  const lastBotInWindow = [...inWindow].reverse().find(m => supervisorMessageActor(m) === "bot") || null;

  const lastClientAll = [...all].reverse().find(m => supervisorMessageActor(m) === "client") || null;
  const lastHumanAll = [...all].reverse().find(m => supervisorMessageActor(m) === "human") || null;
  const humanAfterLastClient = lastClientAll
    ? all.filter(m => supervisorMessageActor(m) === "human" && new Date(m.timestamp).getTime() > new Date(lastClientAll.timestamp).getTime())
    : [];
  const followUpAttemptsAfterLastClient = humanAfterLastClient.length;
  const followUpAttemptsInWindow = humanAfterLastClient.filter(m => supervisorInRange(m.timestamp, range.from, range.to)).length;
  const sellerFollowUpInWindow = inWindow.filter(m => supervisorMessageActor(m) === "human").length > 0 && inbound.length === 0 && !!lastClientAll;
  const readyToDiscardNoResponse = followUpAttemptsAfterLastClient >= 10 && !!lastClientAll && (!lastHumanAll || new Date(lastHumanAll.timestamp).getTime() > new Date(lastClientAll.timestamp).getTime());
  const followUpOk = sellerFollowUpInWindow && followUpAttemptsAfterLastClient > 0 && followUpAttemptsAfterLastClient < 10;
  const daysSinceLastClient = lastClientAll ? Math.floor((range.to.getTime() - new Date(lastClientAll.timestamp).getTime()) / (24 * 60 * 60 * 1000)) : null;

  const responseTimes = [];
  const lateResponses = [];
  let pendingClientMessages = 0;

  for (let i = 0; i < inWindow.length; i++) {
    const m = inWindow[i];
    if (supervisorMessageActor(m) !== "client") continue;
    const nextHuman = inWindow.slice(i + 1).find(x => supervisorMessageActor(x) === "human");
    const nextAnyOut = inWindow.slice(i + 1).find(x => ["human", "bot", "outbound_unknown"].includes(supervisorMessageActor(x)));

    if (nextHuman) {
      const mins = qaMinutesBetween(m.timestamp, nextHuman.timestamp);
      if (mins !== null && mins >= 0) {
        responseTimes.push(mins);
        if (mins > lateMinutes) {
          lateResponses.push({
            inboundAt: m.timestamp,
            humanAt: nextHuman.timestamp,
            minutes: mins,
            customerText: (m.text || "").slice(0, 240),
            humanText: (nextHuman.text || "").slice(0, 240),
            seller: nextHuman.user || seller
          });
        }
      }
    } else if (!nextAnyOut || supervisorMessageActor(nextAnyOut) === "bot") {
      pendingClientMessages += 1;
    }
  }

  const avgHumanResponseMinutes = responseTimes.length
    ? Math.round(responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length)
    : null;
  const maxHumanResponseMinutes = responseTimes.length ? Math.max(...responseTimes) : null;

  const humanResponded = human.length > 0;
  const botOnly = inbound.length > 0 && bot.length > 0 && !humanResponded;
  const noHumanResponse = inbound.length > 0 && !humanResponded;
  const lastIsClient = lastInWindow && supervisorMessageActor(lastInWindow) === "client";
  const needsHumanNow = botOnly || noHumanResponse || lastIsClient || pendingClientMessages > 0;

  return {
    conversationId: conversation.id,
    contactName: conversation.contactName || conversation.phone || "sin dato",
    phone: conversation.phone || "",
    lineId: conversation.lineId || conversation.inboundTo || "",
    owner: conversation.owner || seller || "No detectado",
    seller: seller || conversation.owner || "No detectado",
    stage: conversation.stage || "",
    dealId: conversation.dealId || "",
    sourceChannel: conversation.sourceChannel || conversation.leadPlatform || "",
    lastMessageAt: conversation.lastMessageAt || "",
    messagesInWindow: inWindow.length,
    inboundCount: inbound.length,
    botCount: bot.length,
    humanCount: human.length,
    outboundUnknownCount: outboundUnknown.length,
    humanResponded,
    botOnly,
    noHumanResponse,
    needsHumanNow,
    pendingClientMessages,
    avgHumanResponseMinutes,
    maxHumanResponseMinutes,
    lateCount: lateResponses.length,
    lateResponses,
    lastActor: lastInWindow ? supervisorMessageActor(lastInWindow) : "",
    lastClientAt: lastClientInWindow?.timestamp || "",
    lastHumanAt: lastHumanInWindow?.timestamp || "",
    lastBotAt: lastBotInWindow?.timestamp || "",
    lastClientAnyAt: lastClientAll?.timestamp || "",
    lastHumanAnyAt: lastHumanAll?.timestamp || "",
    followUpAttemptsAfterLastClient,
    followUpAttemptsInWindow,
    sellerFollowUpInWindow,
    followUpOk,
    readyToDiscardNoResponse,
    daysSinceLastClient,
    lastClientText: (lastClientInWindow?.text || "").slice(0, 300),
    lastHumanText: (lastHumanInWindow?.text || "").slice(0, 300),
    lastBotText: (lastBotInWindow?.text || "").slice(0, 300),
    humanTexts: human.slice(-3).map(m => ({ at: m.timestamp, user: m.user || seller, text: (m.text || "").slice(0, 500) })),
    botTexts: bot.slice(-3).map(m => ({ at: m.timestamp, text: (m.text || "").slice(0, 500) }))
  };
}

function supervisorHourlyNeedsAi(row) {
  if (!row.humanResponded) return false;
  if (!row.humanTexts || !row.humanTexts.length) return false;
  if (row.lateCount > 0) return true;
  if (row.inboundCount > 0) return true;
  return false;
}

async function supervisorGetHourlyCachedReview(date, hour, conversationId) {
  const id = supervisorHourlyReviewDocId(date, hour, conversationId);
  const doc = await db.collection("supervisor_reviews").doc(id).get();
  if (doc.exists) return { id: doc.id, data: doc.data() || {} };
  return null;
}

async function supervisorSaveHourlyReview({ date, hour, conversation, messages, aiReview, error }) {
  const reviewId = supervisorHourlyReviewDocId(date, hour, conversation.id);
  const item = {
    ok: !error,
    type: "hourly_manual_chat_review",
    date,
    hour: Number(hour),
    conversationId: conversation.id,
    contactName: conversation.contactName || conversation.phone || null,
    phone: conversation.phone || null,
    owner: conversation.owner || null,
    lineId: conversation.lineId || conversation.inboundTo || null,
    source: "hourly_manual_supervisor",
    lastMessageAt: conversation.lastMessageAt || null
  };

  if (error) {
    item.error = error;
  } else {
    item.result = aiReview.result;
    item.score = aiReview.overall_score;
    item.risk = aiReview.risk_level;
    item.reason = reviewReason(aiReview);
    item.nextBestReply = aiReview.next_best_reply;
    item.aiReview = aiReview;
  }

  await db.collection("supervisor_reviews").doc(reviewId).set({
    ...item,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { id: reviewId, data: { ...item, updatedAt: new Date().toISOString() } };
}

function supervisorReviewBool(review, key) {
  const v = review?.[key] ?? review?.aiReview?.[key];
  if (typeof v === "boolean") return v;
  if (typeof v === "string") return ["true", "si", "sí", "yes", "1"].includes(v.trim().toLowerCase());
  return false;
}

function supervisorCommercialDiscoveryLevel(review) {
  const level = String(review?.commercial_discovery_level || review?.aiReview?.commercial_discovery_level || "").trim().toLowerCase();
  if (["alto", "medio", "bajo", "nulo"].includes(level)) return level;
  return "sin_dato";
}

function supervisorCommercialRisk(review) {
  const risk = String(review?.commercial_risk || review?.aiReview?.commercial_risk || "").trim().toLowerCase();
  if (["alto", "medio", "bajo"].includes(risk)) return risk;
  return "sin_dato";
}

function supervisorApplyAiToHourlyRow(row, review) {
  if (!review) return row;
  const score = crmReviewScore(review);
  const risk = crmReviewRisk(review);
  const result = String(review.result || review.aiReview?.result || "").toLowerCase();
  const bad = crmReviewArray(review, "bad_points");
  const missed = crmReviewArray(review, "missed_opportunities");
  const missedDiscovery = crmReviewArray(review, "missed_discovery_questions");
  const discoveryLevel = supervisorCommercialDiscoveryLevel(review);
  const commercialRisk = supervisorCommercialRisk(review);
  const didAskBusinessContext = supervisorReviewBool(review, "did_ask_business_context");
  const didAskImportExperience = supervisorReviewBool(review, "did_ask_import_experience");
  const didAskVolumePotential = supervisorReviewBool(review, "did_ask_volume_potential");
  const didDetectCustomerProfile = supervisorReviewBool(review, "did_detect_customer_profile");
  const operationalWithoutDiscovery =
    supervisorReviewBool(review, "operational_without_discovery") ||
    (row.humanResponded && ["bajo", "nulo"].includes(discoveryLevel) && !didAskBusinessContext && !didAskVolumePotential);
  const unexploredPotential = supervisorReviewBool(review, "unexplored_potential") || missedDiscovery.length > 0;
  const goodCommercialResponse =
    row.humanResponded &&
    ["alto", "medio"].includes(discoveryLevel) &&
    (didAskBusinessContext || didAskVolumePotential || didAskImportExperience || didDetectCustomerProfile) &&
    commercialRisk !== "alto" &&
    result !== "mal";

  const needsReview =
    result === "mal" ||
    risk === "alto" ||
    commercialRisk === "alto" ||
    operationalWithoutDiscovery ||
    unexploredPotential ||
    (score !== null && score < 65) ||
    bad.length > 0;

  return {
    ...row,
    ai: {
      result: result || "sin análisis",
      score,
      risk: risk || "sin riesgo",
      reason: crmExecutiveReason(review),
      action: crmExecutiveAction(review),
      badPoints: bad,
      missedOpportunities: missed,
      summary: crmReviewText(review, "summary"),
      commercialDiscoveryLevel: discoveryLevel,
      didAskBusinessContext,
      didAskImportExperience,
      didAskVolumePotential,
      didDetectCustomerProfile,
      customerProfileGuess: crmReviewText(review, "customer_profile_guess") || "desconocido",
      missedDiscoveryQuestions: missedDiscovery,
      commercialRisk,
      salesCoaching: crmReviewText(review, "sales_coaching"),
      operationalWithoutDiscovery,
      unexploredPotential,
      goodCommercialResponse
    },
    needsReviewByAi: needsReview,
    operationalWithoutDiscovery,
    unexploredPotential,
    goodCommercialResponse,
    commercialDiscoveryLevel: discoveryLevel,
    commercialRisk
  };
}

function supervisorHourlyStatus(row) {
  if (row.excludedFromReport) return "EXCLUIDO";
  if (row.readyToDiscardNoResponse) return "DESCARTAR SIN RESPUESTA";
  if (row.followUpOk) return "SEGUIMIENTO OK";
  if (row.businessCloseGrace) return "PENDIENTE CIERRE";
  if (row.respondedOutsideBusinessHours) return "RESPUESTA FUERA DE HORARIO";
  if (row.operationalWithoutDiscovery) return "RESPONDIÓ SIN INDAGAR";
  if (row.unexploredPotential) return "POTENCIAL NO EXPLORADO";
  if (row.needsReviewByAi) return "REVISAR RESPUESTA";
  if (row.noHumanResponse) return "SIN RESPUESTA HUMANA";
  if (row.botOnly) return "SOLO BOT";
  if (row.lateCount > 0) return "RESPUESTA TARDE";
  if (row.goodCommercialResponse) return "BUENA RESPUESTA COMERCIAL";
  if (row.humanResponded) return "RESPONDIDO OK";
  if (row.inboundCount > 0) return "CLIENTE ACTIVO";
  return "SIN ACCIÓN";
}

function supervisorHourlyStatusColor(status) {
  if (["RESPONDIÓ SIN INDAGAR", "POTENCIAL NO EXPLORADO", "REVISAR RESPUESTA", "SIN RESPUESTA HUMANA"].includes(status)) return "#dc2626";
  if (["DESCARTAR SIN RESPUESTA", "SOLO BOT", "RESPUESTA TARDE", "RESPUESTA FUERA DE HORARIO", "CLIENTE ACTIVO", "PENDIENTE CIERRE"].includes(status)) return "#d97706";
  if (["SEGUIMIENTO OK", "BUENA RESPUESTA COMERCIAL", "RESPONDIDO OK"].includes(status)) return "#16a34a";
  return "#6b7280";
}

function supervisorHourlyAction(row) {
  if (row.excludedFromReport) return "No computa en el desempeño comercial.";
  if (row.readyToDiscardNoResponse) return "Ya tiene 10 o más intentos de seguimiento sin respuesta del cliente. Revisar y descartar/mover etapa si corresponde.";
  if (row.followUpOk) return "Buen seguimiento: el vendedor recontactó al cliente. Mantener cadencia hasta 5-10 intentos; si no responde, descartar.";
  if (row.businessCloseGrace) return "No marcar como incumplimiento: el cliente escribió cerca del cierre del horario laboral. Retomar en el próximo horario de atención.";
  if (row.respondedOutsideBusinessHours) return "Respondió humano, pero fuera del horario evaluado. No es sin respuesta; revisar demora y si corresponde ajustar seguimiento.";
  if (row.operationalWithoutDiscovery) {
    const questions = row.ai?.missedDiscoveryQuestions || [];
    return row.ai?.salesCoaching || (questions.length ? "Recontactar e indagar: " + questions.slice(0, 2).join(" / ") : "Recontactar y preguntar negocio real: uso propio/reventa, si ya importa, volumen potencial y qué miedo u objeción tiene.");
  }
  if (row.unexploredPotential) return row.ai?.salesCoaching || "Revisar potencial no explorado: preguntar si es distribuidor/comercio/fábrica, volumen estimado y si busca prueba o compra recurrente.";
  if (row.ai?.action) return row.ai.action;
  if (row.needsReviewByAi) return "Revisar la respuesta humana y corregir el seguimiento comercial.";
  if (row.noHumanResponse) return "Responder ahora: el cliente escribió y no hay intervención humana.";
  if (row.botOnly) return "Intervenir manualmente: el bot respondió, pero falta vendedor humano.";
  if (row.lateCount > 0) return "Revisar demora y actualizar CRM con próxima acción.";
  if (row.goodCommercialResponse) return "Buen enfoque: mantener seguimiento y dejar próxima acción cargada en CRM.";
  if (row.humanResponded) return "Controlar que el CRM tenga próxima acción y fecha.";
  return "Sin acción urgente.";
}

function supervisorBuildHourlySummary(rows) {
  const bySeller = new Map();
  for (const r of rows) {
    const seller = r.seller || r.owner || "No detectado";
    const item = bySeller.get(seller) || {
      seller,
      activeChats: 0,
      clientChats: 0,
      humanResponded: 0,
      botOnly: 0,
      noHumanResponse: 0,
      late: 0,
      needsHumanNow: 0,
      needsReviewByAi: 0,
      okHuman: 0,
      goodCommercial: 0,
      operationalWithoutDiscovery: 0,
      unexploredPotential: 0,
      lowDiscovery: 0,
      followUpOk: 0,
      readyToDiscardNoResponse: 0,
      maxDelayMinutes: 0,
      lastClients: []
    };

    const hasClient = (Number(r.inboundCount || 0) > 0);
    item.activeChats += 1;
    if (hasClient) item.clientChats += 1;
    if (r.humanResponded) item.humanResponded += 1;
    if (r.botOnly) item.botOnly += 1;
    if (r.noHumanResponse) item.noHumanResponse += 1;
    if (r.lateCount > 0) item.late += 1;
    if (r.needsHumanNow) item.needsHumanNow += 1;
    if (r.needsReviewByAi) item.needsReviewByAi += 1;
    if (r.goodCommercialResponse) item.goodCommercial += 1;
    if (r.operationalWithoutDiscovery) item.operationalWithoutDiscovery += 1;
    if (r.unexploredPotential) item.unexploredPotential += 1;
    if (r.followUpOk) item.followUpOk += 1;
    if (r.readyToDiscardNoResponse) item.readyToDiscardNoResponse += 1;
    if (["bajo", "nulo"].includes(String(r.commercialDiscoveryLevel || r.ai?.commercialDiscoveryLevel || "").toLowerCase())) item.lowDiscovery += 1;
    if (r.humanResponded && !r.needsReviewByAi && !(r.lateCount > 0)) item.okHuman += 1;
    if (Number.isFinite(Number(r.maxHumanResponseMinutes))) item.maxDelayMinutes = Math.max(item.maxDelayMinutes, Number(r.maxHumanResponseMinutes));
    if (hasClient && item.lastClients.length < 5) item.lastClients.push(r.contactName || r.phone || r.conversationId);
    bySeller.set(seller, item);
  }

  return Array.from(bySeller.values()).map(s => {
    const responseRate = s.clientChats ? Math.round((s.humanResponded / s.clientChats) * 100) : null;
    const reviewRate = s.humanResponded ? Math.round((s.needsReviewByAi / s.humanResponded) * 100) : 0;
    let evaluation = "OK";
    if (s.noHumanResponse > 0 || s.needsReviewByAi > 0 || s.operationalWithoutDiscovery > 0 || s.unexploredPotential > 0 || s.readyToDiscardNoResponse > 0) evaluation = "REVISAR";
    if (s.clientChats >= 1 && s.humanResponded === 0 && s.followUpOk === 0 && s.readyToDiscardNoResponse === 0) evaluation = "URGENTE";
    return { ...s, responseRate, reviewRate, evaluation };
  }).sort((a, b) => {
    const order = { URGENTE: 0, REVISAR: 1, OK: 2 };
    return (order[a.evaluation] ?? 9) - (order[b.evaluation] ?? 9) ||
      b.noHumanResponse - a.noHumanResponse ||
      b.operationalWithoutDiscovery - a.operationalWithoutDiscovery ||
      b.unexploredPotential - a.unexploredPotential ||
      b.needsReviewByAi - a.needsReviewByAi ||
      b.clientChats - a.clientChats;
  });
}

function supervisorBuildHourlyReport(data) {
  const rows = data.rows || [];
  const bySeller = data.bySeller || [];
  const noHuman = rows.filter(r => r.noHumanResponse);
  const botOnly = rows.filter(r => r.botOnly);
  const late = rows.filter(r => r.lateCount > 0);
  const needsReview = rows.filter(r => r.needsReviewByAi);
  const human = rows.filter(r => r.humanResponded);
  const okHuman = rows.filter(r => r.humanResponded && !r.needsReviewByAi && !(r.lateCount > 0));
  const goodCommercial = rows.filter(r => r.goodCommercialResponse);
  const operationalNoDiscovery = rows.filter(r => r.operationalWithoutDiscovery);
  const unexploredPotential = rows.filter(r => r.unexploredPotential);
  const lowDiscovery = rows.filter(r => ["bajo", "nulo"].includes(String(r.commercialDiscoveryLevel || r.ai?.commercialDiscoveryLevel || "").toLowerCase()));
  const clientChats = rows.filter(r => Number(r.inboundCount || 0) > 0);

  const sellerRows = bySeller.map((s, i) => `${i + 1}) ${s.seller} — ${s.evaluation}
   Clientes activos: ${s.clientChats}
   Respondió humano: ${s.humanResponded}${s.responseRate === null ? "" : " (" + s.responseRate + "% de clientes con respuesta humana)"}
   Bien / sin alerta: ${s.okHuman}
   Buena respuesta comercial: ${s.goodCommercial}
   Respondió operativo sin indagar: ${s.operationalWithoutDiscovery}
   Potencial no explorado: ${s.unexploredPotential}
   Baja/nula indagación: ${s.lowDiscovery}
   Seguimientos correctos: ${s.followUpOk}
   Para descartar por no respuesta: ${s.readyToDiscardNoResponse}
   A revisar por IA: ${s.needsReviewByAi}
   Sin respuesta humana: ${s.noHumanResponse}
   Solo bot: ${s.botOnly}
   Respuestas tarde: ${s.late}
   Máxima demora: ${qaFormatMinutes(s.maxDelayMinutes || null)}
   Clientes ejemplo: ${(s.lastClients || []).join(" | ") || "-"}`).join("\n\n");

  const urgentRows = rows
    .filter(r => r.needsHumanNow || r.needsReviewByAi || r.lateCount > 0)
    .sort((a, b) => {
      const rank = x => x.operationalWithoutDiscovery ? 1 : x.unexploredPotential ? 2 : x.needsReviewByAi ? 3 : x.noHumanResponse ? 4 : x.botOnly ? 5 : x.lateCount > 0 ? 6 : 9;
      return rank(a) - rank(b);
    })
    .slice(0, 40)
    .map((r, i) => `${i + 1}) ${supervisorHourlyStatus(r)} — ${r.contactName}
   Vendedor: ${r.seller || r.owner || "No detectado"}
   Cliente escribió: ${r.lastClientText || "-"}
   Bot: ${r.lastBotText || "-"}
   Humano: ${r.lastHumanText || "-"}
   Demora máx humano: ${qaFormatMinutes(r.maxHumanResponseMinutes)}
   Calidad IA: ${r.ai?.result || "sin análisis"} · Score: ${r.ai?.score ?? "-"} · Riesgo: ${r.ai?.risk || "-"}
   Indagación comercial: ${r.ai?.commercialDiscoveryLevel || r.commercialDiscoveryLevel || "sin dato"} · Riesgo comercial: ${r.ai?.commercialRisk || r.commercialRisk || "sin dato"}
   Perfil estimado: ${r.ai?.customerProfileGuess || "desconocido"}
   Motivo: ${r.ai?.reason || "-"}
   Coaching ventas: ${r.ai?.salesCoaching || "-"}
   Acción concreta: ${supervisorHourlyAction(r)}
   Chat: ${r.conversationId}`).join("\n\n");

  const bestRows = okHuman.slice(0, 20).map((r, i) => `${i + 1}) ${r.contactName} — ${r.seller || r.owner || "No detectado"}
   Humano: ${r.lastHumanText || "-"}
   Chat: ${r.conversationId}`).join("\n\n");

  const urgentSellers = bySeller.filter(s => s.evaluation === "URGENTE").map(s => s.seller).join(", ") || "-";
  const reviewSellers = bySeller.filter(s => s.evaluation === "REVISAR").map(s => s.seller).join(", ") || "-";

  return `📊 SCB SUPERVISOR — REPORTE HORARIO GERENCIAL
Fecha: ${data.date}
Franja: ${data.hourLabel} Argentina

RESUMEN EJECUTIVO
- Conversaciones activas: ${rows.length}
- Conversaciones donde escribió el cliente: ${clientChats.length}
- Respondidas por humano: ${human.length}
- Respondidas bien / sin alerta: ${okHuman.length}
- Buenas respuestas comerciales: ${goodCommercial.length}
- Respuestas operativas sin indagar: ${operationalNoDiscovery.length}
- Clientes con potencial no explorado: ${unexploredPotential.length}
- Chats con baja/nula indagación: ${lowDiscovery.length}
- Respondidas solo por bot: ${botOnly.length}
- Sin respuesta humana: ${noHuman.length}
- Respuestas tarde: ${late.length}
- Respuestas a revisar por IA: ${needsReview.length}
- Seguimientos correctos del vendedor: ${followUpOk.length}
- Para descartar por no respuesta luego de seguimiento: ${readyToDiscard.length}
- Excluidos por empleo/CV: ${excludedJob.length}
- Excluidos por basura@sentirecustomsbroker.com: ${excludedTrash.length}
- Chats analizados con IA ahora/cache: ${data.aiUsedCount || 0}
- Consultas cerca del cierre no marcadas como incumplimiento: ${rows.filter(r => r.businessCloseGrace).length}

QUIÉN NECESITA ATENCIÓN
- Vendedores urgentes: ${urgentSellers}
- Vendedores a revisar: ${reviewSellers}

RENDIMIENTO POR VENDEDOR
${sellerRows || "-"}

CASOS QUE REQUIEREN ACCIÓN
${urgentRows || "Sin casos urgentes detectados."}

RESPUESTAS HUMANAS OK
${bestRows || "No se detectaron respuestas humanas OK en esta franja."}

LECTURA GERENCIAL
${noHuman.length ? "- Hay clientes que escribieron y todavía no tienen respuesta humana." : "- No se detectaron clientes sin respuesta humana en la franja."}
${botOnly.length ? "- Hay chats atendidos solo por bot; si el cliente mostró interés, debe entrar un vendedor." : "- No hay volumen relevante de chats solo bot."}
${operationalNoDiscovery.length ? "- Hay vendedores que responden de forma operativa sin indagar el negocio del cliente." : "- No se detectó volumen relevante de respuestas operativas sin indagación."}
${unexploredPotential.length ? "- Hay clientes con potencial comercial no explorado; pueden ser importadores/distribuidores/comercios tratados como consultas chicas." : "- No se detectó potencial comercial no explorado en la muestra."}
${needsReview.length ? "- Hay respuestas humanas que conviene revisar por calidad comercial." : "- No se detectaron respuestas humanas problemáticas en la muestra analizada."}

ACCIONES SUGERIDAS
1) Responder primero los casos SIN RESPUESTA HUMANA.
2) Revisar los chats SOLO BOT con intención comercial.
3) Auditar RESPONDIÓ SIN INDAGAR: el vendedor debe descubrir negocio, volumen, experiencia importando y miedo/objeción.
4) Revisar POTENCIAL NO EXPLORADO: puede haber distribuidores/importadores grandes detrás de una consulta chica.
5) Auditar los casos REVISAR RESPUESTA y corregir el mensaje al cliente.
6) Pedir a cada vendedor que actualice CRM con próxima acción y fecha.
7) Usar este reporte por hora para controlar venta consultiva, no solo cantidad de mensajes.`;
}

function supervisorHourlyHtml(data, reportText) {
  const sellerRows = (data.bySeller || []).map((s, i) => {
    const color = s.evaluation === "URGENTE" ? "#dc2626" : s.evaluation === "REVISAR" ? "#d97706" : "#16a34a";
    return `<tr>
<td>${i + 1}</td>
<td style="font-weight:bold;color:${color}">${htmlEscape(s.evaluation)}</td>
<td>${htmlEscape(s.seller)}</td>
<td>${htmlEscape(s.clientChats)}</td>
<td>${htmlEscape(s.humanResponded)}</td>
<td>${htmlEscape(s.okHuman)}</td>
<td>${htmlEscape(s.goodCommercial)}</td>
<td>${htmlEscape(s.operationalWithoutDiscovery)}</td>
<td>${htmlEscape(s.unexploredPotential)}</td>
<td>${htmlEscape(s.lowDiscovery)}</td>
<td>${htmlEscape(s.followUpOk)}</td>
<td>${htmlEscape(s.readyToDiscardNoResponse)}</td>
<td>${htmlEscape(s.needsReviewByAi)}</td>
<td>${htmlEscape(s.noHumanResponse)}</td>
<td>${htmlEscape(s.botOnly)}</td>
<td>${htmlEscape(s.late)}</td>
<td>${htmlEscape(s.responseRate === null ? "-" : s.responseRate + "%")}</td>
<td>${htmlEscape(qaFormatMinutes(s.maxDelayMinutes || null))}</td>
</tr>`;
  }).join("");

  const rows = (data.rows || []).map((r, i) => {
    const status = supervisorHourlyStatus(r);
    const color = supervisorHourlyStatusColor(status);
    return `<tr>
<td>${i + 1}</td>
<td style="font-weight:bold;color:${color}">${htmlEscape(status)}</td>
<td>${htmlEscape(r.contactName)}</td>
<td>${htmlEscape(r.seller || r.owner || "No detectado")}</td>
<td>${htmlEscape(r.inboundCount)}</td>
<td>${htmlEscape(r.botCount)}</td>
<td>${htmlEscape(r.humanCount)}</td>
<td>${htmlEscape(qaFormatMinutes(r.maxHumanResponseMinutes))}</td>
<td>${htmlEscape(r.ai?.result || "-")}</td>
<td>${htmlEscape(r.ai?.score ?? "-")}</td>
<td>${htmlEscape(r.ai?.commercialDiscoveryLevel || r.commercialDiscoveryLevel || "-")}</td>
<td>${htmlEscape(r.ai?.commercialRisk || r.commercialRisk || "-")}</td>
<td>${htmlEscape(r.ai?.customerProfileGuess || "-")}</td>
<td>${htmlEscape(r.ai?.reason || "-")}</td>
<td>${htmlEscape(supervisorHourlyAction(r))}</td>
<td>${htmlEscape(r.conversationId)}</td>
</tr>`;
  }).join("");

  return `<!doctype html><html><head><meta charset="utf-8"/>
<title>Supervisor horario ${htmlEscape(data.date)} ${htmlEscape(data.hourLabel)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff;margin-top:18px}
td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}th{background:#f9fafb}
.sectionTitle{margin-top:28px;border-bottom:2px solid #111827;padding-bottom:6px}
</style></head><body><div class="card">
<h1>SCB Supervisor — Reporte horario gerencial</h1>
<p><b>Fecha:</b> ${htmlEscape(data.date)} · <b>Franja:</b> ${htmlEscape(data.hourLabel)} Argentina</p>
<pre>${htmlEscape(reportText)}</pre>
<h2 class="sectionTitle">Rendimiento por vendedor</h2>
<table><thead><tr><th>#</th><th>Evaluación</th><th>Vendedor</th><th>Clientes</th><th>Respondió humano</th><th>Bien</th><th>Buena comercial</th><th>Sin indagar</th><th>Potencial no explorado</th><th>Baja/nula indagación</th><th>Seguimiento OK</th><th>Para descartar</th><th>A revisar</th><th>Sin humano</th><th>Solo bot</th><th>Tarde</th><th>% respuesta</th><th>Demora máx</th></tr></thead><tbody>${sellerRows || '<tr><td colspan="18">Sin vendedores detectados.</td></tr>'}</tbody></table>
<h2 class="sectionTitle">Detalle por cliente</h2>
<table><thead><tr><th>#</th><th>Estado</th><th>Cliente</th><th>Vendedor</th><th>Cliente</th><th>Bot</th><th>Humano</th><th>Demora máx</th><th>IA</th><th>Score</th><th>Indagación</th><th>Riesgo comercial</th><th>Perfil</th><th>Motivo IA</th><th>Acción</th><th>Chat</th></tr></thead><tbody>${rows || '<tr><td colspan="16">Sin conversaciones activas.</td></tr>'}</tbody></table>
</div></body></html>`;
}

function supervisorHourlyCaseTxt(row, data) {
  const status = supervisorHourlyStatus(row);
  const action = supervisorHourlyAction(row);
  return `SCB SUPERVISOR — CASO HORARIO
===============================

Fecha: ${data.date}
Franja: ${data.hourLabel} Argentina
Estado: ${status}
Acción concreta: ${action}

CLIENTE
Nombre: ${row.contactName}
Teléfono: ${row.phone || "-"}
Chat: ${row.conversationId}
Línea: ${row.lineId || "-"}
Origen: ${row.sourceChannel || "-"}
Stage: ${row.stage || "-"}

VENDEDOR / ATENCIÓN
Vendedor detectado: ${row.seller || row.owner || "No detectado"}
Fuente vendedor: ${row.ownerSource || "-"}
Mensajes cliente: ${row.inboundCount}
Mensajes bot: ${row.botCount}
Mensajes humano: ${row.humanCount}
Solo bot: ${row.botOnly ? "sí" : "no"}
Sin respuesta humana: ${row.noHumanResponse ? "sí" : "no"}
Respuesta tarde: ${row.lateCount > 0 ? "sí" : "no"}
Demora máxima humano: ${qaFormatMinutes(row.maxHumanResponseMinutes)}

ÚLTIMO MENSAJE CLIENTE
${row.lastClientText || "-"}

ÚLTIMO MENSAJE BOT
${row.lastBotText || "-"}

ÚLTIMO MENSAJE HUMANO
${row.lastHumanText || "-"}

ANÁLISIS IA
Resultado: ${row.ai?.result || "sin análisis"}
Score: ${row.ai?.score ?? "-"}
Riesgo: ${row.ai?.risk || "-"}
Indagación comercial: ${row.ai?.commercialDiscoveryLevel || row.commercialDiscoveryLevel || "-"}
Riesgo comercial: ${row.ai?.commercialRisk || row.commercialRisk || "-"}
Perfil estimado: ${row.ai?.customerProfileGuess || "desconocido"}
Preguntó contexto de negocio: ${row.ai?.didAskBusinessContext ? "sí" : "no"}
Preguntó experiencia importando: ${row.ai?.didAskImportExperience ? "sí" : "no"}
Preguntó volumen potencial: ${row.ai?.didAskVolumePotential ? "sí" : "no"}
Detectó perfil del cliente: ${row.ai?.didDetectCustomerProfile ? "sí" : "no"}
Respondió operativo sin indagar: ${row.operationalWithoutDiscovery ? "sí" : "no"}
Potencial no explorado: ${row.unexploredPotential ? "sí" : "no"}
Motivo: ${row.ai?.reason || "-"}
Resumen: ${row.ai?.summary || "-"}
Coaching ventas: ${row.ai?.salesCoaching || "-"}
Preguntas de indagación que faltaron: ${(row.ai?.missedDiscoveryQuestions || []).map(x => "- " + x).join("\n") || "-"}
Problemas: ${(row.ai?.badPoints || []).map(x => "- " + x).join("\n") || "-"}
Oportunidades: ${(row.ai?.missedOpportunities || []).map(x => "- " + x).join("\n") || "-"}

JSON
${JSON.stringify(row, null, 2)}
`;
}

async function supervisorBuildHourlyManualData({ date, hour, lateMinutes, limit, analyzeMissing, useCache }) {
  const reportId = supervisorHourlyDocId(date, hour);
  if (useCache && !analyzeMissing) {
    const cached = await db.collection("supervisor_reports").doc(reportId).get();
    if (cached.exists) return { ...(cached.data() || {}), fromCache: true, reportId };
  }

  const fetched = await supervisorGetConversationsInHour(date, hour, limit);
  const rows = [];
  const excludedRows = [];
  const ownerResolveCache = new Map();
  let aiUsedCount = 0;
  const aiErrors = [];

  for (const conversation of fetched.conversations) {
    const messages = await getConversationMessages(conversation.id, 120);
    let row = supervisorAnalyzeHourlyConversation(conversation, messages, fetched.range, lateMinutes);

    const resolvedOwner = await supervisorResolveHourlyOwner(conversation, messages, row, ownerResolveCache);
    row.owner = resolvedOwner.owner || "No detectado";
    row.seller = resolvedOwner.owner || "No detectado";
    row.ownerSource = resolvedOwner.source || "not_found";
    row.crmContactId = resolvedOwner.contactId || row.crmContactId || "";
    row.crmDealId = resolvedOwner.dealId || row.dealId || "";

    const exclusionReason = supervisorDailyExclusionReason(conversation, row, messages);
    if (exclusionReason) {
      excludedRows.push({
        ...row,
        excludedFromReport: true,
        exclusionReason
      });
      continue;
    }

    if (supervisorHourlyNeedsAi(row)) {
      try {
        let cached = await supervisorGetHourlyCachedReview(date, hour, conversation.id);
        if (!cached && analyzeMissing) {
          const aiReview = await analyzeWithAI(conversation, messages);
          cached = await supervisorSaveHourlyReview({ date, hour, conversation, messages, aiReview, error: null });
        }
        if (cached) {
          aiUsedCount += 1;
          row = supervisorApplyAiToHourlyRow(row, cached.data);
          row.aiFromCache = true;
        }
      } catch (err) {
        aiErrors.push({ conversationId: conversation.id, error: err.message });
      }
    }

    rows.push(row);
  }

  const bySeller = supervisorBuildHourlySummary(rows);
  const data = {
    ok: true,
    type: "hourly_manual_supervisor",
    date,
    hour: Number(hour),
    hourLabel: fetched.range.label,
    dateRangeArgentina: { from: fetched.range.from.toISOString(), to: fetched.range.to.toISOString() },
    lateMinutes,
    limit,
    rows,
    excludedRows,
    excludedCount: excludedRows.length,
    bySeller,
    aiUsedCount,
    aiErrors,
    generatedAt: new Date().toISOString()
  };
  const managerReport = supervisorBuildHourlyReport(data);

  await db.collection("supervisor_reports").doc(reportId).set({
    ...data,
    managerReport,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { ...data, managerReport, fromCache: false, reportId };
}

app.get("/api/supervisor/hourly-manual", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const hour = Math.min(Math.max(Number(req.query.hour || 9), 0), 23);
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 30), 5), 180);
    const limit = Math.min(Math.max(Number(req.query.limit || 80), 1), 200);
    const analyzeMissing = String(req.query.analyze || "") === "1";
    const refresh = String(req.query.refresh || "") === "1";

    const data = await supervisorBuildHourlyManualData({ date, hour, lateMinutes, limit, analyzeMissing, useCache: !refresh });

    res.json({
      ok: true,
      mode: "manual_hourly_supervisor_no_scheduler",
      reportId: data.reportId,
      fromCache: !!data.fromCache,
      date: data.date,
      hour: data.hour,
      hourLabel: data.hourLabel,
      totalActiveConversations: (data.rows || []).length,
      businessHours: data.businessHours,
      bySeller: data.bySeller,
      reportsBySeller: (data.reportsBySeller || []).map(x => ({ seller: x.seller, count: x.count, report: x.report })),
      aiUsedCount: data.aiUsedCount,
      aiErrors: data.aiErrors,
      rowsPreview: (data.rows || []).slice(0, 80),
      managerReport: data.managerReport,
      note: "Manual, sin Cloud Scheduler. Separa cliente/bot/humano. IA solo en respuestas humanas con cache."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/hourly-manual/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const hour = Math.min(Math.max(Number(req.query.hour || 9), 0), 23);
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 30), 5), 180);
    const limit = Math.min(Math.max(Number(req.query.limit || 80), 1), 200);

    const data = await supervisorBuildHourlyManualData({ date, hour, lateMinutes, limit, analyzeMissing: false, useCache: true });
    const reportText = data.managerReport || supervisorBuildHourlyReport(data);
    const reportHtml = supervisorHourlyHtml(data, reportText);

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="supervisor-horario-${date}-${String(hour).padStart(2, "0")}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(reportText, { name: "00_RESUMEN_SUPERVISOR_HORARIO.txt" });
    archive.append(reportHtml, { name: "00_RESUMEN_SUPERVISOR_HORARIO.html" });
    archive.append(JSON.stringify(data, null, 2), { name: "00_DATA.json" });

    (data.rows || []).forEach((row, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      const status = row.needsReviewByAi ? "01_REVISAR_RESPUESTA" : row.noHumanResponse ? "02_SIN_RESPUESTA_HUMANA" : row.botOnly ? "03_SOLO_BOT" : row.lateCount > 0 ? "04_RESPUESTAS_TARDE" : "05_OK";
      const fileBase = `${prefix}_${safeFileName(row.seller || row.owner || "No_detectado")}_${safeFileName(row.contactName || row.phone || row.conversationId)}`;
      archive.append(supervisorHourlyCaseTxt(row, data), { name: `${status}/${fileBase}.txt` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP supervisor horario: " + err.message);
  }
});


// =====================================================
// MANUAL DAILY SUPERVISOR — GERENCIAL, NO SCHEDULER
// Uses the same consultative-sales AI logic as the hourly report.
// =====================================================

function supervisorDailyDocId(date, businessStartHour = 9, businessEndHour = 17, lateMinutes = 30, ownerFilters = []) {
  return "daily_manual__" + date + "__" + String(businessStartHour).padStart(2, "0") + "_" + String(businessEndHour).padStart(2, "0") + "__late_" + String(lateMinutes) + "__owners_" + supervisorOwnerFilterKey(ownerFilters);
}

function supervisorDailyReviewDocId(date, conversationId) {
  return "daily_review__" + date + "__" + String(conversationId || "").replace(/[^a-zA-Z0-9_-]/g, "_");
}

function supervisorDailyFullRangeArgentina(dateStr) {
  const from = new Date(dateStr + "T00:00:00.000-03:00");
  const to = new Date(from.getTime() + 24 * 60 * 60 * 1000 - 1);
  return { from, to, label: "Día completo" };
}

function supervisorDailyBusinessRangeArgentina(dateStr, businessStartHour = 9, businessEndHour = 17) {
  const start = Math.min(Math.max(Number(businessStartHour || 9), 0), 23);
  let end = Math.min(Math.max(Number(businessEndHour || 17), start + 1), 24);
  const from = new Date(dateStr + "T" + String(start).padStart(2, "0") + ":00:00.000-03:00");
  const to = new Date(dateStr + "T" + String(end).padStart(2, "0") + ":00:00.000-03:00");
  return {
    from,
    to: new Date(to.getTime() - 1),
    startHour: start,
    endHour: end,
    label: String(start).padStart(2, "0") + ":00 a " + String(end).padStart(2, "0") + ":00"
  };
}

async function supervisorGetConversationsInDay(date, limit) {
  // Lee el día completo para no perder chats que empezaron en horario laboral
  // pero tuvieron último movimiento después de las 17:00. El análisis se hace
  // luego solo dentro del horario laboral configurado.
  const range = supervisorDailyFullRangeArgentina(date);
  const snap = await db.collection("conversations")
    .where("lastMessageAt", ">=", range.from)
    .where("lastMessageAt", "<=", range.to)
    .orderBy("lastMessageAt", "desc")
    .limit(limit)
    .get();

  return {
    range,
    conversations: snap.docs.map(normalizeConversation).filter(c => supervisorInRange(c.lastMessageAt, range.from, range.to))
  };
}

function supervisorApplyBusinessCloseGrace(row, businessRange, lateMinutes) {
  // Si el cliente escribió cerca del cierre, no lo marcamos como "sin respuesta"
  // porque todavía no tuvo una ventana real de atención para contestarle.
  if (!row || !row.lastClientAt || row.humanResponded) return row;
  const lastClientTime = new Date(row.lastClientAt).getTime();
  const closeTime = businessRange.to.getTime();
  if (!Number.isFinite(lastClientTime) || !Number.isFinite(closeTime)) return row;

  const minutesAvailableBeforeClose = Math.max(0, Math.round((closeTime - lastClientTime) / 60000));
  if (minutesAvailableBeforeClose < Number(lateMinutes || 30)) {
    return {
      ...row,
      businessCloseGrace: true,
      minutesAvailableBeforeClose,
      noHumanResponse: false,
      botOnly: false,
      needsHumanNow: false,
      pendingClientMessages: 0
    };
  }
  return row;
}

function supervisorMessageTextForReport(m) {
  const txt = String(m?.text || "").replace(/\s+/g, " ").trim();
  if (txt) return txt;
  if (m?.hasAttachment || m?.media) return "[archivo/adjunto enviado]";
  return "";
}

function supervisorApplyAfterHoursHumanResponse(row, messages, businessRange, lateMinutes) {
  // Caso típico diario: el cliente escribió dentro del horario laboral y el vendedor
  // respondió después de las 17:00 con texto, plantilla humana o PDF/adjunto.
  // No debe quedar como "sin respuesta humana"; debe quedar como respuesta tarde/fuera de horario.
  if (!row || !row.lastClientAt || row.humanResponded) return row;

  const lastClientTime = new Date(row.lastClientAt).getTime();
  if (!Number.isFinite(lastClientTime)) return row;

  const all = (messages || [])
    .filter(m => m.timestamp)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const nextHuman = all.find(m =>
    supervisorMessageActor(m) === "human" &&
    new Date(m.timestamp).getTime() > lastClientTime
  );

  if (!nextHuman) return row;

  const mins = qaMinutesBetween(row.lastClientAt, nextHuman.timestamp);
  const humanText = supervisorMessageTextForReport(nextHuman) || "[respuesta humana detectada]";

  const lateResponses = Array.isArray(row.lateResponses) ? [...row.lateResponses] : [];
  if (mins !== null && mins >= 0 && mins > Number(lateMinutes || 30)) {
    lateResponses.push({
      inboundAt: row.lastClientAt,
      humanAt: nextHuman.timestamp,
      minutes: mins,
      customerText: row.lastClientText || "",
      humanText,
      seller: nextHuman.user || row.seller || row.owner || ""
    });
  }

  return {
    ...row,
    humanResponded: true,
    noHumanResponse: false,
    botOnly: false,
    needsHumanNow: false,
    pendingClientMessages: 0,
    businessCloseGrace: false,
    respondedOutsideBusinessHours: new Date(nextHuman.timestamp).getTime() > businessRange.to.getTime(),
    afterHoursHumanAt: nextHuman.timestamp,
    afterHoursHumanText: humanText,
    humanCount: Math.max(Number(row.humanCount || 0), 1),
    lastHumanAt: nextHuman.timestamp,
    lastHumanAnyAt: nextHuman.timestamp,
    lastHumanText: humanText.slice(0, 300),
    maxHumanResponseMinutes: mins !== null && mins >= 0 ? Math.max(Number(row.maxHumanResponseMinutes || 0), mins) : row.maxHumanResponseMinutes,
    avgHumanResponseMinutes: mins !== null && mins >= 0 ? mins : row.avgHumanResponseMinutes,
    lateCount: lateResponses.length,
    lateResponses,
    humanTexts: [
      ...(Array.isArray(row.humanTexts) ? row.humanTexts : []),
      { at: nextHuman.timestamp, user: nextHuman.user || row.seller || row.owner || "", text: humanText.slice(0, 500) }
    ].slice(-3)
  };
}


const SUPERVISOR_EXCLUDED_OWNER_EMAILS = new Set([
  "basura@sentirecustomsbroker.com"
]);

function supervisorNormalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function supervisorIsExcludedOwner(owner) {
  return SUPERVISOR_EXCLUDED_OWNER_EMAILS.has(supervisorNormalizeEmail(owner));
}

function supervisorCombinedClientText(messages) {
  return (messages || [])
    .filter(m => supervisorMessageActor(m) === "client")
    .map(m => m.text || "")
    .join(" \n ")
    .toLowerCase();
}

function supervisorIsJobSeekerConversation(conversation, messages) {
  const text = supervisorCombinedClientText(messages);
  const name = String(conversation?.contactName || "").toLowerCase();
  const haystack = text + " " + name;

  const strong = [
    "curriculum", "currículum", " cv", "cv ", "enviar cv", "mandar cv", "mande cv",
    "trabajo", "trabajar", "empleo", "vacante", "vacantes", "chofer", "choferes",
    "conductor", "conductor profesional", "toman choferes", "necesitan choferes",
    "necesitan conductor", "busco laburo", "busco trabajo", "dan trabajo", "oferta laboral"
  ];

  return strong.some(k => haystack.includes(k));
}

function supervisorDailyExclusionReason(conversation, row, messages) {
  const owner = row?.seller || row?.owner || conversation?.owner || "";
  if (supervisorIsExcludedOwner(owner)) return "owner_excluido_basura";
  if (supervisorIsJobSeekerConversation(conversation, messages)) return "consulta_empleo_cv";
  return "";
}

function supervisorReviewHasConsultativeFields(review) {
  const ai = review?.aiReview || review || {};
  return ai.commercial_discovery_level !== undefined ||
    ai.operational_without_discovery !== undefined ||
    ai.unexplored_potential !== undefined ||
    ai.sales_coaching !== undefined;
}

async function supervisorGetDailyCachedReview(date, conversationId) {
  const id = supervisorDailyReviewDocId(date, conversationId);
  const doc = await db.collection("supervisor_reviews").doc(id).get();
  if (doc.exists) return { id: doc.id, data: doc.data() || {}, source: "daily_exact" };

  // Reuse any same-day/full-day review if it already has the new consultative fields.
  try {
    const existing = await findCachedReviewForConversation(conversationId, date);
    if (existing && supervisorReviewHasConsultativeFields(existing.data)) {
      return { ...existing, source: "existing_consultative" };
    }
  } catch (err) {}

  return null;
}

async function supervisorSaveDailyReview({ date, conversation, messages, aiReview, error }) {
  const reviewId = supervisorDailyReviewDocId(date, conversation.id);
  const item = {
    ok: !error,
    type: "daily_manual_chat_review",
    date,
    conversationId: conversation.id,
    contactName: conversation.contactName || conversation.phone || null,
    phone: conversation.phone || null,
    owner: conversation.owner || null,
    lineId: conversation.lineId || conversation.inboundTo || null,
    source: "daily_manual_supervisor",
    lastMessageAt: conversation.lastMessageAt || null
  };

  if (error) {
    item.error = error;
  } else {
    item.result = aiReview.result;
    item.score = aiReview.overall_score;
    item.risk = aiReview.risk_level;
    item.reason = reviewReason(aiReview);
    item.nextBestReply = aiReview.next_best_reply;
    item.aiReview = aiReview;
  }

  await db.collection("supervisor_reviews").doc(reviewId).set({
    ...item,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { id: reviewId, data: { ...item, updatedAt: new Date().toISOString() } };
}

function supervisorBuildDailyReport(data) {
  const rows = data.rows || [];
  const bySeller = data.bySeller || [];
  const clientChats = rows.filter(r => Number(r.inboundCount || 0) > 0);
  const human = rows.filter(r => r.humanResponded);
  const okHuman = rows.filter(r => r.humanResponded && !r.needsReviewByAi && !(r.lateCount > 0));
  const goodCommercial = rows.filter(r => r.goodCommercialResponse);
  const operationalNoDiscovery = rows.filter(r => r.operationalWithoutDiscovery);
  const unexploredPotential = rows.filter(r => r.unexploredPotential);
  const lowDiscovery = rows.filter(r => ["bajo", "nulo"].includes(String(r.commercialDiscoveryLevel || r.ai?.commercialDiscoveryLevel || "").toLowerCase()));
  const noHuman = rows.filter(r => r.noHumanResponse);
  const botOnly = rows.filter(r => r.botOnly);
  const late = rows.filter(r => r.lateCount > 0);
  const needsReview = rows.filter(r => r.needsReviewByAi);
  const followUpOk = rows.filter(r => r.followUpOk);
  const readyToDiscard = rows.filter(r => r.readyToDiscardNoResponse);
  const excludedRows = data.excludedRows || [];
  const excludedJob = excludedRows.filter(r => r.exclusionReason === "consulta_empleo_cv");
  const excludedTrash = excludedRows.filter(r => r.exclusionReason === "owner_excluido_basura");

  const sellerRows = bySeller.map((s, i) => {
    let lectura = "Buen desempeño general.";
    if (s.readyToDiscardNoResponse > 0) lectura = "Tiene clientes con 10 o más seguimientos sin respuesta; revisar para descartar o mover etapa.";
    else if (s.clientChats >= 1 && s.humanResponded === 0 && s.followUpOk === 0) lectura = "Urgente: tuvo clientes activos pero no se detectó respuesta humana.";
    else if (s.noHumanResponse > 0) lectura = "Tiene clientes sin respuesta humana; revisar seguimiento inmediato.";
    else if (s.followUpOk > 0) lectura = "Está haciendo seguimiento: correcto si mantiene cadencia hasta 5-10 intentos antes de descartar.";
    else if (s.operationalWithoutDiscovery > 0 || s.unexploredPotential > 0) lectura = "Responde, pero pierde oportunidad comercial por falta de indagación.";
    else if (s.goodCommercial >= Math.max(1, Math.floor(s.humanResponded * 0.5))) lectura = "Buen enfoque consultivo: indaga mejor que el promedio.";

    return `${i + 1}) ${s.seller} — ${s.evaluation}
   Clientes activos: ${s.clientChats}
   Respondió humano: ${s.humanResponded}${s.responseRate === null ? "" : " (" + s.responseRate + "% de clientes con respuesta humana)"}
   Bien / sin alerta: ${s.okHuman}
   Buena respuesta comercial: ${s.goodCommercial}
   Respondió operativo sin indagar: ${s.operationalWithoutDiscovery}
   Potencial no explorado: ${s.unexploredPotential}
   Baja/nula indagación: ${s.lowDiscovery}
   Seguimientos correctos: ${s.followUpOk}
   Para descartar por no respuesta: ${s.readyToDiscardNoResponse}
   A revisar por IA: ${s.needsReviewByAi}
   Sin respuesta humana: ${s.noHumanResponse}
   Solo bot: ${s.botOnly}
   Respuestas tarde: ${s.late}
   Máxima demora: ${qaFormatMinutes(s.maxDelayMinutes || null)}
   Lectura: ${lectura}
   Clientes ejemplo: ${(s.lastClients || []).join(" | ") || "-"}`;
  }).join("\n\n");

  const priorityRows = rows
    .filter(r => r.readyToDiscardNoResponse || r.noHumanResponse || r.botOnly || r.operationalWithoutDiscovery || r.unexploredPotential || r.needsReviewByAi || r.lateCount > 0)
    .sort((a, b) => {
      const rank = x => x.readyToDiscardNoResponse ? 1 : x.noHumanResponse ? 2 : x.botOnly ? 3 : x.operationalWithoutDiscovery ? 4 : x.unexploredPotential ? 5 : x.needsReviewByAi ? 6 : x.lateCount > 0 ? 7 : 9;
      return rank(a) - rank(b);
    })
    .slice(0, 60)
    .map((r, i) => `${i + 1}) ${supervisorHourlyStatus(r)} — ${r.contactName}
   Vendedor: ${r.seller || r.owner || "No detectado"}
   Cliente escribió: ${r.lastClientText || "-"}
   Humano: ${r.lastHumanText || "-"}
   Indagación comercial: ${r.ai?.commercialDiscoveryLevel || r.commercialDiscoveryLevel || "sin dato"}
   Perfil estimado: ${r.ai?.customerProfileGuess || "desconocido"}
   Motivo: ${r.ai?.reason || "-"}
   Coaching: ${r.ai?.salesCoaching || "-"}
   Acción: ${supervisorHourlyAction(r)}
   Chat: ${r.conversationId}`)
    .join("\n\n");

  const urgentSellers = bySeller.filter(s => s.evaluation === "URGENTE").map(s => s.seller).join(", ") || "-";
  const reviewSellers = bySeller.filter(s => s.evaluation === "REVISAR").map(s => s.seller).join(", ") || "-";
  const okSellers = bySeller.filter(s => s.evaluation === "OK").map(s => s.seller).join(", ") || "-";

  return `📊 SCB SUPERVISOR — REPORTE DIARIO GERENCIAL
Fecha: ${data.date}
Horario evaluado: ${data.businessHours?.label || data.dayLabel || "09:00 a 17:00"} Argentina
Filtro CRM: ${(data.ownerFilters || []).length ? (data.ownerFilters || []).join(", ") : "Todos los usuarios"}
Modo filtro: ${data.filterMode || "all"}
Umbral de respuesta tarde: más de ${data.lateMinutes || 30} minutos

RESUMEN GENERAL
- Conversaciones activas en horario laboral: ${rows.length}
- Conversaciones donde escribió el cliente: ${clientChats.length}
- Respondidas por humano: ${human.length}
- Respondidas bien / sin alerta: ${okHuman.length}
- Buenas respuestas comerciales: ${goodCommercial.length}
- Respuestas operativas sin indagar: ${operationalNoDiscovery.length}
- Clientes con potencial comercial no explorado: ${unexploredPotential.length}
- Chats con baja/nula indagación: ${lowDiscovery.length}
- Chats solo bot: ${botOnly.length}
- Clientes sin respuesta humana: ${noHuman.length}
- Respuestas tarde: ${late.length}
- Respuestas a revisar por IA: ${needsReview.length}
- Seguimientos correctos del vendedor: ${followUpOk.length}
- Para descartar por no respuesta luego de seguimiento: ${readyToDiscard.length}
- Excluidos por empleo/CV: ${excludedJob.length}
- Excluidos por basura@sentirecustomsbroker.com: ${excludedTrash.length}
- Chats analizados con IA ahora/cache: ${data.aiUsedCount || 0}
- Consultas cerca del cierre no marcadas como incumplimiento: ${rows.filter(r => r.businessCloseGrace).length}

QUIÉN TRABAJÓ BIEN / QUIÉN NECESITA CONTROL
- Urgentes: ${urgentSellers}
- A revisar: ${reviewSellers}
- OK: ${okSellers}

RANKING POR VENDEDOR
${sellerRows || "-"}

CASOS IMPORTANTES DEL DÍA
${priorityRows || "Sin casos importantes detectados."}

LECTURA GERENCIAL
${noHuman.length ? "- Hay clientes que escribieron y no tuvieron respuesta humana." : "- No se detectaron clientes sin respuesta humana."}
${botOnly.length ? "- Hay chats que quedaron solo con bot; deben ser tomados por vendedores si hay intención comercial." : "- No hay volumen relevante de chats solo bot."}
${operationalNoDiscovery.length ? "- Hay vendedores que responden, pero no venden consultivamente: piden datos sin descubrir negocio real." : "- No se detectó volumen relevante de respuestas operativas sin indagación."}
${unexploredPotential.length ? "- Hay potencial comercial no explorado: clientes que podrían ser importadores/distribuidores/comercios tratados como consultas chicas." : "- No se detectó potencial comercial no explorado en la muestra."}
${followUpOk.length ? "- Hay vendedores haciendo seguimiento correcto a clientes que dejaron de responder; eso no debe castigarse como falta de respuesta." : "- No se detectaron seguimientos activos en la muestra."}
${readyToDiscard.length ? "- Hay clientes con muchos intentos de seguimiento sin respuesta; conviene descartarlos o moverlos de etapa." : "- No hay casos claros para descartar por exceso de seguimiento."}
${goodCommercial.length ? "- También hay buenas respuestas comerciales que pueden usarse como ejemplo para entrenar al equipo." : "- No se detectaron buenas respuestas comerciales claras en la muestra analizada."}

ACCIONES PARA MAÑANA / CIERRE DEL DÍA
1) Recuperar primero los clientes SIN RESPUESTA HUMANA.
2) No castigar los SEGUIMIENTOS OK: son intentos válidos para recuperar clientes dormidos.
3) Revisar los casos DESCARTAR SIN RESPUESTA: si ya hubo 10 o más intentos, mover etapa/descartar.
4) Tomar manualmente los chats SOLO BOT que mostraron intención comercial.
5) Auditar por vendedor los casos RESPONDIÓ SIN INDAGAR.
6) Pedir que cada vendedor recontacte clientes con POTENCIAL NO EXPLORADO.
7) Actualizar CRM con próxima acción, fecha y responsable.`;
}

function supervisorDailyHtml(data, reportText) {
  const sellerRows = (data.bySeller || []).map((s, i) => {
    const color = s.evaluation === "URGENTE" ? "#dc2626" : s.evaluation === "REVISAR" ? "#d97706" : "#16a34a";
    return `<tr>
<td>${i + 1}</td>
<td style="font-weight:bold;color:${color}">${htmlEscape(s.evaluation)}</td>
<td>${htmlEscape(s.seller)}</td>
<td>${htmlEscape(s.clientChats)}</td>
<td>${htmlEscape(s.humanResponded)}</td>
<td>${htmlEscape(s.okHuman)}</td>
<td>${htmlEscape(s.goodCommercial)}</td>
<td>${htmlEscape(s.operationalWithoutDiscovery)}</td>
<td>${htmlEscape(s.unexploredPotential)}</td>
<td>${htmlEscape(s.lowDiscovery)}</td>
<td>${htmlEscape(s.followUpOk)}</td>
<td>${htmlEscape(s.readyToDiscardNoResponse)}</td>
<td>${htmlEscape(s.needsReviewByAi)}</td>
<td>${htmlEscape(s.noHumanResponse)}</td>
<td>${htmlEscape(s.botOnly)}</td>
<td>${htmlEscape(s.late)}</td>
<td>${htmlEscape(s.responseRate === null ? "-" : s.responseRate + "%")}</td>
<td>${htmlEscape(qaFormatMinutes(s.maxDelayMinutes || null))}</td>
</tr>`;
  }).join("");

  const rows = (data.rows || []).map((r, i) => {
    const status = supervisorHourlyStatus(r);
    const color = supervisorHourlyStatusColor(status);
    return `<tr>
<td>${i + 1}</td>
<td style="font-weight:bold;color:${color}">${htmlEscape(status)}</td>
<td>${htmlEscape(r.contactName)}</td>
<td>${htmlEscape(r.seller || r.owner || "No detectado")}</td>
<td>${htmlEscape(r.inboundCount)}</td>
<td>${htmlEscape(r.botCount)}</td>
<td>${htmlEscape(r.humanCount)}</td>
<td>${htmlEscape(qaFormatMinutes(r.maxHumanResponseMinutes))}</td>
<td>${htmlEscape(r.ai?.result || "-")}</td>
<td>${htmlEscape(r.ai?.score ?? "-")}</td>
<td>${htmlEscape(r.ai?.commercialDiscoveryLevel || r.commercialDiscoveryLevel || "-")}</td>
<td>${htmlEscape(r.ai?.commercialRisk || r.commercialRisk || "-")}</td>
<td>${htmlEscape(r.ai?.customerProfileGuess || "-")}</td>
<td>${htmlEscape(r.ai?.reason || "-")}</td>
<td>${htmlEscape(supervisorHourlyAction(r))}</td>
<td>${htmlEscape(r.conversationId)}</td>
</tr>`;
  }).join("");

  return `<!doctype html><html><head><meta charset="utf-8"/>
<title>Supervisor diario ${htmlEscape(data.date)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff;margin-top:18px}td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}th{background:#f9fafb}.sectionTitle{margin-top:28px;border-bottom:2px solid #111827;padding-bottom:6px}
</style></head><body><div class="card">
<h1>SCB Supervisor — Reporte diario gerencial</h1>
<p><b>Fecha:</b> ${htmlEscape(data.date)} · <b>Horario evaluado:</b> ${htmlEscape(data.businessHours?.label || data.dayLabel || "09:00 a 17:00")} Argentina</p>
<pre>${htmlEscape(reportText)}</pre>
<h2 class="sectionTitle">Ranking por vendedor</h2>
<table><thead><tr><th>#</th><th>Evaluación</th><th>Vendedor</th><th>Clientes</th><th>Respondió humano</th><th>Bien</th><th>Buena comercial</th><th>Sin indagar</th><th>Potencial no explorado</th><th>Baja/nula indagación</th><th>Seguimiento OK</th><th>Para descartar</th><th>A revisar</th><th>Sin humano</th><th>Solo bot</th><th>Tarde</th><th>% respuesta</th><th>Demora máx</th></tr></thead><tbody>${sellerRows || '<tr><td colspan="18">Sin vendedores detectados.</td></tr>'}</tbody></table>
<h2 class="sectionTitle">Detalle por cliente</h2>
<table><thead><tr><th>#</th><th>Estado</th><th>Cliente</th><th>Vendedor</th><th>Cliente</th><th>Bot</th><th>Humano</th><th>Demora máx</th><th>IA</th><th>Score</th><th>Indagación</th><th>Riesgo comercial</th><th>Perfil</th><th>Motivo IA</th><th>Acción</th><th>Chat</th></tr></thead><tbody>${rows || '<tr><td colspan="16">Sin conversaciones activas.</td></tr>'}</tbody></table>
</div></body></html>`;
}


function supervisorGroupRowsBySeller(rows) {
  const groups = new Map();
  for (const row of (rows || [])) {
    const seller = String(row.seller || row.owner || "No detectado").trim() || "No detectado";
    if (!groups.has(seller)) groups.set(seller, []);
    groups.get(seller).push(row);
  }
  return Array.from(groups.entries())
    .map(([seller, sellerRows]) => ({ seller, rows: sellerRows }))
    .sort((a, b) => a.seller.localeCompare(b.seller));
}

function supervisorBuildSellerReport(data, seller, sellerRows) {
  // Mantiene EXACTAMENTE el formato gerencial principal, pero limitado a un solo vendedor.
  // Así el reporte individual sirve tanto en pantalla como para MRAPI Email sin cambiar estructura.
  const sellerSummary = (data.bySeller || []).find(x => String(x.seller) === String(seller)) || {
    seller,
    activeChats: sellerRows.length,
    clientChats: sellerRows.filter(r => Number(r.inboundCount || 0) > 0).length,
    humanResponded: sellerRows.filter(r => r.humanResponded).length,
    botOnly: sellerRows.filter(r => r.botOnly).length,
    noHumanResponse: sellerRows.filter(r => r.noHumanResponse).length,
    late: sellerRows.filter(r => r.lateCount > 0).length,
    needsReviewByAi: sellerRows.filter(r => r.needsReviewByAi).length,
    okHuman: sellerRows.filter(r => r.humanResponded && !r.needsReviewByAi && !(r.lateCount > 0)).length,
    goodCommercial: sellerRows.filter(r => r.goodCommercialResponse).length,
    operationalWithoutDiscovery: sellerRows.filter(r => r.operationalWithoutDiscovery).length,
    unexploredPotential: sellerRows.filter(r => r.unexploredPotential).length,
    lowDiscovery: sellerRows.filter(r => ["bajo", "nulo"].includes(String(r.commercialDiscoveryLevel || r.ai?.commercialDiscoveryLevel || "").toLowerCase())).length,
    followUpOk: sellerRows.filter(r => r.followUpOk).length,
    readyToDiscardNoResponse: sellerRows.filter(r => r.readyToDiscardNoResponse).length,
    maxDelayMinutes: Math.max(0, ...sellerRows.map(r => Number(r.maxHumanResponseMinutes || 0))),
    evaluation: "OK",
    lastClients: sellerRows.filter(r => Number(r.inboundCount || 0) > 0).slice(0, 5).map(r => r.contactName || r.phone || r.conversationId)
  };

  const sellerData = {
    ...data,
    rows: sellerRows,
    bySeller: [{ ...sellerSummary, seller }],
    ownerFilters: [seller],
    filterMode: "individual",
    reportsBySeller: []
  };

  return supervisorBuildDailyReport(sellerData);
}

function supervisorAttachSellerReports(data) {
  const groups = supervisorGroupRowsBySeller(data.rows || []);
  const reportsBySeller = groups.map(group => ({
    seller: group.seller,
    count: group.rows.length,
    report: supervisorBuildSellerReport(data, group.seller, group.rows),
    rows: group.rows
  }));
  return { ...data, reportsBySeller };
}

function supervisorDailyFolderForRow(row) {
  if (row.noHumanResponse) return "01_SIN_RESPUESTA_HUMANA";
  if (row.botOnly) return "02_SOLO_BOT";
  if (row.respondedOutsideBusinessHours) return "03_RESPUESTA_FUERA_DE_HORARIO";
  if (row.operationalWithoutDiscovery) return "03_RESPONDIO_SIN_INDAGAR";
  if (row.unexploredPotential) return "04_POTENCIAL_NO_EXPLORADO";
  if (row.lateCount > 0) return "05_RESPUESTAS_TARDE";
  if (row.needsReviewByAi) return "06_REVISAR_RESPUESTA";
  if (row.goodCommercialResponse) return "07_BUENAS_RESPUESTAS";
  return "08_OK";
}



function supervisorBucket() {
  if (!SUPERVISOR_REPORTS_BUCKET) {
    throw new Error("Falta configurar SUPERVISOR_REPORTS_BUCKET en Cloud Run.");
  }
  return admin.storage().bucket(SUPERVISOR_REPORTS_BUCKET);
}

async function supervisorSaveBucketObject(path, content, contentType) {
  const bucket = supervisorBucket();
  const file = bucket.file(path);
  const body = Buffer.isBuffer(content) ? content : Buffer.from(String(content || ""), "utf8");
  await file.save(body, {
    resumable: false,
    contentType: contentType || "application/octet-stream",
    metadata: {
      cacheControl: "private, max-age=0, no-store",
      metadata: {
        generatedBy: "scb-supervisor",
        generatedAt: new Date().toISOString()
      }
    }
  });
  return {
    bucket: SUPERVISOR_REPORTS_BUCKET,
    path,
    gsUri: `gs://${SUPERVISOR_REPORTS_BUCKET}/${path}`,
    sizeBytes: body.length,
    contentType: contentType || "application/octet-stream"
  };
}

function supervisorSellerReportHtml(data, sellerReport) {
  // Usa la misma plantilla HTML gerencial del reporte general, limitada al vendedor.
  const sellerSummary = (data.bySeller || []).find(x => String(x.seller) === String(sellerReport.seller)) || {};
  const sellerData = {
    ...data,
    rows: sellerReport.rows || [],
    bySeller: [{ ...sellerSummary, seller: sellerReport.seller }],
    ownerFilters: [sellerReport.seller],
    filterMode: "individual",
    reportsBySeller: []
  };
  return supervisorDailyHtml(sellerData, sellerReport.report || supervisorBuildDailyReport(sellerData));
}

async function supervisorPersistDailyArtifacts(data, managerReport) {
  const base = `supervisor-reports/${data.date}/${safeFileName(data.queueJobId || "manual")}`;
  const generalHtml = supervisorDailyHtml(data, managerReport);
  const artifacts = {
    bucket: SUPERVISOR_REPORTS_BUCKET,
    basePath: base,
    generatedAt: new Date().toISOString(),
    managerText: await supervisorSaveBucketObject(`${base}/00_REPORTE_GERENCIAL.txt`, managerReport, "text/plain; charset=utf-8"),
    managerHtml: await supervisorSaveBucketObject(`${base}/00_REPORTE_GERENCIAL.html`, generalHtml, "text/html; charset=utf-8"),
    fullJson: await supervisorSaveBucketObject(`${base}/00_DATA_COMPLETA.json`, JSON.stringify(data, null, 2), "application/json; charset=utf-8"),
    sellers: []
  };

  for (const sellerReport of (data.reportsBySeller || [])) {
    const sellerFolder = `${base}/vendedores/${safeFileName(sellerReport.seller || "No_detectado")}`;
    const sellerJson = {
      date: data.date,
      businessHours: data.businessHours,
      seller: sellerReport.seller,
      count: sellerReport.count,
      summary: (data.bySeller || []).find(x => String(x.seller) === String(sellerReport.seller)) || null,
      report: sellerReport.report,
      rows: sellerReport.rows || []
    };
    const sellerArtifacts = {
      seller: sellerReport.seller,
      count: sellerReport.count,
      text: await supervisorSaveBucketObject(`${sellerFolder}/00_REPORTE_VENDEDOR.txt`, sellerReport.report, "text/plain; charset=utf-8"),
      html: await supervisorSaveBucketObject(`${sellerFolder}/00_REPORTE_VENDEDOR.html`, supervisorSellerReportHtml(data, sellerReport), "text/html; charset=utf-8"),
      json: await supervisorSaveBucketObject(`${sellerFolder}/00_DATA_VENDEDOR.json`, JSON.stringify(sellerJson, null, 2), "application/json; charset=utf-8")
    };
    artifacts.sellers.push(sellerArtifacts);
  }

  return artifacts;
}

function supervisorCompactArtifacts(artifacts) {
  if (!artifacts) return null;
  const compactObject = obj => obj ? ({ path: obj.path, gsUri: obj.gsUri, sizeBytes: obj.sizeBytes, contentType: obj.contentType }) : null;
  return {
    bucket: artifacts.bucket,
    basePath: artifacts.basePath,
    generatedAt: artifacts.generatedAt,
    managerText: compactObject(artifacts.managerText),
    managerHtml: compactObject(artifacts.managerHtml),
    fullJson: compactObject(artifacts.fullJson),
    sellers: (artifacts.sellers || []).map(x => ({
      seller: x.seller,
      count: x.count,
      text: compactObject(x.text),
      html: compactObject(x.html),
      json: compactObject(x.json)
    }))
  };
}

function supervisorCompactDailyReport(data, managerReport) {
  return {
    ok: true,
    type: data.type || "daily_manual_supervisor",
    source: data.source || "manual",
    queueJobId: data.queueJobId || null,
    date: data.date,
    dayLabel: data.dayLabel || null,
    businessHours: data.businessHours || null,
    dateRangeArgentina: data.dateRangeArgentina || null,
    businessRangeArgentina: data.businessRangeArgentina || null,
    lateMinutes: data.lateMinutes || 30,
    limit: data.limit || 0,
    ownerFilters: supervisorParseOwnerFilters(data.ownerFilters || []),
    filterMode: data.filterMode || (supervisorParseOwnerFilters(data.ownerFilters || []).length ? (supervisorParseOwnerFilters(data.ownerFilters || []).length === 1 ? "individual" : "group") : "all"),
    filteredOutCount: Number(data.filteredOutCount || 0),
    includedCount: Array.isArray(data.rows) ? data.rows.length : Number(data.includedCount || 0),
    excludedCount: Array.isArray(data.excludedRows) ? data.excludedRows.length : Number(data.excludedCount || 0),
    bySeller: data.bySeller || [],
    aiUsedCount: data.aiUsedCount || 0,
    aiErrors: (data.aiErrors || []).slice(0, 100),
    reportsBySeller: (data.reportsBySeller || []).map(x => ({ seller: x.seller, count: x.count })),
    managerReportPreview: String(managerReport || "").slice(0, 100000),
    artifacts: supervisorCompactArtifacts(data.artifacts || null),
    storageMode: data.queueJobId ? "queue_items" : "summary_only",
    generatedAt: data.generatedAt || new Date().toISOString()
  };
}

async function supervisorHydrateDailyQueueData(jobId, reportData = {}) {
  if (!jobId) return reportData;
  const itemsSnap = await db.collection("supervisor_jobs").doc(jobId).collection("items").limit(1000).get();
  const rows = [];
  const excludedRows = [];
  const aiErrors = [];
  let aiUsedCount = 0;
  itemsSnap.forEach(doc => {
    const item = doc.data() || {};
    if (item.status === "included" && item.row) rows.push(item.row);
    if (item.status === "excluded" && item.reason !== "owner_filter" && item.row) excludedRows.push(item.row);
    if (item.aiUsed) aiUsedCount += 1;
    if (item.aiError) aiErrors.push({ conversationId: item.conversationId, error: item.aiError });
  });
  let data = { ...reportData, rows, excludedRows, excludedCount: excludedRows.length, aiUsedCount, aiErrors };
  if (!Array.isArray(data.bySeller) || !data.bySeller.length) data.bySeller = supervisorBuildHourlySummary(rows);
  data = supervisorAttachSellerReports(data);
  return data;
}

async function supervisorBuildDailyManualData({ date, lateMinutes, limit, businessStartHour, businessEndHour, analyzeMissing, useCache, ownerFilters = [] }) {
  ownerFilters = supervisorParseOwnerFilters(ownerFilters);
  const reportId = supervisorDailyDocId(date, businessStartHour, businessEndHour, lateMinutes, ownerFilters);
  if (useCache && !analyzeMissing) {
    const cached = await db.collection("supervisor_reports").doc(reportId).get();
    if (cached.exists) return { ...(cached.data() || {}), fromCache: true, reportId };
  }

  const fetched = await supervisorGetConversationsInDay(date, limit);
  const businessRange = supervisorDailyBusinessRangeArgentina(date, businessStartHour, businessEndHour);
  const rows = [];
  const excludedRows = [];
  const ownerResolveCache = new Map();
  let aiUsedCount = 0;
  const aiErrors = [];

  for (const conversation of fetched.conversations) {
    const messages = await getConversationMessages(conversation.id, 150);
    let row = supervisorAnalyzeHourlyConversation(conversation, messages, businessRange, lateMinutes);
    row = supervisorApplyBusinessCloseGrace(row, businessRange, lateMinutes);
    row = supervisorApplyAfterHoursHumanResponse(row, messages, businessRange, lateMinutes);

    // Si no hubo actividad dentro del horario laboral configurado, no lo contamos
    // en el reporte gerencial del día. Así los mensajes fuera de horario no quedan
    // falsamente como sin responder.
    if (!row.messagesInWindow) continue;

    const resolvedOwner = await supervisorResolveHourlyOwner(conversation, messages, row, ownerResolveCache);
    row.owner = resolvedOwner.owner || "No detectado";
    row.seller = resolvedOwner.owner || "No detectado";
    row.ownerSource = resolvedOwner.source || "not_found";
    row.crmContactId = resolvedOwner.contactId || row.crmContactId || "";
    row.crmDealId = resolvedOwner.dealId || row.dealId || "";

    if (!supervisorOwnerMatchesFilter(row.seller || row.owner, ownerFilters)) continue;

    const exclusionReason = supervisorDailyExclusionReason(conversation, row, messages);
    if (exclusionReason) {
      excludedRows.push({
        ...row,
        excludedFromReport: true,
        exclusionReason
      });
      continue;
    }

    if (supervisorHourlyNeedsAi(row)) {
      try {
        let cached = await supervisorGetDailyCachedReview(date, conversation.id);
        if ((!cached || !supervisorReviewHasConsultativeFields(cached.data)) && analyzeMissing) {
          const aiReview = await analyzeWithAI(conversation, messages);
          cached = await supervisorSaveDailyReview({ date, conversation, messages, aiReview, error: null });
        }
        if (cached) {
          aiUsedCount += 1;
          row = supervisorApplyAiToHourlyRow(row, cached.data);
          row.aiFromCache = true;
        }
      } catch (err) {
        aiErrors.push({ conversationId: conversation.id, error: err.message });
      }
    }

    rows.push(row);
  }

  const bySeller = supervisorBuildHourlySummary(rows);
  let data = {
    ok: true,
    type: "daily_manual_supervisor",
    date,
    dayLabel: "Horario laboral " + businessRange.label + " Argentina",
    businessHours: { startHour: businessRange.startHour, endHour: businessRange.endHour, label: businessRange.label },
    dateRangeArgentina: { from: fetched.range.from.toISOString(), to: fetched.range.to.toISOString() },
    businessRangeArgentina: { from: businessRange.from.toISOString(), to: businessRange.to.toISOString() },
    lateMinutes,
    limit,
    ownerFilters,
    filterMode: ownerFilters.length ? (ownerFilters.length === 1 ? "individual" : "group") : "all",
    rows,
    excludedRows,
    excludedCount: excludedRows.length,
    bySeller,
    aiUsedCount,
    aiErrors,
    generatedAt: new Date().toISOString()
  };
  data = supervisorAttachSellerReports(data);
  const generalManagerReport = supervisorBuildDailyReport(data);
  const sellerManagerReports = (data.reportsBySeller || []).map(x => x.report).join("\n\n============================================================\n\n");
  // En modo individual el reporte general YA ES el reporte gerencial completo del vendedor.
  // No anexamos un segundo reporte simplificado/duplicado.
  const managerReport = data.filterMode === "individual"
    ? generalManagerReport
    : generalManagerReport + (sellerManagerReports ? "\n\nREPORTES SEPARADOS POR VENDEDOR\n\n" + sellerManagerReports : "");

  await db.collection("supervisor_reports").doc(reportId).set({
    ...supervisorCompactDailyReport(data, managerReport),
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: false });

  return { ...data, managerReport, fromCache: false, reportId };
}


function supervisorParseOwnerFilters(value) {
  const raw = Array.isArray(value) ? value : (value === undefined || value === null ? [] : [value]);
  const out = [];
  for (const item of raw) {
    String(item || "").split(",").forEach(part => {
      const clean = part.trim().toLowerCase();
      if (clean && !out.includes(clean)) out.push(clean);
    });
  }
  return out.sort();
}

function supervisorOwnerFilterKey(ownerFilters) {
  const owners = supervisorParseOwnerFilters(ownerFilters);
  if (!owners.length) return "all";
  return Buffer.from(owners.join("|"), "utf8").toString("base64url").slice(0, 96);
}

function supervisorOwnerMatchesFilter(owner, ownerFilters) {
  const filters = supervisorParseOwnerFilters(ownerFilters);
  if (!filters.length) return true;
  const current = String(owner || "").trim().toLowerCase();
  if (!current) return false;
  if (filters.includes(current)) return true;
  const currentLocal = current.includes("@") ? current.split("@")[0] : current;
  return filters.some(filter => {
    const local = filter.includes("@") ? filter.split("@")[0] : filter;
    return currentLocal === local || current.includes(filter) || filter.includes(current);
  });
}

function supervisorQueueItemDocId(conversationId) {
  return Buffer.from(String(conversationId || ""), "utf8").toString("base64url").slice(0, 180) || "sin_id";
}

function supervisorDailyQueueJobId(date, businessStartHour, businessEndHour, lateMinutes, ownerFilters = []) {
  return "daily_queue__" + date + "__" + String(businessStartHour).padStart(2, "0") + "_" + String(businessEndHour).padStart(2, "0") + "__late_" + String(lateMinutes) + "__owners_" + supervisorOwnerFilterKey(ownerFilters);
}

async function supervisorProcessDailyConversation({ date, conversation, businessRange, lateMinutes, analyzeMissing, ownerResolveCache, ownerFilters = [] }) {
  const messages = await getConversationMessages(conversation.id, 150);
  let row = supervisorAnalyzeHourlyConversation(conversation, messages, businessRange, lateMinutes);
  row = supervisorApplyBusinessCloseGrace(row, businessRange, lateMinutes);
  row = supervisorApplyAfterHoursHumanResponse(row, messages, businessRange, lateMinutes);

  if (!row.messagesInWindow) return { status: "excluded", reason: "sin_actividad_en_horario", row };

  const resolvedOwner = await supervisorResolveHourlyOwner(conversation, messages, row, ownerResolveCache || new Map());
  row.owner = resolvedOwner.owner || "No detectado";
  row.seller = resolvedOwner.owner || "No detectado";
  row.ownerSource = resolvedOwner.source || "not_found";
  row.crmContactId = resolvedOwner.contactId || row.crmContactId || "";
  row.crmDealId = resolvedOwner.dealId || row.dealId || "";

  if (!supervisorOwnerMatchesFilter(row.seller || row.owner, ownerFilters)) {
    return { status: "excluded", reason: "owner_filter", row: { ...row, excludedFromReport: true, exclusionReason: "owner_filter" } };
  }

  const exclusionReason = supervisorDailyExclusionReason(conversation, row, messages);
  if (exclusionReason) return { status: "excluded", reason: exclusionReason, row: { ...row, excludedFromReport: true, exclusionReason } };

  let aiUsed = false;
  let aiError = null;
  if (supervisorHourlyNeedsAi(row)) {
    try {
      let cached = await supervisorGetDailyCachedReview(date, conversation.id);
      if ((!cached || !supervisorReviewHasConsultativeFields(cached.data)) && analyzeMissing) {
        const aiReview = await analyzeWithAI(conversation, messages);
        cached = await supervisorSaveDailyReview({ date, conversation, messages, aiReview, error: null });
      }
      if (cached) {
        aiUsed = true;
        row = supervisorApplyAiToHourlyRow(row, cached.data);
        row.aiFromCache = cached.source !== undefined || true;
      }
    } catch (err) {
      aiError = err.message;
    }
  }

  return { status: "included", row, aiUsed, aiError };
}

async function supervisorFinalizeDailyQueue(jobId, jobData) {
  const itemsSnap = await db.collection("supervisor_jobs").doc(jobId).collection("items").limit(1000).get();
  const rows = [];
  const excludedRows = [];
  const filteredOutRows = [];
  const aiErrors = [];
  let aiUsedCount = 0;

  itemsSnap.forEach(doc => {
    const item = doc.data() || {};
    if (item.status === "included" && item.row) rows.push(item.row);
    if (item.status === "excluded" && item.reason === "owner_filter" && item.row) filteredOutRows.push(item.row);
    else if (item.status === "excluded" && item.row) excludedRows.push(item.row);
    if (item.aiUsed) aiUsedCount += 1;
    if (item.aiError) aiErrors.push({ conversationId: item.conversationId, error: item.aiError });
  });

  const businessRange = supervisorDailyBusinessRangeArgentina(jobData.date, jobData.businessStartHour, jobData.businessEndHour);
  const bySeller = supervisorBuildHourlySummary(rows);
  let data = {
    ok: true,
    type: "daily_manual_supervisor",
    source: "persistent_queue",
    queueJobId: jobId,
    date: jobData.date,
    dayLabel: "Horario laboral " + businessRange.label + " Argentina",
    businessHours: { startHour: businessRange.startHour, endHour: businessRange.endHour, label: businessRange.label },
    dateRangeArgentina: jobData.dateRangeArgentina,
    businessRangeArgentina: { from: businessRange.from.toISOString(), to: businessRange.to.toISOString() },
    lateMinutes: jobData.lateMinutes,
    limit: jobData.limit,
    ownerFilters: supervisorParseOwnerFilters(jobData.ownerFilters || []),
    filterMode: supervisorParseOwnerFilters(jobData.ownerFilters || []).length ? (supervisorParseOwnerFilters(jobData.ownerFilters || []).length === 1 ? "individual" : "group") : "all",
    rows,
    filteredOutCount: filteredOutRows.length,
    excludedRows,
    excludedCount: excludedRows.length,
    bySeller,
    aiUsedCount,
    aiErrors,
    generatedAt: new Date().toISOString()
  };
  data = supervisorAttachSellerReports(data);
  const generalManagerReport = supervisorBuildDailyReport(data);
  const sellerManagerReports = (data.reportsBySeller || []).map(x => x.report).join("\n\n============================================================\n\n");
  // En modo individual el reporte general YA ES el reporte gerencial completo del vendedor.
  // No anexamos un segundo reporte simplificado/duplicado.
  const managerReport = data.filterMode === "individual"
    ? generalManagerReport
    : generalManagerReport + (sellerManagerReports ? "\n\nREPORTES SEPARADOS POR VENDEDOR\n\n" + sellerManagerReports : "");
  const reportId = supervisorDailyDocId(jobData.date, jobData.businessStartHour, jobData.businessEndHour, jobData.lateMinutes, jobData.ownerFilters || []);
  const artifacts = await supervisorPersistDailyArtifacts(data, managerReport);
  data.artifacts = artifacts;

  await db.collection("supervisor_reports").doc(reportId).set({
    ...supervisorCompactDailyReport(data, managerReport),
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: false });

  await db.collection("supervisor_jobs").doc(jobId).set({
    status: "completed",
    reportId,
    includedCount: rows.length,
    excludedCount: excludedRows.length,
    filteredOutCount: filteredOutRows.length,
    ownerFilters: supervisorParseOwnerFilters(jobData.ownerFilters || []),
    aiUsedCount,
    artifacts: supervisorCompactArtifacts(artifacts),
    completedAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  return { ...data, managerReport, reportId };
}

app.get("/api/supervisor/daily-queue/start", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const businessStartHour = Math.min(Math.max(Number(req.query.businessStartHour || 9), 0), 23);
    const businessEndHour = Math.min(Math.max(Number(req.query.businessEndHour || 17), businessStartHour + 1), 24);
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 30), 5), 180);
    const limit = Math.min(Math.max(Number(req.query.limit || 200), 1), 500);
    const ownerFilters = supervisorParseOwnerFilters(req.query.owner);
    const jobId = supervisorDailyQueueJobId(date, businessStartHour, businessEndHour, lateMinutes, ownerFilters);
    const jobRef = db.collection("supervisor_jobs").doc(jobId);
    const existing = await jobRef.get();

    if (existing.exists) {
      const existingData = existing.data() || {};
      if (["queued", "processing", "finalizing"].includes(String(existingData.status || ""))) {
        return res.json({ ok: true, reused: true, jobId, ...existingData });
      }
      if (String(existingData.status || "") === "completed" && String(req.query.force || "") !== "1") {
        return res.json({
          ok: true,
          reused: true,
          jobId,
          status: "completed",
          reportId: existingData.reportId || null,
          total: existingData.total || 0,
          processed: existingData.processed || existingData.total || 0,
          ownerFilters: existingData.ownerFilters || ownerFilters,
          filterMode: existingData.filterMode || (ownerFilters.length ? (ownerFilters.length === 1 ? "individual" : "group") : "all"),
          artifacts: existingData.artifacts || null,
          note: "Reporte ya existente: no se volvieron a leer chats ni a llamar a OpenAI. Use force=1 solo si realmente desea regenerarlo."
        });
      }
    }

    const fetched = await supervisorGetConversationsInDay(date, limit);
    const conversationIds = fetched.conversations.map(c => c.id);
    await jobRef.set({
      ok: true,
      type: "daily_supervisor_queue",
      status: "queued",
      date,
      businessStartHour,
      businessEndHour,
      lateMinutes,
      limit,
      ownerFilters,
      filterMode: ownerFilters.length ? (ownerFilters.length === 1 ? "individual" : "group") : "all",
      conversationIds,
      total: conversationIds.length,
      cursor: 0,
      processed: 0,
      dateRangeArgentina: { from: fetched.range.from.toISOString(), to: fetched.range.to.toISOString() },
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    res.json({ ok: true, jobId, status: "queued", total: conversationIds.length, processed: 0, ownerFilters, filterMode: ownerFilters.length ? (ownerFilters.length === 1 ? "individual" : "group") : "all" });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-queue/process", requireAuth, async (req, res) => {
  try {
    const jobId = String(req.query.jobId || "").trim();
    const batchSize = Math.min(Math.max(Number(req.query.batchSize || 5), 1), 10);
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });

    const jobRef = db.collection("supervisor_jobs").doc(jobId);
    const jobSnap = await jobRef.get();
    if (!jobSnap.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    const job = jobSnap.data() || {};
    if (job.status === "completed") return res.json({ ok: true, jobId, status: "completed", processed: job.processed || job.total || 0, total: job.total || 0, reportId: job.reportId || null });

    const ids = Array.isArray(job.conversationIds) ? job.conversationIds : [];
    const cursor = Number(job.cursor || 0);
    const selectedIds = ids.slice(cursor, cursor + batchSize);
    const businessRange = supervisorDailyBusinessRangeArgentina(job.date, job.businessStartHour, job.businessEndHour);
    const ownerResolveCache = new Map();
    let processedNow = 0;

    await jobRef.set({ status: "processing", updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });

    for (const conversationId of selectedIds) {
      const itemRef = jobRef.collection("items").doc(supervisorQueueItemDocId(conversationId));
      const existingItem = await itemRef.get();
      if (existingItem.exists && existingItem.data()?.done === true) {
        processedNow += 1;
        continue;
      }

      try {
        const convDoc = await db.collection("conversations").doc(conversationId).get();
        if (!convDoc.exists) {
          await itemRef.set({ done: true, status: "excluded", reason: "conversation_not_found", conversationId, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        } else {
          const conversation = normalizeConversation(convDoc);
          const result = await supervisorProcessDailyConversation({ date: job.date, conversation, businessRange, lateMinutes: job.lateMinutes, analyzeMissing: true, ownerResolveCache, ownerFilters: job.ownerFilters || [] });
          await itemRef.set({
            done: true,
            conversationId,
            status: result.status,
            reason: result.reason || null,
            row: result.row || null,
            aiUsed: !!result.aiUsed,
            aiError: result.aiError || null,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
        }
      } catch (err) {
        await itemRef.set({ done: true, status: "error", conversationId, aiError: err.message, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      }
      processedNow += 1;
    }

    const nextCursor = Math.min(cursor + selectedIds.length, ids.length);
    await jobRef.set({ cursor: nextCursor, processed: nextCursor, status: nextCursor >= ids.length ? "finalizing" : "processing", updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });

    if (nextCursor >= ids.length) {
      const finalData = await supervisorFinalizeDailyQueue(jobId, { ...job, cursor: nextCursor, processed: nextCursor });
      return res.json({
        ok: true,
        jobId,
        status: "completed",
        processed: nextCursor,
        total: ids.length,
        processedNow,
        reportId: finalData.reportId,
        bySeller: finalData.bySeller,
        reportsBySeller: (finalData.reportsBySeller || []).map(x => ({ seller: x.seller, count: x.count, report: x.report })),
        artifacts: supervisorCompactArtifacts(finalData.artifacts),
        managerReport: finalData.managerReport
      });
    }

    res.json({ ok: true, jobId, status: "processing", processed: nextCursor, total: ids.length, processedNow, progressPercent: ids.length ? Math.round((nextCursor / ids.length) * 100) : 100 });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-queue/status", requireAuth, async (req, res) => {
  try {
    const jobId = String(req.query.jobId || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });
    const jobDoc = await db.collection("supervisor_jobs").doc(jobId).get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    const job = jobDoc.data() || {};
    let report = null;
    if (job.reportId) {
      const reportDoc = await db.collection("supervisor_reports").doc(job.reportId).get();
      if (reportDoc.exists) report = reportDoc.data() || {};
    }
    res.json({
      ok: true,
      jobId,
      status: job.status,
      processed: job.processed || 0,
      total: job.total || 0,
      progressPercent: job.total ? Math.round(((job.processed || 0) / job.total) * 100) : 100,
      reportId: job.reportId || null,
      ownerFilters: report?.ownerFilters || job.ownerFilters || [],
      filterMode: report?.filterMode || job.filterMode || "all",
      bySeller: report?.bySeller || [],
      reportsBySeller: report?.reportsBySeller || [],
      artifacts: report?.artifacts || job.artifacts || null,
      managerReport: report?.managerReportPreview || null
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.get("/api/supervisor/daily-queue/saved-reports", requireAuth, async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 250);
    const snap = await db.collection("supervisor_jobs")
      .where("type", "==", "daily_supervisor_queue")
      .limit(limit)
      .get();

    const reports = snap.docs
      .map(doc => {
        const d = doc.data() || {};
        const completedAt = ts(d.completedAt) || ts(d.updatedAt) || null;
        const owners = supervisorParseOwnerFilters(d.ownerFilters || []);
        return {
          jobId: doc.id,
          reportId: d.reportId || null,
          status: d.status || null,
          date: d.date || "",
          businessStartHour: d.businessStartHour ?? 9,
          businessEndHour: d.businessEndHour ?? 17,
          businessHours: String(d.businessStartHour ?? 9).padStart(2, "0") + ":00-" + String(d.businessEndHour ?? 17).padStart(2, "0") + ":00",
          lateMinutes: d.lateMinutes ?? 30,
          ownerFilters: owners,
          filterMode: d.filterMode || (owners.length ? (owners.length === 1 ? "individual" : "group") : "all"),
          total: d.total || 0,
          includedCount: d.includedCount || 0,
          excludedCount: d.excludedCount || 0,
          sellerCount: Array.isArray(d.artifacts?.sellers) ? d.artifacts.sellers.length : 0,
          completedAt,
          hasArtifacts: !!d.artifacts
        };
      })
      .filter(x => x.status === "completed" && x.reportId)
      .sort((a, b) => {
        const da = new Date(a.completedAt || (a.date + "T00:00:00Z")).getTime();
        const dbb = new Date(b.completedAt || (b.date + "T00:00:00Z")).getTime();
        return dbb - da;
      });

    res.json({
      ok: true,
      count: reports.length,
      reports,
      note: "Listado desde supervisor_jobs. No lee conversaciones y no usa OpenAI."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-queue/saved-report", requireAuth, async (req, res) => {
  try {
    const jobId = String(req.query.jobId || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });

    const jobDoc = await db.collection("supervisor_jobs").doc(jobId).get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Reporte guardado no encontrado" });
    const job = jobDoc.data() || {};
    if (job.status !== "completed") return res.status(409).json({ ok: false, error: "El reporte todavía no está completado", status: job.status || null });

    let report = null;
    if (job.reportId) {
      const reportDoc = await db.collection("supervisor_reports").doc(job.reportId).get();
      if (reportDoc.exists) report = reportDoc.data() || {};
    }

    let managerReport = report?.managerReportPreview || "";
    const managerTextPath = job.artifacts?.managerText?.path || report?.artifacts?.managerText?.path || "";
    if (managerTextPath) {
      try {
        const [buf] = await supervisorBucket().file(managerTextPath).download();
        managerReport = buf.toString("utf8");
      } catch (err) {
        // Keep Firestore preview if bucket read fails.
      }
    }

    res.json({
      ok: true,
      saved: true,
      noChatRead: true,
      noOpenAI: true,
      jobId,
      reportId: job.reportId || null,
      status: job.status,
      date: job.date || report?.date || null,
      businessHours: report?.businessHours || { startHour: job.businessStartHour, endHour: job.businessEndHour },
      lateMinutes: job.lateMinutes || report?.lateMinutes || null,
      ownerFilters: report?.ownerFilters || job.ownerFilters || [],
      filterMode: report?.filterMode || job.filterMode || "all",
      includedCount: job.includedCount || report?.includedCount || 0,
      excludedCount: job.excludedCount || report?.excludedCount || 0,
      bySeller: report?.bySeller || [],
      reportsBySeller: report?.reportsBySeller || [],
      artifacts: report?.artifacts || job.artifacts || null,
      managerReport
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-queue/artifacts", requireAuth, async (req, res) => {
  try {
    const jobId = String(req.query.jobId || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });
    const jobDoc = await db.collection("supervisor_jobs").doc(jobId).get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    const job = jobDoc.data() || {};
    res.json({ ok: true, jobId, status: job.status || null, reportId: job.reportId || null, artifacts: job.artifacts || null });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

async function supervisorRebuildSavedHtml(jobId, job, type, seller) {
  // Reconstruye el HTML usando la MISMA plantilla actual que usa el ZIP diario.
  // No lee conversaciones y no llama a OpenAI: reutiliza los rows ya guardados
  // en supervisor_jobs/{jobId}/items.
  let report = {};
  if (job.reportId) {
    try {
      const reportDoc = await db.collection("supervisor_reports").doc(job.reportId).get();
      if (reportDoc.exists) report = reportDoc.data() || {};
    } catch (err) {}
  }

  const businessStartHour = Number(job.businessStartHour ?? report?.businessHours?.startHour ?? 9);
  const businessEndHour = Number(job.businessEndHour ?? report?.businessHours?.endHour ?? 17);
  const businessRange = supervisorDailyBusinessRangeArgentina(job.date || report.date, businessStartHour, businessEndHour);

  let data = {
    ...report,
    ok: true,
    type: "daily_manual_supervisor",
    source: "saved_queue_rebuild",
    queueJobId: jobId,
    date: job.date || report.date,
    dayLabel: report.dayLabel || ("Horario laboral " + businessRange.label + " Argentina"),
    businessHours: report.businessHours || { startHour: businessRange.startHour, endHour: businessRange.endHour, label: businessRange.label },
    lateMinutes: Number(job.lateMinutes ?? report.lateMinutes ?? 30),
    limit: Number(job.limit ?? report.limit ?? 0),
    ownerFilters: supervisorParseOwnerFilters(report.ownerFilters || job.ownerFilters || []),
    filterMode: report.filterMode || job.filterMode || "all"
  };

  data = await supervisorHydrateDailyQueueData(jobId, data);
  if (!Array.isArray(data.bySeller) || !data.bySeller.length) data.bySeller = supervisorBuildHourlySummary(data.rows || []);
  data = supervisorAttachSellerReports(data);

  if (type === "sellerHtml") {
    const sellerReport = (data.reportsBySeller || []).find(x => String(x.seller || "").toLowerCase() === String(seller || "").toLowerCase());
    if (!sellerReport) throw new Error("Vendedor no encontrado dentro del reporte guardado.");
    return {
      html: supervisorSellerReportHtml(data, sellerReport),
      filename: `SCB-Supervisor-${safeFileName(data.date)}-${safeFileName(sellerReport.seller)}.html`,
      sellerReport,
      data
    };
  }

  const generalManagerReport = supervisorBuildDailyReport(data);
  const sellerManagerReports = (data.reportsBySeller || []).map(x => x.report).join("\n\n============================================================\n\n");
  const managerReport = data.filterMode === "individual"
    ? generalManagerReport
    : generalManagerReport + (sellerManagerReports ? "\n\nREPORTES SEPARADOS POR VENDEDOR\n\n" + sellerManagerReports : "");

  return {
    html: supervisorDailyHtml(data, managerReport),
    filename: `SCB-Supervisor-Gerencial-${safeFileName(data.date)}-${data.filterMode === "individual" ? safeFileName((data.ownerFilters || [])[0] || "vendedor") : data.filterMode === "group" ? "grupo" : "todos"}.html`,
    managerReport,
    data
  };
}

app.get("/api/supervisor/daily-queue/artifact/download", requireAuth, async (req, res) => {
  try {
    const jobId = String(req.query.jobId || "").trim();
    const type = String(req.query.type || "managerHtml").trim();
    const seller = String(req.query.seller || "").trim();
    if (!jobId) return res.status(400).json({ ok: false, error: "Falta jobId" });
    const jobDoc = await db.collection("supervisor_jobs").doc(jobId).get();
    if (!jobDoc.exists) return res.status(404).json({ ok: false, error: "Cola no encontrada" });
    const job = jobDoc.data() || {};
    const artifacts = job.artifacts || null;
    if (!artifacts) return res.status(404).json({ ok: false, error: "El reporte todavía no tiene archivos en bucket" });

    let selected = null;
    if (["managerText", "managerHtml", "fullJson"].includes(type)) {
      selected = artifacts[type];
    } else if (["sellerText", "sellerHtml", "sellerJson"].includes(type)) {
      const item = (artifacts.sellers || []).find(x => String(x.seller).toLowerCase() === seller.toLowerCase());
      if (item) selected = type === "sellerText" ? item.text : type === "sellerHtml" ? item.html : item.json;
    }
    if (!selected?.path) return res.status(404).json({ ok: false, error: "Archivo no encontrado para ese tipo/vendedor" });

    // HTML: siempre reconstruir con la plantilla actual, igual que el ZIP.
    // Esto también arregla reportes históricos que tengan un HTML viejo/básico en el bucket.
    if (type === "managerHtml" || type === "sellerHtml") {
      const rebuilt = await supervisorRebuildSavedHtml(jobId, job, type, seller);

      // Actualiza el objeto existente en el bucket para que MRAPI Email también
      // obtenga desde ahora la versión linda/actual sin reanalizar nada.
      try {
        await supervisorSaveBucketObject(selected.path, rebuilt.html, "text/html; charset=utf-8");
      } catch (err) {
        console.log("[SUPERVISOR HTML REBUILD] No se pudo actualizar bucket:", err.message);
      }

      res.setHeader("Content-Type", "text/html; charset=utf-8");
      const htmlDownloadName = safeFileName(String(rebuilt.filename || "SCB-Supervisor").replace(/\.html$/i, "")) + ".html";
      res.setHeader("Content-Disposition", `attachment; filename="${htmlDownloadName}"`);
      return res.send(rebuilt.html);
    }

    const bucket = supervisorBucket();
    const file = bucket.file(selected.path);
    const [exists] = await file.exists();
    if (!exists) return res.status(404).json({ ok: false, error: "El objeto no existe en el bucket" });
    const [metadata] = await file.getMetadata();
    res.setHeader("Content-Type", metadata.contentType || selected.contentType || "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename="${safeFileName(selected.path.split("/").pop())}"`);
    file.createReadStream().on("error", err => {
      if (!res.headersSent) res.status(500).json({ ok: false, error: err.message });
      else res.destroy(err);
    }).pipe(res);
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-manual", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const businessStartHour = Math.min(Math.max(Number(req.query.businessStartHour || 9), 0), 23);
    const businessEndHour = Math.min(Math.max(Number(req.query.businessEndHour || 17), businessStartHour + 1), 24);
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 30), 5), 180);
    const limit = Math.min(Math.max(Number(req.query.limit || 200), 1), 500);
    const ownerFilters = supervisorParseOwnerFilters(req.query.owner);
    const analyzeMissing = String(req.query.analyze || "") === "1";
    const refresh = String(req.query.refresh || "") === "1";

    const data = await supervisorBuildDailyManualData({ date, lateMinutes, limit, businessStartHour, businessEndHour, analyzeMissing, useCache: !refresh, ownerFilters });

    res.json({
      ok: true,
      mode: "manual_daily_supervisor_gerencial_no_scheduler",
      reportId: data.reportId,
      fromCache: !!data.fromCache,
      date: data.date,
      totalActiveConversations: (data.rows || []).length,
      businessHours: data.businessHours,
      bySeller: data.bySeller,
      aiUsedCount: data.aiUsedCount,
      aiErrors: data.aiErrors,
      rowsPreview: (data.rows || []).slice(0, 120),
      managerReport: data.managerReport,
      note: "Diario gerencial dentro del horario laboral configurado. No marca como sin responder los mensajes fuera de horario o cerca del cierre."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/supervisor/daily-manual/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
    const businessStartHour = Math.min(Math.max(Number(req.query.businessStartHour || 9), 0), 23);
    const businessEndHour = Math.min(Math.max(Number(req.query.businessEndHour || 17), businessStartHour + 1), 24);
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 30), 5), 180);
    const limit = Math.min(Math.max(Number(req.query.limit || 200), 1), 500);
    const ownerFilters = supervisorParseOwnerFilters(req.query.owner);

    let data = await supervisorBuildDailyManualData({ date, lateMinutes, limit, businessStartHour, businessEndHour, analyzeMissing: false, useCache: true, ownerFilters });
    if ((!Array.isArray(data.rows) || !data.rows.length) && data.queueJobId) {
      data = await supervisorHydrateDailyQueueData(data.queueJobId, data);
    }
    const reportText = data.managerReport || supervisorBuildDailyReport(data);
    const reportHtml = supervisorDailyHtml(data, reportText);

    res.setHeader("Content-Type", "application/zip");
    const ownerSuffix = ownerFilters.length ? "-" + (ownerFilters.length === 1 ? safeFileName(ownerFilters[0]) : "grupo-" + ownerFilters.length) : "-todos";
    res.setHeader("Content-Disposition", `attachment; filename="supervisor-diario-gerencial-${date}-${String(businessStartHour).padStart(2, "0")}-${String(businessEndHour).padStart(2, "0")}${ownerSuffix}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(reportText, { name: "00_RESUMEN_DIARIO_GERENCIAL.txt" });
    archive.append(reportHtml, { name: "00_RESUMEN_DIARIO_GERENCIAL.html" });
    archive.append(JSON.stringify(data, null, 2), { name: "00_DATA.json" });

    (data.reportsBySeller || []).forEach((sellerReport, sellerIdx) => {
      const sellerFolder = `VENDEDORES/${String(sellerIdx + 1).padStart(2, "0")}_${safeFileName(sellerReport.seller)}`;
      archive.append(sellerReport.report, { name: `${sellerFolder}/00_RESUMEN_VENDEDOR.txt` });
      (sellerReport.rows || []).forEach((row, idx) => {
        const prefix = String(idx + 1).padStart(3, "0");
        const folder = supervisorDailyFolderForRow(row);
        const fileBase = `${prefix}_${safeFileName(row.contactName || row.phone || row.conversationId)}`;
        const caseData = { ...data, hourLabel: data.businessHours?.label || "Horario laboral" };
        archive.append(supervisorHourlyCaseTxt(row, caseData), { name: `${sellerFolder}/${folder}/${fileBase}.txt` });
      });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP supervisor diario: " + err.message);
  }
});


// =====================================================
// OPEN QUESTIONS OVER CHAT DAY — NO OPENAI
// =====================================================

function qaMinutesBetween(a, b) {
  const ta = a ? new Date(a).getTime() : 0;
  const tb = b ? new Date(b).getTime() : 0;
  if (!ta || !tb || Number.isNaN(ta) || Number.isNaN(tb)) return null;
  return Math.round((tb - ta) / 60000);
}

function qaFormatMinutes(mins) {
  if (mins === null || mins === undefined) return "-";
  if (mins < 60) return mins + " min";
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h < 24) return h + "h " + m + "m";
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return d + "d " + rh + "h";
}

function qaAnalyzeConversationMessages(conversation, messages, lateMinutes) {
  const events = (messages || [])
    .filter(m => m.timestamp)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const responseTimes = [];
  const lateResponses = [];
  const unansweredInbound = [];

  for (let i = 0; i < events.length; i++) {
    const m = events[i];
    if (m.direction !== "inbound") continue;

    const nextOut = events.slice(i + 1).find(x => x.direction === "outbound");
    if (!nextOut) {
      unansweredInbound.push(m);
      continue;
    }

    const mins = qaMinutesBetween(m.timestamp, nextOut.timestamp);
    if (mins !== null && mins >= 0) {
      responseTimes.push(mins);
      if (mins > lateMinutes) {
        lateResponses.push({
          inboundAt: m.timestamp,
          outboundAt: nextOut.timestamp,
          minutes: mins,
          customerText: (m.text || "").slice(0, 240),
          responseText: (nextOut.text || "").slice(0, 240)
        });
      }
    }
  }

  const last = events[events.length - 1] || null;
  const lastInbound = [...events].reverse().find(m => m.direction === "inbound") || null;
  const lastOutbound = [...events].reverse().find(m => m.direction === "outbound") || null;

  const avgResponseMinutes = responseTimes.length
    ? Math.round(responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length)
    : null;

  const maxResponseMinutes = responseTimes.length ? Math.max(...responseTimes) : null;

  const isHanging =
    (last && last.direction === "inbound") ||
    unansweredInbound.length > 0;

  return {
    conversationId: conversation.id,
    contactName: conversation.contactName || conversation.phone || "sin dato",
    phone: conversation.phone || "",
    lineId: conversation.lineId || conversation.inboundTo || "",
    owner: conversation.owner || "",
    stage: conversation.stage || "",
    sourceChannel: conversation.sourceChannel || conversation.leadPlatform || "",
    lastMessageAt: conversation.lastMessageAt || "",
    messagesCount: events.length,
    inboundCount: events.filter(m => m.direction === "inbound").length,
    outboundCount: events.filter(m => m.direction === "outbound").length,
    avgResponseMinutes,
    maxResponseMinutes,
    lateResponses,
    lateCount: lateResponses.length,
    unansweredInboundCount: unansweredInbound.length,
    lastDirection: last?.direction || "",
    lastInboundAt: lastInbound?.timestamp || "",
    lastOutboundAt: lastOutbound?.timestamp || "",
    lastCustomerText: (lastInbound?.text || "").slice(0, 240),
    lastSellerText: (lastOutbound?.text || "").slice(0, 240),
    isHanging
  };
}

function qaBuildReport({ date, question, lateMinutes, totalChats, analyzedChats, stats }) {
  const q = String(question || "").toLowerCase();

  const withResponses = stats.filter(s => s.avgResponseMinutes !== null);
  const avg = withResponses.length
    ? Math.round(withResponses.reduce((sum, s) => sum + s.avgResponseMinutes, 0) / withResponses.length)
    : null;

  const late = stats
    .filter(s => s.lateCount > 0)
    .sort((a, b) => (b.maxResponseMinutes || 0) - (a.maxResponseMinutes || 0));

  const hanging = stats
    .filter(s => s.isHanging)
    .sort((a, b) => new Date(b.lastInboundAt || 0).getTime() - new Date(a.lastInboundAt || 0).getTime());

  const noOutbound = stats
    .filter(s => s.inboundCount > 0 && s.outboundCount === 0);

  let focusTitle = "Consulta general";
  let focusRows = stats.slice(0, 30);

  if (q.includes("tarde") || q.includes("demora") || q.includes("respuesta")) {
    focusTitle = "Mensajes respondidos tarde";
    focusRows = late.slice(0, 50);
  }

  if (q.includes("promedio") || q.includes("tiempo promedio")) {
    focusTitle = "Tiempo promedio de respuesta";
    focusRows = withResponses.sort((a,b) => (b.avgResponseMinutes || 0) - (a.avgResponseMinutes || 0)).slice(0, 50);
  }

  if (q.includes("colgado") || q.includes("colgados") || q.includes("sin responder") || q.includes("pendiente")) {
    focusTitle = "Clientes colgados / pendientes";
    focusRows = hanging.slice(0, 50);
  }

  const lines = focusRows.map((s, i) => {
    const lateDetail = s.lateResponses?.length
      ? "\n   Demora mayor: " + qaFormatMinutes(Math.max(...s.lateResponses.map(x => x.minutes))) +
        "\n   Cliente: " + (s.lateResponses[0].customerText || "-") +
        "\n   Respuesta: " + (s.lateResponses[0].responseText || "-")
      : "";

    return `${i + 1}) ${s.contactName}
   Chat: ${s.conversationId}
   Tel: ${s.phone || "-"}
   Línea: ${s.lineId || "-"}
   Stage: ${s.stage || "-"}
   Origen: ${s.sourceChannel || "-"}
   Último mensaje: ${s.lastMessageAt || "-"}
   Promedio respuesta: ${qaFormatMinutes(s.avgResponseMinutes)}
   Máxima demora: ${qaFormatMinutes(s.maxResponseMinutes)}
   Respuestas tarde: ${s.lateCount}
   Pendientes sin respuesta: ${s.unansweredInboundCount}
   Último cliente: ${s.lastCustomerText || "-"}
   Último vendedor: ${s.lastSellerText || "-"}${lateDetail}
`;
  }).join("\n");

  return `📊 CONSULTA SOBRE CHATS — SCB SUPERVISOR
Fecha: ${date}
Pregunta: ${question}
Umbral de respuesta tarde: más de ${lateMinutes} minutos

RESUMEN
- Chats del día: ${totalChats}
- Chats analizados con mensajes: ${analyzedChats}
- Chats con respuesta medible: ${withResponses.length}
- Tiempo promedio de respuesta: ${qaFormatMinutes(avg)}
- Chats con respuestas tarde: ${late.length}
- Clientes colgados / pendientes: ${hanging.length}
- Chats con cliente entrante y sin respuesta vendedor: ${noOutbound.length}

RESULTADO PRINCIPAL — ${focusTitle}
${lines || "Sin resultados para esa consulta."}

LECTURA GERENCIAL
${late.length ? "- Hay respuestas fuera del umbral definido." : "- No se detectaron respuestas tarde relevantes."}
${hanging.length ? "- Hay clientes que quedaron pendientes o con último mensaje del cliente." : "- No se detectaron clientes colgados según el criterio actual."}
${avg !== null ? "- El promedio general de respuesta fue " + qaFormatMinutes(avg) + "." : "- No hay suficientes respuestas para calcular promedio."}

ACCIONES SUGERIDAS
1) Revisar primero los clientes colgados.
2) Revisar chats con demora mayor al umbral.
3) Pedir al vendedor actualizar CRM con próxima acción.
4) Ajustar automatización o alerta si el promedio supera el objetivo.`;
}

app.get("/api/qa/day", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || "").slice(0, 10);
    const question = String(req.query.question || "").trim();
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 60), 5), 1440);

    if (!date) return res.status(400).json({ ok: false, error: "Falta date" });
    if (!question) return res.status(400).json({ ok: false, error: "Falta question" });

    const conversations = await getAllConversationsForDay(date, 1000);
    const stats = [];

    for (const conversation of conversations) {
      const messages = await getConversationMessages(conversation.id, 120);
      if (!messages || !messages.length) continue;
      stats.push(qaAnalyzeConversationMessages(conversation, messages, lateMinutes));
    }

    const qaReport = qaBuildReport({
      date,
      question,
      lateMinutes,
      totalChats: conversations.length,
      analyzedChats: stats.length,
      stats
    });

    const reportId = "qa_day__" + date + "__" + safeFileName(question).slice(0, 40);

    await db.collection("supervisor_reports").doc(reportId).set({
      ok: true,
      type: "qa_day",
      date,
      question,
      lateMinutes,
      totalChats: conversations.length,
      analyzedChats: stats.length,
      qaReport,
      stats,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.json({
      ok: true,
      mode: "qa_day_no_openai",
      date,
      question,
      lateMinutes,
      totalChats: conversations.length,
      analyzedChats: stats.length,
      qaReport,
      statsPreview: stats.slice(0, 80),
      note: "No usa OpenAI. Calcula métricas reales sobre mensajes del día."
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});



function qaDetectFocus(question) {
  const q = String(question || "").toLowerCase();

  if (
    q.includes("tarde") ||
    q.includes("tardó") ||
    q.includes("tardo") ||
    q.includes("demoró") ||
    q.includes("demoro") ||
    q.includes("demora") ||
    q.includes("lento") ||
    q.includes("lentos") ||
    q.includes("respondieron tarde") ||
    q.includes("se demoro") ||
    q.includes("se demoró")
  ) return "late";

  if (q.includes("promedio") || q.includes("tiempo promedio")) return "average";

  if (
    q.includes("colgado") ||
    q.includes("colgados") ||
    q.includes("sin responder") ||
    q.includes("pendiente") ||
    q.includes("pendientes")
  ) return "hanging";

  return "general";
}

function qaSelectRowsForQuestion(question, stats) {
  const focus = qaDetectFocus(question);
  let rows = [...(stats || [])];

  if (focus === "late") {
    rows = rows
      .filter(s => s.lateCount > 0)
      .sort((a, b) => (b.maxResponseMinutes || 0) - (a.maxResponseMinutes || 0));
  } else if (focus === "average") {
    rows = rows
      .filter(s => s.avgResponseMinutes !== null)
      .sort((a, b) => (b.avgResponseMinutes || 0) - (a.avgResponseMinutes || 0));
  } else if (focus === "hanging") {
    rows = rows
      .filter(s => s.isHanging)
      .sort((a, b) => new Date(b.lastInboundAt || 0).getTime() - new Date(a.lastInboundAt || 0).getTime());
  } else {
    rows = rows.sort((a, b) => {
      const av = Math.max(a.maxResponseMinutes || 0, a.avgResponseMinutes || 0);
      const bv = Math.max(b.maxResponseMinutes || 0, b.avgResponseMinutes || 0);
      return bv - av;
    });
  }

  return { focus, rows };
}

function qaFocusTitle(focus) {
  if (focus === "late") return "Clientes con mayor demora de respuesta";
  if (focus === "average") return "Clientes por mayor tiempo promedio de respuesta";
  if (focus === "hanging") return "Clientes colgados / pendientes de respuesta";
  return "Reporte general de chats";
}

function qaStatusLabel(row, lateMinutes) {
  if (row.isHanging) return "PENDIENTE";
  if ((row.maxResponseMinutes || 0) > lateMinutes) return "TARDE";
  return "OK";
}

function qaStatusEmoji(row, lateMinutes) {
  const status = qaStatusLabel(row, lateMinutes);
  if (status === "PENDIENTE") return "🔴";
  if (status === "TARDE") return "🟠";
  return "🟢";
}

function qaClientTxt(row, date, question, lateMinutes) {
  const lateDetails = (row.lateResponses || []).length
    ? (row.lateResponses || []).slice(0, 10).map((r, i) =>
        `${i + 1}) Demora: ${qaFormatMinutes(r.minutes)}
   Cliente escribió: ${r.inboundAt}
   Vendedor respondió: ${r.outboundAt}
   Mensaje cliente: ${r.customerText || "-"}
   Respuesta vendedor: ${r.responseText || "-"}`
      ).join("\n\n")
    : "Sin respuestas tarde según el umbral.";

  return `SCB — REPORTE DE CHAT POR CLIENTE
====================================

Fecha: ${date}
Pregunta: ${question}
Umbral tarde: más de ${lateMinutes} minutos

ESTADO
${qaStatusEmoji(row, lateMinutes)} ${qaStatusLabel(row, lateMinutes)}

CLIENTE
Nombre: ${row.contactName || "sin dato"}
Teléfono: ${row.phone || "-"}
Chat ID: ${row.conversationId}
Línea: ${row.lineId || "-"}
Stage: ${row.stage || "-"}
Origen: ${row.sourceChannel || "-"}

MÉTRICAS
Mensajes totales: ${row.messagesCount}
Mensajes cliente: ${row.inboundCount}
Mensajes vendedor/bot: ${row.outboundCount}
Promedio de respuesta: ${qaFormatMinutes(row.avgResponseMinutes)}
Máxima demora: ${qaFormatMinutes(row.maxResponseMinutes)}
Respuestas tarde: ${row.lateCount}
Pendientes sin respuesta: ${row.unansweredInboundCount}
Último mensaje: ${row.lastMessageAt || "-"}
Última dirección: ${row.lastDirection || "-"}

ÚLTIMO MENSAJE DEL CLIENTE
${row.lastCustomerText || "-"}

ÚLTIMA RESPUESTA DEL VENDEDOR/BOT
${row.lastSellerText || "-"}

DETALLE DE DEMORAS
${lateDetails}

LECTURA GERENCIAL
${row.isHanging ? "- Este cliente quedó pendiente o con último mensaje del cliente." : "- No quedó como pendiente según el último mensaje."}
${(row.maxResponseMinutes || 0) > lateMinutes ? "- Hubo demora superior al umbral definido." : "- No superó el umbral de demora definido."}

ACCIÓN SUGERIDA
${row.isHanging ? "Revisar y responder hoy. Luego actualizar el CRM con próxima acción." : ((row.maxResponseMinutes || 0) > lateMinutes ? "Revisar por qué se demoró la respuesta y corregir seguimiento." : "Sin acción urgente por tiempo de respuesta.")}
`;
}

function qaClientHtml(row, date, question, lateMinutes) {
  const status = qaStatusLabel(row, lateMinutes);
  const emoji = qaStatusEmoji(row, lateMinutes);
  const color = status === "PENDIENTE" ? "#dc2626" : status === "TARDE" ? "#d97706" : "#16a34a";

  const lateRows = (row.lateResponses || []).length
    ? (row.lateResponses || []).slice(0, 20).map((r, i) => `<tr>
<td>${i + 1}</td>
<td>${htmlEscape(qaFormatMinutes(r.minutes))}</td>
<td>${htmlEscape(r.inboundAt || "-")}</td>
<td>${htmlEscape(r.outboundAt || "-")}</td>
<td>${htmlEscape(r.customerText || "-")}</td>
<td>${htmlEscape(r.responseText || "-")}</td>
</tr>`).join("")
    : `<tr><td colspan="6">Sin respuestas tarde según el umbral.</td></tr>`;

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>${htmlEscape(row.contactName || row.conversationId)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;max-width:1150px;margin:auto;box-shadow:0 8px 28px rgba(0,0,0,.10)}
.badge{display:inline-block;background:${color};color:white;padding:8px 13px;border-radius:999px;font-weight:800}
.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin:18px 0}
.box{border:1px solid #e5e7eb;border-radius:14px;padding:15px;background:#fafafa}
.metric{font-size:26px;font-weight:800}
pre{white-space:pre-wrap;background:#f9fafb;border-left:5px solid ${color};padding:14px;border-radius:10px}
table{border-collapse:collapse;width:100%;font-size:13px}
td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}
th{background:#f9fafb}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="card">
<span class="badge">${htmlEscape(emoji + " " + status)}</span>
<h1>${htmlEscape(row.contactName || "Sin cliente")}</h1>
<p><b>Fecha:</b> ${htmlEscape(date)} · <b>Pregunta:</b> ${htmlEscape(question)}</p>
<p><b>Chat:</b> ${htmlEscape(row.conversationId)} · <b>Tel:</b> ${htmlEscape(row.phone || "-")} · <b>Línea:</b> ${htmlEscape(row.lineId || "-")}</p>

<div class="grid">
  <div class="box"><h3>Promedio respuesta</h3><div class="metric">${htmlEscape(qaFormatMinutes(row.avgResponseMinutes))}</div></div>
  <div class="box"><h3>Máxima demora</h3><div class="metric">${htmlEscape(qaFormatMinutes(row.maxResponseMinutes))}</div></div>
  <div class="box"><h3>Pendientes</h3><div class="metric">${htmlEscape(row.unansweredInboundCount)}</div></div>
</div>

<div class="grid">
  <div class="box"><b>Mensajes cliente:</b> ${htmlEscape(row.inboundCount)}</div>
  <div class="box"><b>Mensajes vendedor/bot:</b> ${htmlEscape(row.outboundCount)}</div>
  <div class="box"><b>Respuestas tarde:</b> ${htmlEscape(row.lateCount)}</div>
</div>

<h2>Último mensaje del cliente</h2>
<pre>${htmlEscape(row.lastCustomerText || "-")}</pre>

<h2>Última respuesta vendedor/bot</h2>
<pre>${htmlEscape(row.lastSellerText || "-")}</pre>

<h2>Detalle de demoras</h2>
<table>
<thead><tr><th>#</th><th>Demora</th><th>Cliente escribió</th><th>Vendedor respondió</th><th>Mensaje cliente</th><th>Respuesta vendedor</th></tr></thead>
<tbody>${lateRows}</tbody>
</table>

<h2>Acción sugerida</h2>
<pre>${htmlEscape(row.isHanging ? "Revisar y responder hoy. Luego actualizar el CRM con próxima acción." : ((row.maxResponseMinutes || 0) > lateMinutes ? "Revisar por qué se demoró la respuesta y corregir seguimiento." : "Sin acción urgente por tiempo de respuesta."))}</pre>
</div>
</body>
</html>`;
}

function qaSummaryHtml({ date, question, lateMinutes, qaReport, rows }) {
  const tableRows = rows.map((r, i) => {
    const status = qaStatusLabel(r, lateMinutes);
    const color = status === "PENDIENTE" ? "#dc2626" : status === "TARDE" ? "#d97706" : "#16a34a";
    return `<tr>
<td>${i + 1}</td>
<td style="font-weight:bold;color:${color}">${htmlEscape(qaStatusEmoji(r, lateMinutes) + " " + status)}</td>
<td>${htmlEscape(r.contactName || "-")}</td>
<td>${htmlEscape(r.phone || "-")}</td>
<td>${htmlEscape(qaFormatMinutes(r.avgResponseMinutes))}</td>
<td>${htmlEscape(qaFormatMinutes(r.maxResponseMinutes))}</td>
<td>${htmlEscape(r.lateCount)}</td>
<td>${htmlEscape(r.unansweredInboundCount)}</td>
<td>${htmlEscape(r.lastCustomerText || "-")}</td>
</tr>`;
  }).join("");

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Reporte QA Chats ${htmlEscape(date)}</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;color:#111827;padding:24px}
.card{background:#fff;border-radius:18px;padding:24px;box-shadow:0 8px 28px rgba(0,0,0,.10)}
pre{white-space:pre-wrap;background:#111827;color:#d1fae5;padding:16px;border-radius:14px;line-height:1.45}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff}
td,th{border:1px solid #e5e7eb;padding:8px;text-align:left;vertical-align:top}
th{background:#f9fafb}
</style>
</head>
<body>
<div class="card">
<h1>Reporte de Pregunta Abierta — Chats</h1>
<p><b>Fecha:</b> ${htmlEscape(date)} · <b>Pregunta:</b> ${htmlEscape(question)} · <b>Umbral:</b> ${htmlEscape(lateMinutes)} min</p>
<pre>${htmlEscape(qaReport)}</pre>
<table>
<thead><tr><th>#</th><th>Estado</th><th>Cliente</th><th>Tel</th><th>Promedio</th><th>Máxima demora</th><th>Tardes</th><th>Pendientes</th><th>Último cliente</th></tr></thead>
<tbody>${tableRows}</tbody>
</table>
</div>
</body>
</html>`;
}

app.get("/api/qa/day/download", requireAuth, async (req, res) => {
  try {
    const date = String(req.query.date || "").slice(0, 10);
    const question = String(req.query.question || "").trim();
    const lateMinutes = Math.min(Math.max(Number(req.query.lateMinutes || 60), 5), 1440);

    if (!date) return res.status(400).send("Falta date");
    if (!question) return res.status(400).send("Falta question");

    const conversations = await getAllConversationsForDay(date, 1000);
    const stats = [];

    for (const conversation of conversations) {
      const messages = await getConversationMessages(conversation.id, 120);
      if (!messages || !messages.length) continue;
      stats.push(qaAnalyzeConversationMessages(conversation, messages, lateMinutes));
    }

    const qaReport = qaBuildReport({
      date,
      question,
      lateMinutes,
      totalChats: conversations.length,
      analyzedChats: stats.length,
      stats
    });

    const selected = qaSelectRowsForQuestion(question, stats);
    const rows = selected.rows;

    await db.collection("supervisor_reports").doc("qa_zip__" + date + "__" + safeFileName(question).slice(0, 40)).set({
      ok: true,
      type: "qa_day_zip",
      date,
      question,
      lateMinutes,
      focus: selected.focus,
      totalChats: conversations.length,
      analyzedChats: stats.length,
      exportedRows: rows.length,
      qaReport,
      rows,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="qa-chats-${date}-${safeFileName(question).slice(0, 35)}.zip"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", err => { throw err; });
    archive.pipe(res);

    archive.append(qaReport, { name: "00_RESUMEN.txt" });
    archive.append(qaSummaryHtml({ date, question, lateMinutes, qaReport, rows }), { name: "00_RESUMEN.html" });
    archive.append(JSON.stringify({ date, question, lateMinutes, focus: selected.focus, totalChats: conversations.length, analyzedChats: stats.length, exportedRows: rows.length, qaReport, rows }, null, 2), { name: "00_DATA.json" });

    rows.forEach((row, idx) => {
      const prefix = String(idx + 1).padStart(2, "0");
      const status = qaStatusLabel(row, lateMinutes);
      const folder = status === "PENDIENTE" ? "01_PENDIENTES" : status === "TARDE" ? "02_RESPUESTAS_TARDE" : "03_OK";
      const fileBase = `${prefix}_${safeFileName(row.contactName || row.phone || row.conversationId)}`;
      archive.append(qaClientTxt(row, date, question, lateMinutes), { name: `${folder}/${fileBase}.txt` });
      archive.append(qaClientHtml(row, date, question, lateMinutes), { name: `${folder}/${fileBase}.html` });
    });

    await archive.finalize();
  } catch (err) {
    res.status(500).send("Error generando ZIP QA: " + err.message);
  }
});


functions.http("helloHttp", app);
