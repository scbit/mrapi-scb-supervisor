'use strict';

const functions = require('@google-cloud/functions-framework');
const { Firestore, FieldValue, FieldPath } = require('@google-cloud/firestore');
const multer = require('multer');
const XLSX = require('xlsx');
const crypto = require('crypto');

const FIRESTORE_DATABASE_ID = process.env.FIRESTORE_DATABASE_ID || 'scb-hunter-bd';
const db = new Firestore({ databaseId: FIRESTORE_DATABASE_ID });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

const APP_NAME = 'SCB Hunter Campo';
const LOGO_DATA_URL = 'data:image/webp;base64,UklGRohNAABXRUJQVlA4WAoAAAAoAAAAXQMA8QEASUNDUKgBAAAAAAGobGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAF9jcHJ0AAABTAAAAAx3dHB0AAABWAAAABRyWFlaAAABbAAAABRnWFlaAAABgAAAABRiWFlaAAABlAAAABRyVFJDAAABDAAAAEBnVFJDAAABDAAAAEBiVFJDAAABDAAAAEBkZXNjAAAAAAAAAAVjMmNpAAAAAAAAAAAAAAAAY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD//3RleHQAAAAAQ0MwAFhZWiAAAAAAAAD21gABAAAAANMtWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPVlA4IPhKAACQXQGdASpeA/IBPkUgjkUioiERWXT0KAREs7d+FxzF5H78wg6gDJANXDQH8/3JF2Oq/kb/Tf3D+ceqvy7+ffnj+r/tf0NtC+dH49+U/4n+nf3j/lf3//////8C/7n+7ezXzAP4V/DP8r/Y/8j/2f7n/////9V37Ae5bzAf1L+t/9r/Ye8l/g/71/mfcd/YP8B/n/1u+QD+if23/sdgP+5fsAfzr+3+rp/mv/R/lv32+iL9kf/X/nP3/+g7+e/2b/vfn//8foA9AD/jf//2APUn6Wf1z+7/sP/Z/kj3l/Z/7v+2X9a/9PvL+M/Nf1r8j/7v+0ftYeLLq3zP/jP1o/C/23/Ff7v/H/tX95/4H/c+Cvyp/yPUF/FP5J/ef7j+0P9+/anjxdw/dr1Bfbn6l/l/71/jP+b/Y/hh9//0/+F/dH3U+z/+6+4j7Af59/YP9t/g/3v/wn0B/x/CE/J/8n/gf534Av6J/eP+3/h/dm/of+v/lP9b/5f91/////8Zf0D/F/9j/N/6r9rPsM/lv9Y/3H9//e//Nf/////dr///c3+5f//91D9o//+Nz3FvhPx4MhAuEJrfCfjwZCBcITW+E/HgyEC4Qmt8J+PBkIFwhNb4T8eDIQLhCa3wn48GQgXCE1vhPx4MhAuEJrfCfjwZCBcITW+E/HgyEC4Qmt8J+PBkIFwhNb4T8eDIQLhCa3wn48GQgXCE1vhPx4MhAuEJrfCfjwZCBcITW+E/HgyEC4Qmt8J+O2dxX7HvOqnGpi698D0/QRxTcRJ0LDzPRWp/FKj4JRyUlia3wn48GQgXCE1vhPx4MhAzL3rHqnvAMrju5pk6XN4D8VF7NwAuauFea9ZCQSi398RDKOoelia3wn48GQgXCE1vhPtJwDqzLo+euHTLltuwOyLWEtxs0mPMnwoL895yTR2OeeAQglHDwc/gbwSPpqn4SForjmlia3wn48GQgXCE1vhOi7eHJj7Z9Z/zvrYKNsCcohpg91xTiKp+x47R/yKZUhatQfCudZl/QTb3ZDHQsRBjGkMfPhLFFn0PC/71EV2nmJLyX9yd0csEymjRy32yg0rvIl97SX6JpBgVROCmBsrNxP4/wUXq6pXsTV1BM56xpISCUclJYmt8J9qMrjO/9kCrdxCdIWd9hEjJ0wD0xmO2rqBQlZAIEtX2PflnvF0scC+Vb7BovdBgjgyi7WIGsvGtHrs754F+XpCwpONCACgwzDeVs5Yldm/Rr58OxKMqlNjm3aT6qpEvb0VFtL6HGEglHJSWJrfCdGHKXEVIAwPkkdHau8ads0jyfeoTtGv6sGF+3nkmfdyJCIBX8b+s88LOQPpwbHAjoVTDpRgRTjciThD2fj+6+c+/6XgKtglgyeGyJm1uanpYmt8J+PBj7DVSnYKmJTQ2ATwCyJHj8PwekRI8Pq4ge7n70pdf8AQLsd1kJHH/7wgX9H5w8nYF59/+B/iXVUEYF6PU7oPJqx9kaIYKqXmUpzSyadjrd7AYY5dunL5mIhmnBqHxXcm+6EN4inffFFH9KKknJYmt8J+PBkHSEEeFFzMFAymnxnhoQFuW+9XaBcITWB19U3w18BwCIEJpo1B7iTksMP0auPoSNaK2HJSWJrfCfjurEyPUIrFReAJq16ARhZH3+rlYTW+E+3SFCYi+tCFwydfWL31V5u8CTXSJgbu+k9DmjJcyREVhKsIwDnIdS3Yw+6VqmAOy703ixjy5Iv7XIYUpjccvjorDS5BLlxA8Q+5sKP5HzM3KOY/DRkx5WX6Li+PBkIFi1uYGs2RIJr89vVQBROh8Szwmt8J2TIdaTdOqmwbNkWGyK6HoG4Iu9ypLmCg4kUuFQZ7J55wPWjNlEyi1mhC5BFke0psauqW8ZW05v0pFEVlceqXAvDCQGAmCgP0P3vl/uYTA79aD7oA3cvywuXm7/yxnzZ9rk4t8J+MacLLmtUCWj47nN97DOpyxE1vhOyX5nsDk2noa+YHoRffXUSIiplFevox1zpGD1q7pmN7hPREqzzLQGFCL8JzR04G/tdNK2dylPDEjhs++VnTyPmGbRmVccoxcKik/VZLAdUUeqaKu41IZ57wXCE1ujpqkZFUcAE6IL55oRrkZ8wNwSjkodPTG+mFo0AC7dXCzLBQScDnK3X2IGlSNr6xyh58OZqW6vZu2blNNH0HthrGDc+nHnScQECsTfz8kCXjOLaabpqyFIu7C8BsDv/0ooDyoXkfd27UtscIxE3mE+bavp72kWJrfCdIFaOr2B6PaZBuB9aSotyQWn06W9XE/GV2PGf6WMwhotNWVRsiH22DjHViqxEjyuwl/n9KPm1w8GEQapVxrwwkRx0GYxGDkNGZ0KIUAzsvayB8kXzLjiVeSomSjkpLExri7iAWK6A3SxdzJdCFdG+HVRcFRvaksTWPK0PlNz43e3sadOEWyLVHkqua+U8wkMD6uOXAntHOjS7WuLr2HfMZ6Jq9UvuSvMSYk8elia3uYV9gq9MPO7kYwsfGsZ0NmmKMxFS/cLEOSkiEaHd6kAgp/wPaWPpe1CTPKoY9MJC4HVWsc7NTafEfjAya3ashLoZ2GGjg7yyWMwJC9YHZ7YLL9LUy/j+QrUnFJ0GNgD1nPBH4gtJUEqV8WJrfCfjwZB0u9Jp5bnKe+sryJyAQ0cT/GbX5X78SLOqJCA2uDe4NvDpoOgCSGjsB7Qxri8NJnilrCRMUznYTQrOaCNO0pfuwb89kbHCY3wYMmGhFDJr8ITW+E/HgyEBPAURcjwaUc1L7KKHfiOP9zzCWCU5h8HWpj4urE9Dmu8iE+gD8WeajNwzxO4GDF7liN5hE7juLzvahm4zEPk7kKIjtSozr9bxdPALPu+pi2HNZAHJtkul9MkQVOmPh27VoYmSxNb4T8eDIO3prFAwETEqmj53wPeDxvt/J9PG/p0AjVR6NQJZRnNl41PHDFssNkeHf5vmNgi3fA1zRXvsFTb8d0iOLt77jZ2WUyB/m7XAapoAj84IeOCAl8+qZI5Mldd/9Ph/f+EbwQ/a1Q5ulia3wn48GQgXCE1w0ZrkpLE1v2qGz3iTx6WTBVxPx4MhAuEJkaHcg0sOwLimxN1mseCEJS3Ye7SdGrNuFWyP/vmq0W80zBNipnzR6B3R0A7AqKVbmnsrM1YOJdwirsxw1aN5bGLgBbQltd2KTaOLMYvuGCcH7jrii0Lwjf39jhffvrt5ylI3IerH33pU5HArS1U+VDMrdCQmJqYttY/wCP6E7K10O/pd8nJpxGGJf/ssMKG9txomSxNb4T8eB8ZdKLC2SEKrb3aDCqXwU/Irb642NA2mUVtQm75g3SzmKZ00d+zszWeBDHOKAXcWie/jwCsnjlW7rNP0PjfpsL99oFGE0H6GnQjcfMOOmA5V1dEJUsYC0RyCV2FnVooPSuY3PR7xRy+pVkgwGml7Q1kMTXdB6NfYoR2J3tsTLXUtiexf3Zs/eaNjt+208ltR3wCXibJMjF5NtFN3ai3WKZGmeO8IFFKbzTLk9LVe2npYmt8J+PBuclJYmt8J+PBkIFwhNb4T8eDIQLhCa3wn48GQgXCE1vhPx4MhAuEJrfCfjwZCBcITW+E/HgyEC4Qmt8J+PBkIFwhNb4T8eDIQLhCa3wn48GQgXCE1vhPx4MhAuEJrfCfjwZCBcITW+E/HgyEC4Qmt8J+PBkIFwhNb4T8eDIQLhCa3wn48GQgXCE1vhPx4MhAuEJrfCfjwZCBcITV4AA/v4IIAAAAAAAAAAAACN5ZjYt+45f1Cx3q8KMb7HA3Y37hHkn+6j10seYy2YG2UEdkBNHxIKr8xlsvtKqNd3Y9TxLbB4o4LoJnGkhODeEYIC0aBOqqK75ITOBc1WLOaSw0s6fFDn8HM1E0OsNyS1jofkJGtm3WyQLlt6hbLzH9xOvP5M3D58zbs++5uyK0PpCOK9zKQaGEiPW4VYrBa/xH0Mr8iYGCRQQJc2sbUUhETip1eIEmFDEqVlGZwZpEzd5qRYZqAnuo2/D/tB4zH3bYSftPYQ/Kij3ohp7RycacJyDVnv4PwhImKcOqL7JTjwnuN0Lk5hZsKy1Or/v6pbYZlMypwsC4Hwvh5ehYOHK4N7fqMyI5/AYBTFqe0s07AJiRY738EBIpmXLD/etHrFXoilA8P6WFCu7YIgAJlOJqz4Xn4tqpnzueg6IS7T0w39FUPy/uVZHTn+4NWc1VAvnxjYyC5VGMkrSvLIOsFwowM6kfQrce4dUhWPNn8vb4Weetn4Q6TTVsnPqSd0jmgReEq4rJNofKZtY5Lc4RR4VZ/7EhWU3tNL0rRX+h/p/nfzfP1YjLnlFOgkt2uqql2+dhzZK9RAABA6N8iFULv0hWIXoCrd2Q5sDjhJmDNLvdl5aACu03nbgOfg0nVBGPLY3ztabQIhpQpx+sf2GK6pmV82n2XAmr+HWnpxYGM9KYh+dXKjAfMFaY/HJCSmwS0CJL4kFpFnzw5J8jLxzQLXI1ctMZloI8R2SadHk9mKGTzTxXDxLt1gITf0PO12mUN1MeRIEx6jCBhmdvCK5AzF7b7Z7/XnK3KpYHk1EPgfb1qOs5mud88yKZWPV/EE4fRKW3dXecj7gAtCZzgC5zQE/boFPrPoP2LEtlZoMh8Ac8D0h92WaeCHNSHisvzr3HWf90JQZDXTacqVsA59C32B/ce44GRAMFaPQABhNbW5ngMXm2XgcAMYbcH2g8L0oHOlYjUIqgq5C1na3PvZ5HVNr1SzSxG9VXghAFKeJiBxueSEFrGiBdT60BBJupY/d7VSRgGYcewifE19ihBcE7gcpvVIxp/idwz9zQ1E6rfD5V2lGQhQ8UHLkBt6aNdsoJjAhp9Q3n8UQb1Rahv7RRlkaaVRYccmyU4z1Mku6lro2Gsf0SGbaHAvNFza/vh7qZwz4Ztg3eLG4Cwo00S/81ITe831CPCh4Kjrz0vt9+MQKDVkvTfPYm0DXxhg+6PvvocuxURUwI+yva20CU8GMgaMeSvIKykJsg0pH+24eVa+wJJYeVzADNHa3W4XBmyarvRcgCWr9gPwjBTIQSRbaqs+pqULdstUfCu7WD0LV5AkBK6nSh4fBPoD639bAQYVOd19NYgqPzBa6auBU2eeYMB+rAFd+VtAkrQ0CL6ltXR+b/9dKfpWADz983ZZ8jvsVezBG7alK/wjiyVedfF3YeOR8UIXqbBRYD5DS5uIuMoPB7bnb7TL3u6vGJcIuinBq1Aul6b/WjDKTczrqIaZH6I7mYEdBVmDqqKrl5ntuy02qoBJ7ABzrYzVznATnBFY5lTItiYg8IX6TG7ROzJdhg7P91k7R3bk9UJw8PeiYaV3OM/8BjTdG49lArEHMMXDbA5opdjODxjR/HqDlTdU1vqxWekYqRd8qCBh8yWJlGzh2p+Wdi7n3dm+XrbvIGnNFqNXnercEznG9gAU67g+3+hdnG3lYNsIF5v2KRzRjBW/cjib6YB+sBFESZw8b+yMaH2+gJQxToOswvgvoggLCTugzsYYdGff3bAUGTPm59UmV2Pd7nwZWHwC/smUcuTo2ZQ2CqnIDc762CJ7VMTxXLd0R5auP3L+mxGos3aAia7W/fkSYBN2DMRpbjgR8DKsRnE9jVWagV7DtmCYOu3L+z6UBPk7oVcGHAZHugia2cJZzPY4k4IwR9TIp2Mz0iEOkthTsxVG412O70Htaw+ImMZFVZ4e7TK73QtcqxZGc931rUwca09GZTWGsz33fbSB8lmTAvQv/YhwOPJwQsEl0G9mU8+TcRVKu67F+ZVm5vSy8i9bhvQqLG8wmw+lwvApEoMUsjJWd9fXTGfWBUEjtn6Aij05KvfW11EPq2SPWXFAAqqbF7oF4PyOknQCMCTnStRYg6ebSKGLijOkbU0IvSw5Ez0aNnGdbRJbW8g1Tbi/Ug2fJiqfr4KhWRT2dNbWNavFlg11jRPzi5s+cTa3PS9dTZbLNpw1kMcql48tw69NwR8DMXEhDuzZiF90MKd2dmDQVARxFy/14lGeO0BXp8sdaJIpTPRlM/aV+h9dpine70AIigFyjgFeaj0Uc3YzYGT8aeVHJngoZ9FA+GcszOErTw1Y+5hX6Qt6BwgM8LZ5qsww9k2tDClTHB1NB3P/D1JlW51Yq+4Xi53MnY2S36fH98gxkll0Fbu1VhPPPW2S+us1uzlrmqH2jj8vD4qEKubr+SeFNal3KQfkX0i5zk14WYmhIJfHCBH35Zvu4NOcmKd+0dJpXJy9stBe283GfbNn5/qIye5NPJygtWhoo+G4J31JR4z1hGRLkRElmkNpErI95MgSD3Yr5G+l0JJPMvrWpvIAA+zVMgpkNN1kc2uZSnZ4IkO8EdpJULcmgrgkY6d8aKkshRz5RyyhHJgRyu2nt2k9EC/SyOf2p7NL1EwmF9jfMv4OkhpPj/xTThDp7nqWTFe79N1y8Gdudi/S+CBmR8iLtzS+NMJfkK+rLBicwJgvVzTLf5A6biBEby8zXotI7h2uWeSd1hghkJCJBDZL9OItJSKzo9pJ5umMEPbj2Qeuu+ec7p8UXVfYa3Wgo2PKI35k24drqixuByXY/NQ4sRIauvDuusT93XmncSn6Qu1ebaTGSj8bTcc1KqDHfJVblnt4mkpP1QpJo2tEQXik3+TPmxRuCG2KSPvv7MmhF9myxLVyoTUdu4LBVf575JNjNfeMs8KfBQmT+/f5AsrkBx+q0fDzjS1n/Hp11FRPAoLyLAuRap/ECR0Q7Ij/uKvoT9/SEuBDXWbQhWwrz9pxdf+wDp24Y/yh7SwvBSbIxluBpH6UZlv3x8gDf7U3bSd6e4v4WyOaHiaD18yp52rf+h3HnsKQN+0g9rRTX3KSQYQlwu1PhC8kUWSIDNAMLk0N0cihpsLq7PP9uAOk8y+sIcMYA9+U5xyBZJdlEYMywD7YKIz6KUbSszEZbrw2xkPAtqUql3550DcUNcRPu0F/Kg5ehOT7arnnK2sg1YBjyStWUlBRJcNT2LG/t7f2wQ3yDLfRWZBgYPSpWFWdGFMt1hYStbLKFxdnl8jhwOjurOAzQic8G33vwF9sQ1lMb/KXU4eV2bpFDXMREz1wxgse8mz8Uwxd8TsBI3Sm6LtUoOWi/yuDskXGY/9TOheRpGep2iPd2r8Jf9wevCnSxoXk9ouTjEBQh5lM4AUyRWRjwZfbsjzQC4gFwb/RsGjWbF1Ifz4sqRFKkLquxCAP3IxFZ7TOC3nlX53Opa16gZOWwlKqg0KtWIiXIfbecUQZYBWCJbkTZoxBHdJAmLEi7S7uYU8O3KQYmSZm6KAPa6eE7+0GIh1ffrf1h5UMRx+9HVkqAJRAtVmy6nxNLnYcvX0LRd4fUSCQkrPv0TQmEbwi48xcGbWS4nMusbLLnX8DMAEY08EeYi20OH44cRrSW+vAFbfO5BmpL+wcqxayUH2AC7o8L0Pr9CfaPPcMEE2/eAbt5n8BCQp7qXLz2IuZuFg1Kpa9UZ0n23syWxC9oNFb34BDYX64eYS9hVUW0Oimc44O0NI3P+I94TwOZJPib4BtMRomTBAa7zbscXQWmM33sB9uz0Dk0gS42H2ZDmM4mggr5zAnwhr/PlSjHd5OwWlYvKdoDOeoTZ3HwHNbGlQDV4TLKVPcJ+sbMPplWBd9YrkTqhd3F9blKJmYgHC6R8OrvbrNsRNy8s3c4BxbHatu9WnkUCPtZm12Txss3zd9LTPy2QylZsRfD8RTTFRE+WRIe/f5O0PCTztb0ndFaT313KQjWdwkGG8fBqsgjpoatsu66NKraiv03WqcELIBqBVIf8AfqfNl9t6gyO0qZHYYhJz/xynBzUq+vyzno4BeeZd+z8gegdoLsJYXCFRaXBLjfskjkOyZ5O3m9lVK93kxjuiB4npfxzLHK2HmxkUKuKhnnHAoKyUzrw6+9WuuMhzaQaagM63PThwgSC/FYuXLp4mz9Aop6/sAUiATIJ20DcqjumobYlHNIAjMlmtYNvWrEuwBlFVjQl7WTiQmLHDw6NyF6M4trvbiR+CV+fIBoYqb2To8gFEDP3pvZvXRRTE85H+PElRNCiEArAAK9A/MVYoyeTSHBxrGjcQ7LACjCnRwPqXfxE8Jkw5OlhUHyyabbPO2L/2rmNPRDZLWV7AjOUg19t+YmZfg3aD8Xg3Iij7UB1/njWmciHcG1tnk74vq8IY2cjYQ3NjfZd9bKf5gW8SGu/ug/9DrQqXLB8oCXeDKVWeQux/eIldybopMULx2sguJnF/Gc/Ot2XrcY9EVvLmMfbzc5Zuffzv8ON4bPMS4VjWDACKd7sBRKgrJG91/U2/mfsBpitd6R+P9YzCQH5Ecibonx3b0DJHauouFXRioz7a63AuBKL7g2fHMgvO4WiJLaqedFm9gi2FVyYYAZFp0fgmqOci3QT8QXnb1PcHSmIPHdJkYg2x6+euOCF5C+LZLWPp2VEJ2i42ZKR245hcuvCnp36P4Ne5MIWJ6AW8FFg6AiQI4knTkBtfVKISM8hvfUU6rfuXAQZfW/QJOByIUd6L69RZwj1lwww+daYC306Hk/O0hXl8lxEXMMDtcuzed/19XhJRFZpC0wyHujUgQ6mDy2h88vNchRFhfs15o5PkVCDsbE7lucOrQ5yFyj973yxyOkIJ047VnMsrvsURpW5bCNcDhGSm8v2jIPsJZuJFQRmPsuFGiQNqNPH2AVicuVljmnpehkoldFwtBqkMUXQFzUoXNCptSvgT/Y0Y46doonpgNT7USXsLGDavrA/xtnjUWpRpDi1wsCxpclwScsgp/PGOokUtH3bJfD3sPAsdg7wDt6cInEhLB+peG71jLCZZAdx13a6LxM6tLlCjq3eVq5R30gDuGIjmE52jHOD9pWQ3qxee/OZAENq0pN4YaKEm/cXA6SYmZwv/r63VOsgLsx6F0NCpEqgoaycu38KbpcK8zgvRATVJzgaOhmqyGwnI4qLQEQYwVWA6B4I/6wcpkRhOLlrrVeI/cMQpL8yb5gzdg0APEtMZDONFC1kcKzzFWKMnk0iDhUt9Omg2XQzFA1USNR6OB9S7+IrN/DuUHzV8gSLpzVl7EEVzgCXMMCAsldX7znvef6t9IfoCDPgYNxcks8G7Fix5NE/YSU1S7RZFowOpq18YBzvmZBRSYYxJa7AWvUVtekuEhCPwW3II4KLjy6o8/HdguRVl1gX5Do8h+oXdYdT9zZAPMUqY6wD9pjcdT915juP4JtWv9E5vByCTC5O7Tpgz0i0YkFBrYjfCR23pOsrGJBhE/pqDQc/80ce1h4awXDo3V4OOo0fGabvXTMkC4l4l+wuP99Cmf+t7zBPVNp8OdHZDAJNg9XEMq/VbLjWrRJp/BMBr/gKfKiavPAforZ/tdyYuDbXdS/ju2s/02/djyk7/VxDBik7Y0pJz/I/Pdf0jKHwQizWbnJvlA5B2xshkSWco8cYHFp3P7tfiW1TB7nbDk0l1eHyv7svuxwGULaHYd/vodLikch/qjhryghqNNPYcZ7qjlFqrGLvJSXTdiRLG1gWCWwObJ7O+IMcGnr7BJmVkR+iN+2zhs0xqGzFJXwfq3Q9ruYGHt53d3bJaiDy06HC7b9eG9cVaz7NgmYaNGabSdyuKMc/Cw7HYSahzKrLRYtBpRCJB7jXyg0MUibL0/BCu36Xp6XoUK4Cs0yX2/qLUi6PNVktyGtf5Oz8fGjyPfjW2ROIZmjPSAV6zyrUC0BUg9Yi5nBl1dk1xXokAlC5H8vZBjZMN8qH06oDdTNC8CLuCE2hCTi7YITzmSHy85FnU/hE17MR0VU3A0x9jwFdV9MB0XlyxKhx9kUjygyt9HTxg22vNtrd9WHilfa3bUhwG0GVNTrGgvmhL9TOhwLeYrmoxK0ExqPIqo+Qm/YWfqjPVSc/aOTz7SkQGO6qmKLPd4af730ApfnpgoZ/OD80nYCB36/dOrEN26JiERG+xib43F0/PF6rrpWTTX+te/ij8M0EzZuoCX29MplPn3YoYjCPXq6ruJSlTxyKZ65ZfFpptCRHq9z5BLVf4KK7mtGItgEmSzhrK9bkK/9PPAL+s623savFakDmCdbI6cUVEeWc2SuntuEE/3QuDZ6LLtKOCxHP8pMgtUJF75uaxuue3h3uu1X4PTmCt4RrVPg1vFGtlJzBi16om5+t9RjXg+7hZ8J8TVcmblJjNwuC65Cbkodfv40bzfFLvdmrHxUw8CG105AYAW1K6J3uMyZt7eTgDYiDRpR0nGIIwNPZsZk6PdBFpC6+T+IArnK9ijdY2woCpFwAWBZBOHBtfdywOXABXoEQ4UsKGXK4uWmJDhTeowZBCYIEOGilKRn8FINr/+aACRvJkJEbF504fa+4edwh4HEGAY9VzFYUnY5YrN1wQSTQXCZFPJV08Sozyma93xpwkt0ewFEcPqf4Lp0IoJkrECUz6dTL7uYU7LICO0noxgPB2OrmE3qkvAgentnv5IBYOCu4SxTfeubtdbMhoZGqanEhmgKR+fyDPwPQS0LcUUV3Ob5GbM4OKwSiYQsspXqtvAGlUvyiNfybabZM9MZYK1nD1K4+gcsnKxyHGQh/lnPyCjMKXs/Yj9ha7pKIUap+EldfGNAYNIvRBXmV9uXkvs8UDK4yf9IsrLMV8ePWonH0D8g6dlFrp5IdRPYML2j88sCoPuZY67ynzV2m2pPkOtmZdrcIZkMrxMyqJSmuVraaQeipRU/GUIl6kAgIaEHb7FY+SryDF8pQyHAEM+ave1cN0j1JCzoG5itsW8OFzNtxM1QYG2uNtO7Aod0xT2DRQGmQ/Asr47X/RyTkZHL2sFCAC4IQT9Voq29IMBRpispdAo0xWBpScm6oHi7oMnerz8uxcHRZ75NMz6WEMtZ/o7UuR3EvzqX7FS2PdkeMSK4W1mTyF2Zk5Yi2t4nN1cC2BAjDrsxJ0kAxA2sapnDiF000i58O6BmVfwjKgf68RvtmCCQ3HLZtaV1e5cBRWpdG47Z3z7U0zQduji1YFqjnZgFeiC0mBklJ4WbuMMTXrQhrj0i2okprBRRBfsE3Z8oXbm0i/kbi0joP3mH7srcN/tgDvLy8deIPAef5SGkNSWKl7v6qc7jPfFifIiBPDso3mvpHl35P/asnN3WY+Ll35fq7Vx6m4yzENGVJ3YsuF4LPaEEvbJ9LWeKaNHmdsqrvnOaIg4RMU8KAwe1M8e5sJKOvYeeDVBhaoFY2U/Je3mVDPzZf+UezjSQiH8bD/A3DUdkToiBFxp7G4wbhhVU+tsTg5aTq0DiP7P36neYJPA3nV/gWSUWyzJun15EiX1LU9IZP8TBYDHz88cb/LZFjnaktxnIZ4CGGeqc9YSnfJJYiueQ0kga5BAnScNbVYkepLAdWW7dMnRGOd9n8RvfJCZbeElSzQ78R2RZtvFn7Kg+xPIa+rbWxknScKX3G2b3ktAKuSRvtxBF6uvkjyjsqpnYWFSHIXfmID45nKddaikjM7zEgEc88tjfmJYcinONmEopl6M6b0m56SqqwG2D9Mga1Rh57PNDPgvtLhNmRdRT9DVH1CnqWOx7wBcm3irppebGnFek9gTWrBbV380pE6mAcTHkAbSGakqu5NiVDHWDyln66kVe5rI03xi2saVuVDCWkiMscdayMt8rdmQPuR3m1qvdWaniX8sIPYE7tfzqlfTl+gmRex7uzqMoQ1/fGtZ1evmfhVCIiiiAE95kYv9uu5TB92tPiUakpSECaDadeWoaXDJFf5AqVmfvjBQTT/cZuorTTWe3cT7kuFMq+w7ODlRJkxLH8b6cyQSDddMvxSQ7Cp0s2UPBsT1uQyzeYX3Izs+009s7IuNkE5tk70/LE3+NyKWdHep3NddZ9/TFlH5DmsQdFVW5XtO6exdVjGo/sr/kVgZlF+D6uqP+Xvhy4uneq1DoC5WqhUvBYYIbNZea7m73+/OZQCiweWsDLE2LSLuhDKAfx2iK0X63bghXJmaL1i6DO2uWOta4d5XWx8avCLtfENCz7ps1EyhaFOQnQCZPBrGFH1WodvdRVSstW+UFPCilV4sR0qPkj4wfXUjXaA0m7XG/u0eBTBvc//vMViUHBJCa+4oHZVMuoHXV+0cRF5aRJ/VGrf8T8rBT//SeSlcEW3Ng+PVD8qj6MT62+N0EcCmAehNkeVz7r0cIbeeXlKaDTYKy2wmA09D8Jz+8Q08b9QlywibDnKACV3HOU/PIFYkxqQc+OCthIRLL8dC2LwhmTDi96A8aZWgxUfCZlo68Sc5DEb2nQ48paP/RXIBE38wTnGjsl8QJOca3LBvKSVNMoCqIgoiO+AdrgaLi48KJyoyvYZM/MOII82/yZfTXLrqCpZr6hS18nx6GGt5UQ8npkKeW9gD4IjxHQzkFakxzDnKx34L/96Mr6mcmBONOoMCcAQiojbaUMcu8qQc9q/+3t+YmxMNY1lQ/wWmyiZDmQZOwVUMlfvDj/svRGbjWN0/Mh12nOacxll5n28BOrLQfSVAnm5RHt2BGNlKplucWD96TyeJBj23UJIMGrocXJ8UxrnS/VPLpGQNBPjv3WWhp6god5VW6Tkfi5BAIwsxpByTpjV1yzyrZ3+soMTFCxahONP55awzBECAJ8ppoPzIMGvNehgZKHY5VFKFUtPQ1i3eCNvrRoA5aLnvvw+oqD4W0ACy7Q4wKS2x55l+ThxfXWwJgwCkAhjXhwYHDXRjgptAdsVa4TedIeTwDXbaJefgg5wbnIXkWyM7BdYOoOe7FhDwTKIJrmNsMTzVuERxQqayHLaVWUjaOc5xpyScAYRmG/3758BTIzYPUNiEnA+xtVwIRSYFBWevjSy78s18nyFNweKNJZEE3OXvrgFr00MCEncGXA38NO+MRGfPK+kRuFwVpX7h4L7j/IqIArqwIUx2nK+x5RxK6b+c9DTZmBxAgAkTRFpuLFC1V1D4akxY4FVLVLXUBQRNmulQiv17xrz03kWTl+wFYHSSdZ1NiilAkDkvssrCpUTFOOcManvYYxN3YPl2H3JsOMMbl33aMt9PXi47cHn1p999Xl+UJATAWt6l+751+wLc/aPI8jvHw6ZZdQDcUAQJo7jjvYJihnurz3SzDNT7rQlXzC16a4xcUzZLcEbctHLlYLC4vAaGdp98i2jNv6+JZ3T51E6fU9OFuKo2k0C6v4vStF2Q7ltK8NJ5V5uFoBbXuk1KIrdKKJM7sPiYH/oozK71poQ3N65Ix5ufdj45rMu2RoiSL0kwORWBuHTb5EA5mreJo+MD+gDHI1ZNxkHNQAFrOpRBJCswCIqnbHajp1Cm+xivKHZ2L1VS3a7miuKpZeeN3VNYy+7Q5nOfvDjGzQKGBTKpBEEotUTBjL27x+LDr64f9frcG/ZXDnsjLVREy3Klj5AAu1hSdmZ4hP/wW+w+XxEEBQ4W2nQhungaCEXnKQpg/+YWIdb2396UBRZ/k7z4eOfu7tQGkyTvYZ07htbYMyXCR/8IpbbrWxIIQVkZcpqx4+fSNHO3YROIVG1zL8+sGNxYIpCfCmlNmyPgSNtgNhOGhORUwzdGyFnHA0s88vxxkfFP1KV6SrlEglHfDM3rQwkl+p+ODtyGccRghvwDpdDZIY7FtMhPRORMwkQXr++iAG8v98BX2mjKo4pBX4hl1OYU2MbbiaFNmBhW5aMDP2cW7h7hoc9wpxuKoGW/Y5zuI+iuXLldWT3EjLjU+XuZ7pdLD3VYEm+md7r53l9TI4ypCgLgQETCe1sTLUsCq4cxhwBecDVp/EkQCkRJRZwNNX1AeB+skBY689zTdY8bYmODJZlofWmgR6nuRCFdZ+2xDYcjtxZnMJD0bIwMbCuIeXayC0B4v92zrZb1LWiMpLYu8T6il6TIVoHAR1q+6mO3wqydVjh6TtJfqc4X1oIjnjGPocEQW2dWgtJkDbfUKvAM8RIeOMYL8FzOjJv24oZ6nlLLY5Evk+/j2gOWJGZwS/K86B+V4NW9+peWKMloBVzy83Egps1k/vcihbZClD/c+R1AyxiO3z0PPwhnE9mHE8MYD6PnSrPN9gJ2t7I99FVHx1nfk/lfGVCkGr26w9ggTJTvaOwGmrruKeB+dKcdsHuKrrf7qW8bYKPvt1+7CGJpV6P08H+FAXDZmFT0+JChUCHSJ1svOycuiPzNL3POo3iivdFOfBVrSOYd5Y8a1gpIIFj3GzmO+8q14aQy+v6EsR6tLcfodMpUhQDWnqE/dat22o2ZPMXgIMtOPSsHscQrDgHOuS7XChLwZ9gm0rFQLzWyUX3Vuh7EgJJFeD04Yfmurte4f1c5RktVPOBfGCek+/ycO1pSVPeNFq4vgjHkGlss1il8cpGARd8xzNdrYpr+AkIeoiw0yHPKp3UYEhC6e2xpFjlpsbcHTHETmrFr8peK1OZQJkqc5xReiCafBJNChc5js//nWRrrb3KwU8f2KxlLvIILOlT2wB8QgrvoSchMzFcxImAR8nvQlwBXIVxytdiLFqfC9mmKJabWwACmEU+7fAG0GlRKKXrvC0Emy4zvZP/meWbtJUDkfQodtVb5hM+2dgGJl5mvXvzBX0lssMwidYvxJe9hrXEkcx4nanOqkZFze1luMtsG19+s/rCwO1XTi3Bg2Q7/3LsPE0N1TFuVdCO9f7CHU8Obamrj8MGzhQj12D6D46iM1XxazDGKcMYBkJ4Ixm5TZPgH22llLQ0afcEi+NSGnBYiPt7dyTNeud0diWY2Q1Af4GKMHPdznQCcaoawdI83q0XlrxowWoa5eLHSEe4sPhfiMgyljY0MO9tYkyyTXe3mA43S41AdQxmmLCNdYxrIptNh6MNZnwGxwR+p7Uo9nATmYeOvG047vVu3xzml6snFeF4dX4PmXfqJfMRp8K+xNejxhVf8dcne4j1izPZIIV9RyvoTXw0bPymHjTeseGHePwWj1kmeMnKz33qrnw//3sp51iHaqLnCJrO1bEx+bUXKyQ6+jCuDg+aOV1Jg4vx7r5ETqlqst+1P2r2gTojnOjFyzWPCczTDrUlkYMKQkdwe3VmI7Gz3/f4f8AI/3vI6XXPjWF5tu4C8uuLc2g+1sOvU/4+oENvVzps2Jfl14kP/cYtFfAYnRLpge6dz6PYQqpdyjl6260eixkL8EOzrMndG6T+DdZaUwOutSrsXksOaaj8SzPVTzI5FacZ1xMUxTb1hnXv3w/LqM8Zf9CqdG27tweG9JzXeC9AF3DerE6tf8TLEnH0CZLjpkt7Fn1oL0qelZ1vaSvDWRuFvmYhj9MwFO0ITReAeWjgT+w1sLcTzpnEHUfBQ85zWfgqdJCeUdH3zKpaUjQB+n7eyLe4VU3v96Z4SVnbBPM2dpGZpLIxk3bdCI124ZRyOPPPsAw/9o/7Y0Lel8hyO9juFgnZdr2ujhtQyQ+tzX1UzzQyzQob4+9pFzA6OukyZJkQ1K7F4GA8m1wzVnTIVgksM5DEdQRjtR0Eu9G+gebA69cEA0qJ4r6IvYqG/BXlebmB8BKeY8aXQpuzQ964oXSPZjloYBNahc2zbojTOoxRMmNc92Y7kNyNCDdEMyEhB9ZDSlgNbN8pZpg5KiwpKF2GdsSJUiIj/4CV809E3m1TsUGMi/drrDp+FhD0uLw+qy8WpkWN8LuGagbRel/ExAt84xIN5zVZ17adjMaojksetbkY94d5DF+b2Azil8GgLq6A4ZCCAX3I1NXqW1yA0X3ax2jDDGlJRFLg0eH9JFRIo2cqOSv8vmx+a9ddEVwY0DWuGK7BLTRHS0LfuqnCUzZG0aYgvjktrwuhZ36pKJcnzw7Ei+ueq00nP04P8P4Q0x/SmcSunaYVrDwbJrD8TXp+ZQgmlNiP7tQvBQTZ/vqf+Fg1vbQm/cWZKeHYePg6vLclyOKiK2C25jvHp0Mz85YfYTCY2mHFUOPTKP/XfmLLf6z0dzgKkjaSK+mKt9t0krXlQmQpe9clo2vxF7VKHNJgw8dASISyhesNHltX386uByHlmVpigQrF1kwqH3FNkw5R6rahTMqDXJKoAcBAS5k4pdr1J/16jtO5LtqRnVo02SazYWsJcGq/QvC8Ngj5wwh+B6qkPqxoh16c1/Kq2ito3tGEvXWj316yDjGMYRsN5PJEy4U3bzIh9OyrmT+ZCy8noCv7F7kC0p5Y69fqudjb40me23IEqsqInD1iz6NTLi6zlkd5AL+Up3hZxCXvSQ+WZgnmZQkxF0IKjaSsOlRMvo+3vZHBdhGb4kInD5b6bGBqN87W6NXcg7pmCXePSUv5O2C2m8HVrfl1srZLmZ4xZdHgp87q4LkR1/ck1N3fI2f/wwBXkAce3YqFM4PgWvReBz7PeCTKG03YKBk6foIdkLyvpI/vZD8DtowxCgHjgkxHAMoMYI6Hc/sjTXJ1VwR6sRfn3mkBJrV52slbx6dJWhR8VmDdLHW3b+n4gQKTkbih46zJf4zcWQCD4YKFZusPAj1cYrr1AG4ndo1ifY9VwMmCBEkXaNirViBY+KyeJr5KlduS28o2FCuv84oyBTzEEi6JAJiq86viu64D+vrJDXNgrAF1AkTIhni+YpIjtBS5cpRRgdyky9VQ6KVXnb0fX2OIJ6OI6RVnPWgm2nffu9LVlwkQeljogPR+6uZh9tlDFWswkgOMogxtoXFKV4lVB2WbDU5wWLOp6zqD8ymWIfDFnDfyl+y3rmoNZPUiQ5UUCELK/+nMqiZnHYGz/8n/nvF4FdJd5n9fGfk/WVGZ1ZTTp0/9cX8eJP3IrMrgWRbpHuMH0w2oLYM6nGBputC8Mqb/4NfU+vd/UEEWN1tscoebzewkJOJ0NMgmhxT7jWgewyVDz3+8RKvbcthLRsQ/XoBBSOwNX4k72u6Numxs0/Fu+Xv7R2Ky2tV/SCuDWSg4oID/ZxOSxco/FsXshMBByBFXJxyB1j6o+zb0syuZ2/ok72qb5HGqh8ikfyWNUqmehrAOVUsD8ekH6ghu0xBWAxYZ7cLKrXv1Lquf7Oz95vTpNBZhXukQgYQsOZ3PclQXloG18ZPNWvdtAm1xL9pk5oWVLZ6n2SeXPdG9dPgm12qRdn/x2uAlzUIJl9pCB7Q2X2Ad2fJLaB60jgc3DZgomZAu52thDIjSk4AlD8PRn8hQ9pdWO4BRAIOf3HwF7E3vMeZT5p/UpkhWqtNPgEdTKAJOf/9sZ7Tbl64LzNRJCysBmtwjVAWrQoCY5PQHfuo/VIJ46V6qOQmKAFwSKqO33yQbv1dxj0prjZvoIyD+FXeMEOMm/fAFOTqBbpC6Oc7YLhnziWXwkL4tR7SESuVgcJaqinAKZ9DEl7XUC/Y1CTxPPAg2Cum7bSrkBFGn13MVTh5ER8Hshrc2FITu+ta7ExOO36Q2dB20BlO1+6FEM+/qjki91PQsEwMnf5BUoyvW7sNyIdFYM7q5wv6w8pU9ymuY8xWv0XuzcmX/5EiL00bhbLSGM1dNNtTTSGgBwIO/O57SKBdDXGZ8g/T+ySrA60JxVnTEPeAu+kQa4xZsYKlWjpDEYpWoGKlrOqbJpp7OIcKxI6Vdgke9iZeIoZ3n51qOOHSG5FL7DvgmgC3UmmgEL/C5yfMjIVqVMW4tGRiDG21X/HH3x4FdBgnZVFyrTkvQ1W8fALKbfPuQcfQfSxo/lYTWz4mymW3L11S5CZi5+g8BSu2crAJdWU4mpOcoysHTjnBjjE9XGN1fzCFnrh1csSjugvfY4GnR2gzY2iWiV2odNsZIxDY9kLC0uLneCYLTKnFIDZYGHjFchs0iOE0/XTg7AcGPc3mOPxpwo902aPxyftCNXKEht1gAAmotW8k6csNU3Mg7hRMpcpY2ls1t7kSloaTbgTGSdzEmJaOGGPzr9nTmHa2EDxAy6gTMLRtdAnbLhBOVgZ+5m+AIZcoH5zxZZCx3cUIuwCBz4yoGW8+xlHhunHQ3yHMR/wLTWo+l3GxdEWJ4m/YHRU80M533II0Qud+kvUKK10o69J2yvMt1TOx0+XvK/yQFfpR8Nqx0S57GAwZNZJy53CdUNfA5mGe5L5snX6OGUsORc1Kx+etOtW5Aw+PFP2DYcKfJA7gNHqT7fREM37T6voNQxsjICq0aqMV2bvKcOVC1PkegdDQKUSCxL0UNBYXfjkgwgznzvWENkMN3lYn7gGcljKVqKrLpHzhWVQKjYsoQZhI4LXdG/mkkI7ItKTyjGWJaTjZ6ih6MG7gQXp4ouFU87OS3Gjy8JhvEs0a/uYUWZLuHop0hPNpghr9kMjfPG3faK1rGJpgcow/LvxOPRfZFQDBirtlRZzPcSdjRO3m+gOmXsoIa6tEbLpYmijtkUEj5sihUpRq+/k/kZL1lch3Rh9AhxdpvljDeJXhgWkirsO4EFHIm1JDn5WJ81BoDIZaIWjAhM+LnJxIA6+Q2VGQ4WwRW2XWFnSTH1SizO/tRGKUkI8j69UeCGM43S4fYpwtx8pqsY+NV0CIQwpIpALKaAexTRpdtf+k33/oFx9hXcYvXYHO5mH0FF6fOXYZNQ8+FtTPcCmAT0453ii67HLFZeA5DblPSkapAz4w1MNEjSjjKwtp09F+l52AltS8SvAcMZ/eA9C4JuN+Ok9fRWnTxxZpIl74vyFThMvrcDdmbSAWo7hGzNa13BRW6AyWONlC6CnKhY+PC20fIx6/8SUMCDXMkyYsAikiwNIZ/ayE4ZUOnTjGIvplnzMVNtiHOBRSbF6AfBZJVLXTk2Q5rQ68Ag89JoNflJ6sjfE+EmIoib85ZxDE8pM2utAXiUCkZShVlmycpLXVb4/0Y+VQPTtDUXazD4dymS7nszWrFFAKe4LOu8Nywbm6Bq3zoG50rwfd3YNucDTPJY7pbAVLRJKN+7mo7nMVwmEuCeW58BqGwOTllKBHaJc/nyw2h/K87M0D9FiU830SCpucXfxzQcXnusl+HMdzDpuf0r4y+XmuhtVBmO8BqaNZfXJmnaKvFYuSMiBI3WCbTWjrTUyzs2NB+do9enzP6zzUgmO14Rny8dhlNPdpJL0ouGPkFbfxnBJ5jYvbL1ci8/J53VKvgAfzA6HT5z098MkxzpQnW1aNw8FIaEXdGpT03hFHg/SzCBp1nTFY4GXCCGGwz/K31HXKmfJbcz9dlUr+puV0xRTKIpUS5HlNJad/WaiKXb7Z6JkBuxm1DNPokNoCj0SJO2ohXUILyBWZ7OFYWAdVLzbxy6h9T9DoaUj32h2VhDEHpkn1CARUITxVgDnNOI93bmvJeaCraKuOobLr2EqdbBPzhAMVeTy9eyuLmIoqKUqZkcga6BcfqTdmBoglaRr0rSqjqL1aIq6BK+6b8FRIqSU2iJeSBBft338KSpIK5Cc58i9hB2Lz3jCq0agBcp8uyFmQXAuvvV+fLt6LMwvnELsK+ANaN/WWlvMiI8kssW9vJ+7cRvemtDmgJ3EhPLbNNqONQfewqq1Pj7I2jOJ3E5Q/lG7O1CqsOAfu7lbv2Mz7Dku6azZkgf1kSIzHL2a8EY8PjrLlQXbu+h9uzqq5jxEuPzLmDMOFvBBCxPGbbDguzG7Fyl/X6CjZNsT6BogKN+qU2mTyMfa3glnEdlzbQ/FLql4JULOfvI4Ob5cUkCyg1pqzZm/9oBzW5YdwK8rlDb53g33hx1T15/Gx8FXvu8wjFzjC+Wi7hZAlBK9RK9LHJ5fpnCg9DC1vsJSFPLUoydEu4pMbpOmAsq5W04FYyBjnGK/QayAR2idQiy5wgOd/Hzx0Tr3v4JBt3o3qLSMGFSJYfv+WWSV8tzPviUV4aZMsmU+UztNXLPyqAeOSTyHlIj+Aj8rHv6EW5HzyrZcMgQQB8fnBV4xIHVQ5mmZMlUQaQol8U9da7r2xpI+MzRFli8Z5wb/VBVPkt6wr/q+iRVC2JJeLVG5EipoYUj5E03VOTNvtpXbOMxPGrW6uZeGkJdqdCZWU3xysVDWrX6Pk3Vnwfpuv7yBqjGMx7akWkV2XvqzyCpokM5bSorKa0pt7wPUyQAlrMu7bELzaevRteMvEgnn8FvFX8T6o37erUI9RP/qSlKnzNjG3o30PHKT7TOSgZaWWfXKKC6C1h8vGeslT6/JratVRkj8KYkcs/+TY8fqOxG3PhIlKlXhsh8BhY+ZtV1Xmwf7EgLp0d1Fg01L5/vrvETpJJtHiY5MAOwuirk3E0TMMPJ3iliMTkFBUH13fxZaHAN1G7TfD3I4sEYxA5gl2pHXrhL7RkbkiZO7aQiEbZIdo+J65ePwBp+k91RcJuzQUI3cZ6QtDG3kaR8OXwWyFK/04I54Uv6vdtWtchcm2L+NhEWrZ2djk33VbLx5a1Rf4/jvNnPyC+u0Rysx8rq7BM6j1izYUCSeMt5yaKI+jCe31O5JRCayczsDWigk4I0ypNzi1zDMOa2sZo08kQ5I11ktJF4N/I1r0lLJdtQ0LmtPWvEJ6YjUx7nfL4n3RcFUi8b5Ve2+Xr6gQCuryZJo/R+Dwat3nh6F/eR5mO3c2Q9JfnhVBGps5v95e4e9/Fqet6r8nVXssmf658CInXwmMfdF9ZKdagUIW3M16osiWZdPeIbUbBv0hRnQXYIayWHcAuJFRRJ6+hSdnJcL5Z9gIUjBWPPYgCn4GK2tGjidTJZWjbs/0XT+m3pfZXNPZcwEFkxOOqlLkUuaWIlBlvXyoscBZpHYOJxXA+bdmHjVUhw4ecDdBzSkobpBFsAzD9w//Udq0rY7FuCIrFto6d2AuE14Kcx5+1TCryDwiu843nrac5tt0vIU+OHK792EYQU5CsM3ZCOUG3FsAbh5bL0glfjuh65OV4J+hw9RjbvaiBaO07dpXgAFKha5vZ5Hu56dthbCzXFl7nYbYhg0muhyVU/nbVIjqowhIAxo42L5/6zsj+VbRx/5alnaujduOIeUWQiaS2lhHMdB1NR2+nm378+6N05svtoihRJ//ztvtJMX5Xj3skuQD/9i4L9uMupgJXr3WVp36eckBwbVlaj4hWW3NSqhDFa//KYnfF6SQQg0+x2UXDF/MO3/VOkemE32JZjdrGIuvL0FD5pt9l3VjANRJLXdmKjGgfQiTsA6e8UQ1ap/oC2FdJNdebxc+a2kBwK/7wC4KZAG+WzyGx6z2hXM72UmeKkDS/PfLcIfyPkZjfBrxYFdPm/wPtbb34ur1BxTf+gB7YF0eqzyn9eStgmVl9RGWy6aq5tEQGKAC9ZY/3Q98DImGhDKbu1vQAAAAADUsMlHvJ8helhEMExrIsmKUJ7MrGG5+HzT66mx7KagVlVsJlEo+z2SqaT/qRpHkSwcyIV4Yu4QOS1tpddeR27tU+d7/+sFPJHtkJAPohS+XwC/L/EorGUwGXfxFX7hwcjy+sGQ65+WPljHqrhoQjoGePE5NGSTfcufadr7x2JtJhIU7aQ+L3EPAaWjf/73DUP+h0Pkq7IgX2O0HwxZkn2Wc2o/mlPTdkIopGTjCA/Ag3W2VrKfRT03eUBJ+tKJFvYiGdWkpCbpvlIBg6zVE/WxK625wmkCRV0Ty/8KF8r1/XBpQLuXf+JcO9l/HOTe0uxk2fxLq/pvkHtchQ5V8u9FD4Hp817Td4lpRvLkAMN6+v7lG636D++uy2fp1PQlBcfQs96oO5gnUj/j6+zX/JfnTmz3KqSZuaU6aR3RTP2/NcT6whhcg9U3WroW1J20nZ8OSuburLPd8Vu34PergdyflC8+z7E0nlhtYbXWC6Zum9f74fMi9E4xUiCZdvizxO7k7pwPiPBZ5fgLpUXwW9IUkrCFdmj4dZm0/BgGKHv8Gm+NlkAcE1iKbfHJ5ScRIK1Efjj1DxoTeUZU2nhscw5rXK26eAWGOLvMgZvBap03+uEiznRNRbE/crca8g5WpROVmHZBWcLcLhf2o2CMNSV1N5K9az2rfwkZpTY9tfn0DZioswCh3aiQtWNQfCP3faxPmhlSV/ivUtjk6lagao29X/EJW1kRipHfhTX16XySaf1rVobRKKo46Wn9N2BfGOu5TBvMB+xVzv7xGApNKK/ZKqra9uIwT0T1Bx5gx69TsI45vUl0sLEN8iR7SVn6ucbLWmyniA8GloU0wrS+JN3uLf3joag2uNnhUg19yONHTqi8NGtG77SLOKfvG43vv1fAGdGM4oxdoIQKXS+hoNPj/ZN92wtx0aDHQdvnur0oXn11soTTCftcf5cXpEOuI2rIRRu/JQDvros4Mbx2KSce/ZrqBUyp5g/SjqPLJfU5uiq7ZijG4DKizz3DssjPMJWNdMAELKUyVKVvW6W8GEarUuOolQOUkOdYvKRWgdVSNHAo6LUZskP3C1Hld712HOu+NfFfuuzm3uef2SXT0K5JFrVe7ZdjVpXU6bRZ7Q01hJi88OFdQkbyVIop4lczmL53VCGt8bBdD+I48Ascygrl9QrSQIM8yuQoJeBv2WKd+uDTVA+75vRxNPeyGCPfRZMcBQNd2XMX18X5QwJK1WI4NhROHaSjbvBSd/QYMnjh4pnAFnuQbbqL6Q5hcGb9ytPViTQU8KRg4XCBJ9dVfOBlygEfrRWFvMSi0Yhncp3SfNjwTKO3AerWVPC9glCLXdKy8h/iZCOXk98qvstu54vBuqSR4O5uWFAFB/6jHXNuqz/YfStcZTHw9YRvNU0JWe4wd9Ao8fKMhuA3IJgshV6sb07fHR1AzhSK5z8r+pAUCAcHe1bostiXf46s2uVvsN/cHFBi1hTc7h1Ug4tmpqgWtIV377VP01NZUktweLWxsoXoGDh+b1S0y3KJxe2dB4Q0viLkWpPvCJQTBwLU14Sx8coVzDWmghdeuAvdTbl6Oxmhmjt/fzVDdWYNmeRSRbDjPP9CjOwQdbrtGU4x0GX0AHTJnpJ+MlKpEwPDE829dgJh9maM7KRTRduzlfzDNZoEickPTuL8xpIqe0foprLv118dCLqc/yw4e2RGlyVpm6fK/OqVPa9moMJd3tMXGDnvXKc7T7x/zG3V43s+kdNX63/o+62CouDHDwj2BDUhLVXFRq3XmeJpD8zbCFmPZevZDN6TdTYTMJXWiM72Kf6W5ONvP0ZxHB48cW4QJa0YT3A4+rdG0XrvaPHbd+uOBhhqUE2Sb1fByI/MERulEjEGtf+rWf6t4BpY986edo/BeMOnjztY3IGc+7jGHzYI3c2jx3fkvlNWycCCbGHG5GD6NwdrUDVfkt58vwc3FGKGEWIv7l3+I9YY6Ph6BQfGzhTBnN8T0pJpkj9gIj+/nLfB7vNE04XboMCkmjaCT1QrQjYJXhzrokHTG7o4wTccrQoUGhFiE05LIa+KbRsNGVTFNIod0jIqx5kurlaOYN4br9XXGx9lSU4dOypYXhrBG54aWW+ESNnhhDLM91u/+63InfT/gD+SVutVL8bue1JR0UajWZQZ5auuXbMAuhe67qXVIP9QaBtGm8aTVb9To28K3Uc1orRY7Svq0k8v4Z4wr9xVIrHtqK3Ux8vXosg6zchmwBR3MG8nT0SCFN7Cj6yy9MAefOVldDNq+uXlUIEdVYnHAOJ9LaeDv4wi9qeDi+05yq1AP3o/ZI9z/2OylMQmhp53cTkncRshtVXnbLuEkzlNHDZ8z6or/4ebdGVdVEp9a+fcevebT4l0FaGSSL1/U0CeQUomfpn8yz/9mPM40V/2EYIKObdcufxArDpzjIydZHi5wqXhgH4NGMZmAr8UkiEmcfcS2XnNrp7/F2A/Zi80CFX6qZ5jCDLxAURGhqkGDb5hbm0DYsIGzezZBt/H6+PyfJXiu0tUjVuhjfM+8hVLvftxZ+R5AxI0jN9duqaZbhX5zecoolfHQc4+MYP/kSO1wQeRs2g1ja3bLIB+WpLw4kQVhhuS0Muv/iGuX0gEA4dLK6twEW6fbVMKzhnG6oouOgNdr9TVx75vYGq8BAA++YTfkYzWtUMk57PMKvYIZZpJnpxDZnQrpy2INAF023LB275DhzaCWJrc7+PXkSsWur4PDYOtDz0jG17UY06zr04o53OWbBWF4xu2AeHbLB0ftoOAq6geN5lzD/ySVXGDwI2WYHhAQ48GXGOVQZ1aYKw/+qL46eEDfFBwa1Ni7oRv1svkNug28oty8O1BL6oCSjaag8jKMb21lAsOTj1YI9X8tgbbd6PqDGbHomdbcztTINERTMF+QE3OB2rX4xiOshhJCIDms28C4qm94sZoJOUkU4ffDNRuT+5wedyJXRGeaYJ0xTV2A1QbCz4DNf1zfkohDOPgVmSTLi2rXn3MBhcp6yN0D/BnlU737pt1LBfgW7mUSX7R1KEao/gu1v1kS5IA0S3ECC8vzsxqjHPukpyCkpk/xYqJaFI2jeCjE5n/w82/1lQrdDH808daQ02jH4QjwzeLW3whz1rM9p5ZJF2YUPmLphqAZCuYWybk6KEiuVwQ7UCcb57/cYeSLssMhcWTp9/i72JB3CWj3GXEsko77K7gNjqlBu4G4Pmr8AhxhmqRN3+kce+xW8Rr2usmqywYgy97IlSyYMxM/IOnJvZJDMX12SuaBacPSueIIJyA5fgia+FoqXGYjcFWDJnV9bcwRAyOG/ep3O2himaLDJheAnZDH1hBVnr4tfiY+1ASOy05kFRAYkl3QIfzge7BGb6CLUktZSlqNoJjL3dWNmUu1hIazkx1UFIYFQ0kNTx+spq3SrqPUoejDr87QFsoqX1CYj/2xna/jMNbPzmxyE8/DzKfezbW8OYg6Jh/Sh7lUGlyf9DI0N1XsgKcQP1frGbn11R+fLnF0TUaDSdukZMzH54FtVOkSlPjmR/OXixJVkRKDwj80J/hARXvnwXdLUwjCvJQ1rUjw7zBNbNi4hRBDVAKwP/9zHJIJNQ241QAMTAzDWz85schPPw8yn3s21vDcmAh9tz4F4+p5td3TyG+1PHAjAMKmQfi5Zoii1qhQz4bj810xCkeYb9cPMPjdmkj3KeTlrbut+evxUfmbdxjjFxFHYkCqik94ipfGEL7e7lnf+SseYhipRqgQ9gkCHeXQl7WXC082/iJ91g1KdMxeS/8A190ThxBk3xXf4Q5kb7x38kvYDeLyTAsvGk7CRRNLTZyWjCTMUP8PIt3cLBOp/lruKyUWneshKDnSANKRLwoEZzCboSnup3xYsMLfomxRMyxJpvCf1KokqPSf5gthRiYiIw6AqQ2YL1ZM5JlL1zFllg/P5Xt7ZY/zyD9/quSDUGfaswxWVyhPTLx0v0eBgJ0WYFbOap9sR8Us90TxwsTNR2SfHplauh2RzQbKDGDJ6/MQ2VdHNCoXVE5+kIGGMvJMZxttV/mb7H+e/vQh66jHb+HBCbp7m+i6vWu+DpqKhJY4G6h5fj+NBK5LThecAYhrp/rAW3Y6u8awTkh7b1ogMC5AFIzgsULuMmPdHEIXTdrva761aDWry55ELhilrFrqLmgQGck2q/jX8mhoQdftuErdkOAW3fcP0ZcyTKMLgrW++nrI+FOmpSBfWH0gHgnCP3R1PRlI+SGha0D2Y5F0sPV+gfeHg/oy7GmfDlOSg760hu8tXs2RnO1AZJmC/Au1UM/FG7CQjx2qKWVhV2zrXMMOdJOp2Vv+Td75+qGcarFjYc5I9dDQji52wS/3+hTds2ShMATLDGjv3UFOwXmFCKwyklrh3qFNEfhAAAAAAAAAAAAAAAAAAAARVhJRroAAABFeGlmAABJSSoACAAAAAYAEgEDAAEAAAABAAAAGgEFAAEAAABWAAAAGwEFAAEAAABeAAAAKAEDAAEAAAACAAAAEwIDAAEAAAABAAAAaYcEAAEAAABmAAAAAAAAAPJ2AQDoAwAA8nYBAOgDAAAGAACQBwAEAAAAMDIxMAGRBwAEAAAAAQIDAACgBwAEAAAAMDEwMAGgAwABAAAA//8AAAKgBAABAAAAXgMAAAOgBAABAAAA8gEAAAAAAAA=';
const DEFAULT_BATCH_SIZE = Number(process.env.BATCH_SIZE || 10);
const BASIC_USER = process.env.BASIC_USER || '';
const BASIC_PASS = process.env.BASIC_PASS || '';
const USERS_JSON = process.env.USERS_JSON || '';
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';

const APP_VERSION = 'tareas-seguimiento-v1-2026-06-11';
const C = {
  contactSources: 'hunter_contact_sources',
  customsGroups: 'hunter_customs_groups',
  customsItems: 'hunter_customs_items',
  prospects: 'hunter_prospects',
  notes: 'hunter_notes',
  tasks: 'hunter_tasks',
  users: 'hunter_users',
  jobs: 'hunter_upload_jobs',
  jobRows: 'hunter_upload_job_rows',
  matchIndex: 'hunter_match_index'
};

function nowISO() { return new Date().toISOString(); }
function safeId(s) {
  const n = normalizeName(s || 'SIN_NOMBRE');
  if (!n) return 'sin_nombre_' + crypto.randomBytes(4).toString('hex');
  return n.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 140) || 'sin_nombre_' + crypto.randomBytes(4).toString('hex');
}
function hashId(s) { return crypto.createHash('sha1').update(String(s || '')).digest('hex').slice(0, 18); }
function passwordHash(s) { return crypto.createHash('sha256').update(String(s || '')).digest('hex'); }
function verifyPassword(raw, hash) { return Boolean(hash) && passwordHash(raw) === hash; }
function canonicalText(v) {
  return upperNoAccents(v)
    .replace(/^[\s'"´`]+/, '')
    .replace(/\s+/g, ' ')
    .trim();
}
function canonicalNumber(v) {
  const n = parseCurrency(v);
  return Number.isFinite(n) ? String(Math.round(n * 1000000) / 1000000) : '0';
}
function customsItemKey(item, normImportador) {
  // Duplicado aduanero estricto: si cambia cualquier campo clave, es otro ítem.
  const parts = [
    normImportador || normalizeName(item.importador),
    canonicalText(item.fecha),
    canonicalText(item.aduana),
    canonicalText(item.destinacion),
    canonicalText(item.posicion),
    canonicalText(item.item),
    canonicalText(item.descripcion),
    canonicalNumber(item.fob),
    canonicalNumber(item.cantidad),
    canonicalText(item.origen),
    canonicalText(item.procedencia),
    canonicalText(item.divisa)
  ];
  return parts.join('|');
}
function parseCurrency(v) {
  if (v === null || v === undefined || v === '') return 0;
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  let s = String(v).trim().replace(/\s/g, '');
  if (!s) return 0;
  const comma = s.lastIndexOf(',');
  const dot = s.lastIndexOf('.');
  if (comma > dot) s = s.replace(/\./g, '').replace(',', '.');
  else s = s.replace(/,/g, '');
  s = s.replace(/[^0-9.-]/g, '');
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}
function parseNumber(v) {
  if (v === null || v === undefined || v === '') return 0;
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  let s = String(v).trim().replace(/\s/g, '').replace(/\./g, '').replace(',', '.').replace(/[^0-9.-]/g, '');
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}
function upperNoAccents(s) {
  return String(s || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toUpperCase();
}
function normFilterValue(v) {
  return upperNoAccents(v).replace(/\s+/g, ' ').trim();
}

const ARG_PROVINCES = [
  'Buenos Aires','CABA','Catamarca','Chaco','Chubut','Córdoba','Corrientes','Entre Ríos','Formosa','Jujuy','La Pampa','La Rioja','Mendoza','Misiones','Neuquén','Río Negro','Salta','San Juan','San Luis','Santa Cruz','Santa Fe','Santiago del Estero','Tierra del Fuego','Tucumán'
];
const ARG_PROVINCE_BY_NORM = (() => {
  const m = new Map();
  for (const p of ARG_PROVINCES) m.set(normFilterValue(p), p);
  const aliases = {
    'CIUDAD AUTONOMA DE BUENOS AIRES': 'CABA',
    'CDAD AUTONOMA DE BUENOS AIRES': 'CABA',
    'CIUDAD DE BUENOS AIRES': 'CABA',
    'CAPITAL FEDERAL': 'CABA',
    'C A B A': 'CABA',
    'PROVINCIA DE BUENOS AIRES': 'Buenos Aires',
    'PROV BUENOS AIRES': 'Buenos Aires',
    'PROVINCIA BUENOS AIRES': 'Buenos Aires',
    'CORDOBA': 'Córdoba',
    'ENTRE RIOS': 'Entre Ríos',
    'NEUQUEN': 'Neuquén',
    'RIO NEGRO': 'Río Negro',
    'TUCUMAN': 'Tucumán',
    'TIERRA DEL FUEGO ANTARTIDA E ISLAS DEL ATLANTICO SUR': 'Tierra del Fuego',
    'TIERRA DEL FUEGO': 'Tierra del Fuego'
  };
  for (const [k,v] of Object.entries(aliases)) m.set(normFilterValue(k), v);
  return m;
})();
function canonicalArgProvince(v) {
  let u = normFilterValue(v);
  if (!u) return '';
  u = u.replace(/^PROVINCIA DE /, '').replace(/^PROVINCIA /, '').replace(/^PROV DE /, '').replace(/^PROV /, '').trim();
  return ARG_PROVINCE_BY_NORM.get(u) || '';
}
function provinceFilterKey(v) {
  return normFilterValue(canonicalArgProvince(v) || v);
}
function zoneListNormProvince(list) {
  return Array.from(new Set((list || []).map(x => canonicalArgProvince(x)).filter(Boolean).map(normFilterValue)));
}

function titleCaseEs(v) {
  const small = new Set(['DE','DEL','LA','LAS','LOS','Y','E']);
  return String(v || '').toLowerCase().split(/\s+/).filter(Boolean).map((w,i)=>{
    const up = upperNoAccents(w);
    if (i > 0 && small.has(up)) return w;
    return w.charAt(0).toUpperCase() + w.slice(1);
  }).join(' ');
}
function normalizeLocationText(v) {
  return cleanText(v)
    .replace(/["'`´]/g, '')
    .replace(/\s*,\s*Argentina\s*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}
function canonicalProvince(v) {
  let raw = normalizeLocationText(v);
  let u = upperNoAccents(raw)
    .replace(/\./g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!u) return '';
  if (
    u === 'CABA' || u === 'C A B A' ||
    u === 'CAPITAL FEDERAL' ||
    u.includes('CIUDAD AUTONOMA DE BUENOS AIRES') ||
    u.includes('CDAD AUTONOMA DE BUENOS AIRES') ||
    u.includes('CIUDAD DE BUENOS AIRES')
  ) return 'CABA';
  u = u.replace(/^PROVINCIA DE\s+/, '').replace(/^PROV\s+DE\s+/, '').replace(/^PROV\s+/, '').trim();
  const map = {
    'BUENOS AIRES': 'Buenos Aires',
    'CATAMARCA': 'Catamarca',
    'CHACO': 'Chaco',
    'CHUBUT': 'Chubut',
    'CORDOBA': 'Córdoba',
    'CORRIENTES': 'Corrientes',
    'ENTRE RIOS': 'Entre Ríos',
    'FORMOSA': 'Formosa',
    'JUJUY': 'Jujuy',
    'LA PAMPA': 'La Pampa',
    'LA RIOJA': 'La Rioja',
    'MENDOZA': 'Mendoza',
    'MISIONES': 'Misiones',
    'NEUQUEN': 'Neuquén',
    'RIO NEGRO': 'Río Negro',
    'SALTA': 'Salta',
    'SAN JUAN': 'San Juan',
    'SAN LUIS': 'San Luis',
    'SANTA CRUZ': 'Santa Cruz',
    'SANTA FE': 'Santa Fe',
    'SANTIAGO DEL ESTERO': 'Santiago del Estero',
    'TIERRA DEL FUEGO': 'Tierra del Fuego',
    'TUCUMAN': 'Tucumán'
  };
  if (map[u]) return map[u];
  if (u.includes('TIERRA DEL FUEGO')) return 'Tierra del Fuego';
  return titleCaseEs(u);
}
function canonicalCity(v) {
  let raw = normalizeLocationText(v);
  let u = upperNoAccents(raw)
    .replace(/\./g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!u) return '';
  if (u === 'CABA' || u === 'C A B A' || u === 'CAPITAL FEDERAL' || u.includes('CIUDAD AUTONOMA DE BUENOS AIRES') || u.includes('CDAD AUTONOMA DE BUENOS AIRES')) return 'CABA';
  u = u.replace(/^PARTIDO DE\s+/, '').replace(/^DEPARTAMENTO\s+/, '').trim();
  return titleCaseEs(u);
}
function summarySearchText(summary) {
  return upperNoAccents([
    (summary?.chapters || []).join(' '),
    (summary?.origins || []).join(' '),
    (summary?.procedencias || []).join(' '),
    (summary?.aduanas || []).join(' '),
    (summary?.positions || []).join(' '),
    (summary?.descriptionsPreview || []).join(' ')
  ].filter(Boolean).join(' '));
}
function prospectIndexFields(contact = {}, summary = {}) {
  return {
    contactProvinceNorm: provinceFilterKey(contact.province || ''),
    contactCityNorm: normFilterValue(contact.city || ''),
    customsOriginsNorm: (summary.origins || []).map(normFilterValue).filter(Boolean),
    customsChapters: (summary.chapters || []).map(x => String(x || '').trim()).filter(Boolean),
    customsDescriptionsNorm: summarySearchText(summary),
    lowReadsIndexedAt: nowISO()
  };
}
function normalizeName(s) {
  let x = upperNoAccents(s)
    .replace(/^\s*TOTAL\s+/, ' ')
    .replace(/&/g, ' Y ')
    .replace(/[.,;:()\[\]{}'"`´]/g, ' ')
    .replace(/[\-_/\\]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Sacar solo sufijos legales, no letras sueltas del nombre.
  // Antes se eliminaban tokens como A / E / ARGENTINA en cualquier parte,
  // y eso podía convertir "A E B ARGENTINA S.A." en solo "B".
  // Ahora se respeta el nombre comercial y se limpian solo sufijos societarios.
  let changed = true;
  while (changed) {
    const before = x;
    x = x
      .replace(/\bSOCIEDAD\s+ANONIMA\b$/g, '')
      .replace(/\bSOCIEDAD\s+DE\s+RESPONSABILIDAD\s+LIMITADA\b$/g, '')
      .replace(/\bS\s*A\s*U\b$/g, '')
      .replace(/\bS\s*A\s*S\b$/g, '')
      .replace(/\bS\s*R\s*L\b$/g, '')
      .replace(/\bSAU\b$/g, '')
      .replace(/\bSAS\b$/g, '')
      .replace(/\bSRL\b$/g, '')
      .replace(/\bSA\b$/g, '')
      .replace(/\bLTDA\b$/g, '')
      .replace(/\bLLC\b$/g, '')
      .replace(/\bINC\b$/g, '')
      .replace(/\bCIA\b$/g, '')
      .replace(/\bCOMPANIA\b$/g, '')
      .replace(/\bCO\b$/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    changed = before !== x;
  }

  const raw = x.split(' ').filter(Boolean);
  const out = [];
  for (let i = 0; i < raw.length; i++) {
    const t = raw[i];
    const prev = raw[i - 1] || '';
    const next = raw[i + 1] || '';
    const betweenInitials = t.length === 1 && prev.length === 1 && next.length === 1;
    // Sacamos conectores comunes, pero NO si son letras de una sigla tipo A E B.
    if (['DE','DEL','LA','LAS','LOS','EL','THE','AND'].includes(t)) continue;
    if ((t === 'Y' || t === 'E') && !betweenInitials) continue;
    out.push(t);
  }
  return out.join(' ').trim();
}
function normalizeMatchKey(s) {
  // Llave única para match contacto/aduana: misma normalización y sin espacios.
  // Evita que A E B ARGENTINA y AEB ARGENTINA queden separados por espacios/puntos.
  return normalizeName(s).replace(/\s+/g, '');
}
function makeMatchKey(s) { return normalizeMatchKey(s); }

function entityMatchKey(x) {
  // Recalcular siempre desde el nombre original.
  // No priorizamos x.matchKey porque datos viejos pueden tener una llave mal generada
  // y eso impide que Reprocesar match corrija contactos/aduana ya cargados.
  return normalizeMatchKey(x?.companyName || x?.importador || x?.sourceContactName || x?.sourceCustomsName || x?.normalizedName || x?.matchKey || '');
}
function tokens(s) { return new Set(normalizeName(s).split(' ').filter(Boolean)); }
function diceScore(a, b) {
  a = normalizeName(a); b = normalizeName(b);
  if (!a || !b) return 0;
  if (a === b) return 100;
  const ta = tokens(a), tb = tokens(b);
  if (!ta.size || !tb.size) return 0;
  let inter = 0; for (const t of ta) if (tb.has(t)) inter++;
  const tokenScore = (2 * inter) / (ta.size + tb.size);
  const containsScore = (a.includes(b) || b.includes(a)) ? 0.94 : 0;
  return Math.round(Math.max(tokenScore, containsScore) * 100);
}
function getHeader(row, candidates) {
  for (const c of candidates) {
    if (Object.prototype.hasOwnProperty.call(row, c)) return row[c];
  }
  const keys = Object.keys(row || {});
  const normalizedMap = new Map(keys.map(k => [upperNoAccents(k).replace(/[^A-Z0-9]/g, ''), k]));
  for (const c of candidates) {
    const nk = upperNoAccents(c).replace(/[^A-Z0-9]/g, '');
    if (normalizedMap.has(nk)) return row[normalizedMap.get(nk)];
  }
  // Soporta encabezados truncados por exportaciones/pivots, ej: "SUM de Cantida".
  for (const c of candidates) {
    const nk = upperNoAccents(c).replace(/[^A-Z0-9]/g, '');
    for (const [rk, originalKey] of normalizedMap.entries()) {
      if (rk && nk && (rk.startsWith(nk) || nk.startsWith(rk))) return row[originalKey];
    }
  }
  return '';
}
function cleanText(v) { return String(v ?? '').trim(); }
function chapterFromPosition(pos) {
  const s = cleanText(pos).replace(/[^0-9]/g, '');
  return s.length >= 2 ? s.slice(0, 2) : '';
}
function unique(arr, max = 50) {
  const out = [];
  const seen = new Set();
  for (const v of arr || []) {
    const s = cleanText(v);
    if (!s || seen.has(s)) continue;
    seen.add(s); out.push(s);
    if (out.length >= max) break;
  }
  return out;
}
function topValues(values, max = 5) {
  const m = new Map();
  for (const v of values || []) {
    const s = cleanText(v);
    if (!s) continue;
    m.set(s, (m.get(s) || 0) + 1);
  }
  return [...m.entries()].sort((a,b) => b[1]-a[1]).slice(0,max).map(x => x[0]);
}
function requireBasic(req, res) {
  // Compatibilidad opcional: por defecto la app usa login propio (admin/vendedores).
  // Si querés volver al popup Basic del navegador, setear FORCE_BASIC_AUTH=true.
  if (process.env.FORCE_BASIC_AUTH !== 'true') return true;
  if (!BASIC_USER || !BASIC_PASS) return true;
  const h = req.headers.authorization || '';
  const [type, value] = h.split(' ');
  if (type !== 'Basic' || !value) {
    res.set('WWW-Authenticate', 'Basic realm="SCB Hunter Campo"');
    res.status(401).send('Auth required'); return false;
  }
  const [u, p] = Buffer.from(value, 'base64').toString().split(':');
  if (u === BASIC_USER && p === BASIC_PASS) return true;
  res.set('WWW-Authenticate', 'Basic realm="SCB Hunter Campo"');
  res.status(401).send('Invalid auth'); return false;
}
function currentUser(req) {
  const headerUser = cleanText(req.headers['x-scb-user']);
  const qUser = cleanText(req.query.user);
  const bodyUser = cleanText(req.body && req.body.user);
  const user = headerUser || qUser || bodyUser || 'admin';
  let role = user === 'admin' ? 'admin' : 'seller';
  try {
    if (USERS_JSON) {
      const users = JSON.parse(USERS_JSON);
      if (users[user] && users[user].role) role = users[user].role;
    }
  } catch (_) {}
  return { id: safeId(user), name: user, role };
}
function isAdmin(req) {
  const u = currentUser(req);
  if (u.role === 'admin') return true;
  if (ADMIN_TOKEN && req.headers['x-admin-token'] === ADMIN_TOKEN) return true;
  return false;
}
function sendJson(res, data, status = 200) {
  res.status(status).set('Content-Type', 'application/json; charset=utf-8').send(JSON.stringify(data));
}

function logEvent(level, event, data = {}) {
  const payload = {
    ts: nowISO(),
    service: APP_NAME,
    databaseId: FIRESTORE_DATABASE_ID,
    level,
    event,
    ...data
  };
  const line = JSON.stringify(payload);
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}
async function safeCollectionCount(colName) {
  try {
    const snap = await db.collection(colName).count().get();
    return snap.data().count || 0;
  } catch (e) {
    logEvent('warn', 'count_failed', { collection: colName, error: e.message });
    const snap = await db.collection(colName).limit(1).get();
    return `count_failed_has_${snap.size}`;
  }
}

async function safeQueryCount(q, label = 'query') {
  try {
    const snap = await q.count().get();
    return snap.data().count || 0;
  } catch (e) {
    logEvent('warn', 'query_count_failed', { label, error: e.message });
    return null;
  }
}
async function debugStatus(req, res) {
  const counts = {};
  for (const [key, col] of Object.entries(C)) counts[key] = await safeCollectionCount(col);
  sendJson(res, {
    ok: true,
    service: APP_NAME,
    target: 'helloHttp',
    databaseId: FIRESTORE_DATABASE_ID,
    batchSize: DEFAULT_BATCH_SIZE,
    node: process.version,
    authBasicEnabled: Boolean(BASIC_USER && BASIC_PASS),
    adminTokenEnabled: Boolean(ADMIN_TOKEN),
    collections: C,
    counts,
    time: nowISO()
  });
}
async function debugJobs(req, res) {
  const snap = await db.collection(C.jobs).orderBy('createdAt', 'desc').limit(Math.min(Number(req.query.limit || 20), 100)).get();
  sendJson(res, { ok: true, jobs: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
}
async function debugMatch(req, res) {
  const a = cleanText(req.query.a || req.query.contact || '');
  const b = cleanText(req.query.b || req.query.customs || '');
  sendJson(res, {
    ok: true,
    a,
    b,
    normalizedA: normalizeName(a),
    normalizedB: normalizeName(b),
    score: diceScore(a, b)
  });
}
async function debugSamples(req, res) {
  const type = cleanText(req.query.type || 'prospects');
  const map = { contacts: C.contactSources, customs: C.customsGroups, items: C.customsItems, prospects: C.prospects, notes: C.notes, tasks: C.tasks, jobs: C.jobs };
  const col = map[type] || C.prospects;
  const snap = await db.collection(col).limit(Math.min(Number(req.query.limit || 5), 25)).get();
  sendJson(res, { ok: true, type, collection: col, rows: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
}
function readXlsxRows(buffer) {
  const wb = XLSX.read(buffer, { type: 'buffer', cellDates: false, raw: false });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) return [];
  const ws = wb.Sheets[sheetName];
  const matrix = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: false });
  if (!matrix.length) return [];

  // Detecta automáticamente la fila de encabezados. Sirve para archivos exportados
  // con filas vacías arriba o formatos tipo pivot/agrupados.
  const keywords = new Set([
    'IMPORTADOR','EMPRESA','NOMBRE','RAZONSOCIAL','RAZONSOCIAL',
    'FECHA','ADUANA','POSICION','POSICIÓN','DESCRIPCION','DESCRIPCIÓN',
    'ITEM','PROCEDENCIA','ORIGEN','FOB','SUMDEFOB','SUMDECANTIDAD',
    'TELEFONO','TELÉFONO','DIRECCION','DIRECCIÓN','GOOGLEMAPS','WEB','CIUDAD','PROVINCIA'
  ]);
  const normKey = v => upperNoAccents(v).replace(/[^A-Z0-9]/g, '');
  let headerIdx = 0;
  let bestScore = -1;
  for (let i = 0; i < Math.min(matrix.length, 30); i++) {
    const row = matrix[i] || [];
    let score = 0;
    for (const cell of row) {
      const k = normKey(cell);
      if (keywords.has(k)) score += 2;
      else if (k.includes('IMPORTADOR') || k.includes('DESCRIPCION') || k.includes('FOB')) score += 1;
    }
    if (score > bestScore) { bestScore = score; headerIdx = i; }
  }

  const headers = (matrix[headerIdx] || []).map((h, i) => cleanText(h) || `COL_${i + 1}`);
  const rows = [];
  for (let r = headerIdx + 1; r < matrix.length; r++) {
    const arr = matrix[r] || [];
    const obj = {};
    let hasAny = false;
    for (let c = 0; c < headers.length; c++) {
      const value = arr[c] ?? '';
      if (cleanText(value)) hasAny = true;
      obj[headers[c]] = value;
    }
    if (hasAny) rows.push(obj);
  }
  return rows;
}
function mapContactRow(row) {
  const companyName = cleanText(getHeader(row, ['Empresa','Nombre','Razon Social','Razón Social','Importador','Cliente','Compañía','Company','Name']));
  const rawCity = cleanText(getHeader(row, ['Ciudad','Localidad','City']));
  const rawProvince = cleanText(getHeader(row, ['Provincia','Estado','Province','State']));
  return {
    companyName,
    normalizedName: normalizeName(companyName),
    matchKey: normalizeMatchKey(companyName),
    address: cleanText(getHeader(row, ['Direccion','Dirección','Domicilio','Address','Ubicación','Ubicacion'])),
    // IMPORTANTE: Ciudad y Provincia se guardan EXACTAMENTE desde las columnas del Excel.
    // H = Ciudad, I = Provincia. No inferir desde dirección ni convertir CABA/Buenos Aires.
    city: rawCity,
    province: rawProvince,
    rawCity,
    rawProvince,
    phone: cleanText(getHeader(row, ['Telefono','Teléfono','Phone','WhatsApp','Celular','Mobile'])),
    email: cleanText(getHeader(row, ['Email','E-mail','Correo','Mail'])),
    website: cleanText(getHeader(row, ['Web','Website','Sitio Web','URL'])),
    googleMapsUrl: cleanText(getHeader(row, ['Google Maps','Maps','Link Google Maps','GoogleMaps','Mapa'])),
    raw: row
  };
}
function isTotalLike(v) {
  let s = upperNoAccents(v).trim();
  s = s.replace(/^[\s'"´`]+/, '').trim();
  return Boolean(s) && (
    s === 'TOTAL' ||
    s.startsWith('TOTAL ') ||
    s.startsWith('TOTAL:') ||
    s.startsWith('TOTAL-') ||
    s.startsWith('SUBTOTAL ') ||
    s.startsWith('SUBTOTAL:') ||
    s.startsWith('SUBTOTAL-')
  );
}
function cleanImporterName(v) {
  let s = cleanText(v);
  s = s.replace(/^['"´`]+\s*/, '').trim();
  return s;
}
function mapCustomsRow(row, current = {}) {
  const rawImportador = cleanText(getHeader(row, ['Importador','Empresa','Nombre','Razon Social','Razón Social']));
  const importador = cleanImporterName(rawImportador || current.importador || '');
  const posicion = cleanText(getHeader(row, ['Posición','Posicion','NCM','PA','Partida','HS','HS Code']));
  const fobRaw = getHeader(row, ['FOB','Valor FOB','FOB USD','SUM de FOB','Suma de FOB','SUMA FOB','SUM FOB']);
  const cantidadRaw = getHeader(row, ['Cantidad','Qty','Quantity','SUM de Cantidad','Suma de Cantidad','SUM Cantidad','SUM de Cantida']);
  const fob = parseCurrency(fobRaw);
  const fecha = cleanText(getHeader(row, ['Fecha','Date'])) || current.fecha || '';
  const aduana = cleanText(getHeader(row, ['Aduana'])) || current.aduana || '';
  return {
    fecha,
    aduana,
    posicion,
    descripcion: cleanText(getHeader(row, ['Descripción','Descripcion','Mercadería','Mercaderia','Producto','Detalle'])),
    destinacion: cleanText(getHeader(row, ['Destinación','Destinacion'])),
    item: cleanText(getHeader(row, ['Item','Ítem'])),
    importador,
    transporte: cleanText(getHeader(row, ['Transporte','Via','Vía','Medio Transporte'])),
    cantidad: parseNumber(cantidadRaw),
    fob,
    origen: cleanText(getHeader(row, ['Origen','País Origen','Pais Origen'])),
    procedencia: cleanText(getHeader(row, ['Procedencia','País Procedencia','Pais Procedencia'])),
    divisa: cleanText(getHeader(row, ['Divisa','Moneda','Currency'])) || 'USD',
    chapter: chapterFromPosition(posicion),
    raw: row
  };
}
function isValidCustomsItem(item) {
  if (!item || !item.importador || !normalizeName(item.importador)) return false;
  if (isTotalLike(item.importador)) return false;
  if (
    isTotalLike(item.fecha) ||
    isTotalLike(item.aduana) ||
    isTotalLike(item.posicion) ||
    isTotalLike(item.descripcion) ||
    isTotalLike(item.destinacion) ||
    isTotalLike(item.item) ||
    isTotalLike(item.transporte) ||
    isTotalLike(item.origen) ||
    isTotalLike(item.procedencia) ||
    isTotalLike(item.divisa)
  ) return false;
  // En los pivots de Google Sheets puede no venir posición. Aceptamos la fila
  // si tiene descripción real y algún dato económico/logístico.
  if (!item.descripcion) return false;
  const hasSignal = Boolean(item.fob || item.cantidad || item.posicion || item.origen || item.procedencia || item.aduana);
  return hasSignal;
}
async function batchCommitWrites(writes) {
  const chunks = [];
  for (let i = 0; i < writes.length; i += 450) chunks.push(writes.slice(i, i + 450));
  for (const ch of chunks) {
    const batch = db.batch();
    for (const w of ch) {
      if (w.type === 'set') batch.set(w.ref, w.data, w.options || { merge: true });
      else if (w.type === 'delete') batch.delete(w.ref);
      else if (w.type === 'update') batch.update(w.ref, w.data);
    }
    await batch.commit();
  }
}
async function getAllDocs(colName, limit = 20000) {
  const snap = await db.collection(colName).limit(limit).get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
async function upsertProspectFromContact(contact, customsGroup, matchScore = 100, matchStatus = 'matched') {
  const id = safeId(contact.normalizedName || contact.companyName);
  const ref = db.collection(C.prospects).doc(id);
  const existingSnap = await ref.get().catch(() => null);
  const existing = existingSnap && existingSnap.exists ? existingSnap.data() : null;
  const existingCommercial = existing && existing.commercial ? existing.commercial : null;
  const summary = customsGroup ? (customsGroup.summary || {}) : {};
  const contactObj = {
    address: contact.address || '', city: contact.city || '', province: contact.province || '', phone: contact.phone || '',
    email: contact.email || '', website: contact.website || '', googleMapsUrl: contact.googleMapsUrl || ''
  };
  const defaultCommercial = {
    status: 'available', assignedTo: null, assignedToName: null, assignedAt: null, lastNoteAt: null,
    nextActionDate: null, completedAt: null, lastResult: null
  };
  const data = {
    companyName: contact.companyName,
    normalizedName: contact.normalizedName,
    matchKey: entityMatchKey(contact),
    searchText: [contact.companyName, contact.normalizedName, contact.city, contact.province, contact.email, contact.phone, summary.descriptionsPreview?.join(' ')].filter(Boolean).join(' ').toUpperCase(),
    contact: contactObj,
    customsSummary: summary,
    ...prospectIndexFields(contactObj, summary),
    // IMPORTANTE: no pisar asignaciones/gestiones cuando se suben archivos o se reprocesa match.
    // Si el prospecto ya existía, conserva commercial tal cual estaba.
    commercial: existingCommercial || defaultCommercial,
    match: {
      sourceContactName: contact.companyName,
      sourceCustomsName: customsGroup ? customsGroup.importador : '',
      customsGroupId: customsGroup ? customsGroup.id : '',
      matchScore,
      matchStatus
    },
    hasContact: true,
    hasCustoms: Boolean(customsGroup),
    updatedAt: nowISO()
  };
  if (!existing) data.createdAt = FieldValue.serverTimestamp();
  await ref.set(data, { merge: true });
}
async function syncMatches() {
  const contacts = await getAllDocs(C.contactSources);
  const customs = await getAllDocs(C.customsGroups);

  // Match oficial: se agrupa por matchKey unificado.
  // IMPORTANTE: una misma empresa puede tener varios grupos aduaneros/cargas/NCM.
  // Por eso no usamos un solo customsGroupId por key: todos los grupos con la misma key deben quedar matched.
  const customsByKey = new Map();
  for (const cg of customs) {
    const key = entityMatchKey(cg);
    if (!key) continue;
    if (!customsByKey.has(key)) customsByKey.set(key, []);
    customsByKey.get(key).push({ ...cg, matchKey: key });
  }
  const contactKeys = new Set(contacts.map(entityMatchKey).filter(Boolean));
  let matched = 0, probable = 0, unmatched = 0;
  const auditWrites = [];

  for (const cg of customs) {
    const key = entityMatchKey(cg);
    const cmatched = Boolean(key && contactKeys.has(key));
    auditWrites.push({ type: 'set', ref: db.collection(C.customsGroups).doc(cg.id), data: {
      matchKey: key,
      auditMatched: cmatched,
      auditMatchStatus: cmatched ? 'matched' : 'unmatched',
      auditUpdatedAt: nowISO()
    }});
  }

  for (const c of contacts) {
    const cKey = entityMatchKey(c);
    if (!cKey) continue;
    const groups = customsByKey.get(cKey) || [];
    if (groups.length) {
      const mergedSummary = mergeCustomsSummaries(groups.map(g => g.summary || {}));
      const syntheticGroup = {
        id: groups[0].id,
        groupIds: groups.map(g => g.id),
        importador: groups[0].importador || groups[0].companyName || '',
        normalizedName: groups[0].normalizedName || '',
        matchKey: cKey,
        summary: mergedSummary
      };
      await upsertProspectFromContact({ ...c, matchKey: cKey }, syntheticGroup, 100, 'matched');
      auditWrites.push({ type: 'set', ref: db.collection(C.contactSources).doc(c.id), data: {
        matchKey: cKey,
        auditMatched: true,
        auditMatchStatus: 'matched',
        auditBestScore: 100,
        auditBestCustomsName: syntheticGroup.importador || '',
        auditUpdatedAt: nowISO()
      }});
      matched++;
      continue;
    }

    // No unimos automáticamente por fuzzy para evitar macheos comerciales malos.
    // Solo guardamos el mejor candidato como referencia de revisión futura.
    let best = null, bestScore = 0;
    for (const cg of customs) {
      const sc = diceScore(c.normalizedName || c.companyName, cg.normalizedName || cg.importador);
      if (sc > bestScore) { bestScore = sc; best = cg; }
    }
    const status = best && bestScore >= 88 ? 'probable_review' : 'unmatched';
    if (status === 'probable_review') probable++;
    unmatched++;
    await upsertProspectFromContact({ ...c, matchKey: cKey }, null, bestScore, status);
    auditWrites.push({ type: 'set', ref: db.collection(C.contactSources).doc(c.id), data: {
      matchKey: cKey,
      auditMatched: false,
      auditMatchStatus: status,
      auditBestScore: bestScore,
      auditBestCustomsName: best?.importador || '',
      auditUpdatedAt: nowISO()
    }});
  }
  await batchCommitWrites(auditWrites);
  return { contacts: contacts.length, customsGroups: customs.length, matched, probable, unmatched, matchMode: 'matchKey_unificado_multi_grupo' };
}

async function syncMatchesForKeys(keys, reason = 'incremental') {
  // Match incremental: se usa al subir contactos/aduana para no reprocesar toda la base.
  // Recalcula solo las empresas afectadas por la carga nueva y preserva asignaciones comerciales.
  const uniqKeys = Array.from(new Set((keys || []).map(k => cleanText(k)).filter(Boolean)));
  let matched = 0, unmatchedContacts = 0, unmatchedCustoms = 0, contactsTouched = 0, customsTouched = 0, prospectWrites = 0;
  for (const key of uniqKeys) {
    const [contactSnap, customsSnap] = await Promise.all([
      db.collection(C.contactSources).where('matchKey', '==', key).limit(50).get(),
      db.collection(C.customsGroups).where('matchKey', '==', key).limit(1000).get()
    ]);
    const contacts = contactSnap.docs.map(d => ({ id: d.id, ref: d.ref, ...d.data() }));
    const groups = customsSnap.docs.map(d => ({ id: d.id, ref: d.ref, ...d.data() }));
    contactsTouched += contacts.length;
    customsTouched += groups.length;
    const writes = [];
    if (contacts.length && groups.length) {
      const mergedSummary = mergeCustomsSummaries(groups.map(g => g.summary || {}));
      const syntheticGroup = {
        id: groups[0].id,
        groupIds: groups.map(g => g.id),
        importador: groups[0].importador || groups[0].companyName || '',
        normalizedName: groups[0].normalizedName || '',
        matchKey: key,
        summary: mergedSummary
      };
      for (const c of contacts) {
        await upsertProspectFromContact({ ...c, matchKey: key }, syntheticGroup, 100, 'matched');
        writes.push({ type: 'set', ref: c.ref, data: {
          matchKey: key,
          auditMatched: true,
          auditMatchStatus: 'matched',
          auditBestScore: 100,
          auditBestCustomsName: syntheticGroup.importador || '',
          auditUpdatedAt: nowISO()
        }});
        matched++;
        prospectWrites++;
      }
      for (const g of groups) {
        writes.push({ type: 'set', ref: g.ref, data: {
          matchKey: key,
          auditMatched: true,
          auditMatchStatus: 'matched',
          auditUpdatedAt: nowISO()
        }});
      }
    } else if (contacts.length && !groups.length) {
      for (const c of contacts) {
        await upsertProspectFromContact({ ...c, matchKey: key }, null, 0, 'unmatched');
        writes.push({ type: 'set', ref: c.ref, data: {
          matchKey: key,
          auditMatched: false,
          auditMatchStatus: 'unmatched',
          auditBestScore: 0,
          auditUpdatedAt: nowISO()
        }});
        unmatchedContacts++;
        prospectWrites++;
      }
    } else if (!contacts.length && groups.length) {
      for (const g of groups) {
        writes.push({ type: 'set', ref: g.ref, data: {
          matchKey: key,
          auditMatched: false,
          auditMatchStatus: 'unmatched',
          auditUpdatedAt: nowISO()
        }});
        unmatchedCustoms++;
      }
    }
    if (writes.length) await batchCommitWrites(writes);
  }
  return { reason, mode: 'incremental_match_by_matchKey', keys: uniqKeys.length, contactsTouched, customsTouched, matched, unmatchedContacts, unmatchedCustoms, prospectWrites };
}

async function getCustomsMatchKeysForJob(jobId) {
  if (!jobId) return [];
  const snap = await db.collection(C.customsGroups).where('lastSourceJobId', '==', jobId).limit(20000).get();
  const keys = [];
  for (const d of snap.docs) {
    const x = { id: d.id, ...d.data() };
    const k = entityMatchKey(x);
    if (k) keys.push(k);
  }
  return Array.from(new Set(keys));
}
async function importContacts(buffer, filename, user) {
  logEvent('info', 'upload_contact_start', { filename, user: user.name });
  const rows = readXlsxRows(buffer);
  const jobRef = db.collection(C.jobs).doc();
  const sourceJobId = jobRef.id;
  const writes = [];
  const touchedKeys = new Set();
  let valid = 0, skipped = 0;
  for (const row of rows) {
    const c = mapContactRow(row);
    if (!c.companyName || !c.normalizedName) { skipped++; continue; }
    valid++;
    if (c.matchKey) touchedKeys.add(c.matchKey);
    writes.push({ type: 'set', ref: db.collection(C.contactSources).doc(safeId(c.normalizedName)), data: {
      ...c,
      uploadedBy: user.name,
      sourceFile: filename,
      sourceJobId,
      updatedAt: nowISO(),
      createdAt: FieldValue.serverTimestamp()
    }, options: { merge: true } });
  }
  await batchCommitWrites(writes);
  await jobRef.set({ id: sourceJobId, type: 'contact_upload', filename, rows: rows.length, valid, skipped, user: user.name, createdAt: nowISO(), deleted: false });
  const sync = await syncMatchesForKeys(Array.from(touchedKeys), 'contact_upload');
  const out = { sourceJobId, rows: rows.length, valid, skipped, sync };
  logEvent('info', 'upload_contact_done', { filename, ...out });
  return out;
}

async function buildSummaryFromItems(groupId) {
  const snap = await db.collection(C.customsItems).where('customsGroupId', '==', groupId).limit(50000).get();
  const items = snap.docs.map(d => d.data());
  return {
    totalFob: items.reduce((a, x) => a + Number(x.fob || 0), 0),
    importCount: items.length,
    positions: unique(items.map(x => x.posicion), 100),
    chapters: unique(items.map(x => x.chapter), 40),
    origins: topValues(items.map(x => x.origen), 15),
    procedencias: topValues(items.map(x => x.procedencia), 15),
    transports: topValues(items.map(x => x.transporte), 15),
    aduanas: topValues(items.map(x => x.aduana), 15),
    descriptionsPreview: unique(items.map(x => x.descripcion), 20)
  };
}

function mergeCustomsSummaries(summaries) {
  const out = {
    totalFob: 0,
    importCount: 0,
    positions: [],
    chapters: [],
    origins: [],
    procedencias: [],
    transports: [],
    aduanas: [],
    descriptionsPreview: []
  };
  const addUnique = (arr, vals, max) => {
    for (const v of (vals || [])) {
      const t = cleanText(v);
      if (t && !arr.includes(t)) arr.push(t);
      if (arr.length >= max) break;
    }
  };
  for (const sm of summaries || []) {
    if (!sm) continue;
    out.totalFob += Number(sm.totalFob || 0);
    out.importCount += Number(sm.importCount || 0);
    addUnique(out.positions, sm.positions, 150);
    addUnique(out.chapters, sm.chapters, 80);
    addUnique(out.origins, sm.origins, 50);
    addUnique(out.procedencias, sm.procedencias, 50);
    addUnique(out.transports, sm.transports, 50);
    addUnique(out.aduanas, sm.aduanas, 50);
    addUnique(out.descriptionsPreview, sm.descriptionsPreview, 50);
  }
  return out;
}

async function recomputeCustomsGroup(groupId, importador, normalizedName, filename, userName, sourceJobId = '') {
  const summary = await buildSummaryFromItems(groupId);
  await db.collection(C.customsGroups).doc(groupId).set({
    id: groupId,
    importador,
    normalizedName,
    matchKey: normalizeMatchKey(importador || normalizedName),
    summary,
    lastSourceFile: filename,
    lastSourceJobId: sourceJobId || '',
    uploadedBy: userName,
    updatedAt: nowISO(),
    createdAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return summary;
}

async function prepareCustomsJob(buffer, filename, user) {
  logEvent('info', 'customs_job_prepare_start', { filename, user: user.name });
  const rows = readXlsxRows(buffer);
  const jobRef = db.collection(C.jobs).doc();
  const jobId = jobRef.id;
  const chunkSize = Number(process.env.CUSTOMS_JOB_CHUNK_SIZE || 250);
  const writes = [];
  let chunkCount = 0;
  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunkRows = rows.slice(i, i + chunkSize);
    const chunkId = `${jobId}_${String(chunkCount).padStart(5, '0')}`;
    writes.push({ type: 'set', ref: db.collection(C.jobRows).doc(chunkId), data: {
      id: chunkId,
      jobId,
      index: chunkCount,
      startRow: i + 1,
      endRow: i + chunkRows.length,
      rows: chunkRows,
      done: false,
      createdAt: nowISO()
    }});
    chunkCount++;
  }
  await batchCommitWrites(writes);
  await jobRef.set({
    id: jobId,
    type: 'customs_upload_async',
    filename,
    status: 'queued',
    rows: rows.length,
    chunkSize,
    chunkCount,
    chunksDone: 0,
    processedRows: 0,
    valid: 0,
    skipped: 0,
    groups: 0,
    totalRowsIgnored: 0,
    inheritedImportadorRows: 0,
    itemWrites: 0,
    currentImportador: '',
    currentFecha: '',
    currentAduana: '',
    strictItemKey: true,
    user: user.name,
    createdAt: nowISO(),
    updatedAt: nowISO(),
    deleted: false
  });
  logEvent('info', 'customs_job_prepared', { filename, jobId, rows: rows.length, chunkCount });
  return { sourceJobId: jobId, mode: 'async', status: 'queued', rows: rows.length, chunkSize, chunkCount };
}

async function processCustomsRowsChunk(rows, filename, userName, sourceJobId, state) {
  const groups = new Map();
  let valid = 0, skipped = 0, totalRowsIgnored = 0, inheritedImportadorRows = 0;
  const current = {
    importador: state.currentImportador || '',
    fecha: state.currentFecha || '',
    aduana: state.currentAduana || ''
  };

  for (const row of rows) {
    const rawImportador = cleanImporterName(getHeader(row, ['Importador','Empresa','Nombre','Razon Social','Razón Social']));
    const rawFecha = cleanText(getHeader(row, ['Fecha','Date']));
    const rawAduana = cleanText(getHeader(row, ['Aduana']));

    if (Object.values(row || {}).some(v => isTotalLike(v))) {
      totalRowsIgnored++; skipped++; continue;
    }

    if (rawImportador && !isTotalLike(rawImportador)) current.importador = rawImportador;
    if (rawFecha && !isTotalLike(rawFecha)) current.fecha = rawFecha;
    if (rawAduana && !isTotalLike(rawAduana)) current.aduana = rawAduana;

    const item = mapCustomsRow(row, current);
    if (!rawImportador && item.importador) inheritedImportadorRows++;
    if (!isValidCustomsItem(item)) { skipped++; continue; }

    valid++;
    const norm = normalizeName(item.importador);
    if (!groups.has(norm)) groups.set(norm, { importador: item.importador, normalizedName: norm, items: [] });
    groups.get(norm).items.push(item);
  }

  const writes = [];
  const groupMeta = [];
  let itemWrites = 0;
  for (const [norm, g] of groups.entries()) {
    const id = safeId(norm);
    groupMeta.push({ id, importador: g.importador, normalizedName: norm, matchKey: normalizeMatchKey(g.importador || norm) });
    for (const it of g.items) {
      const key = customsItemKey(it, norm);
      const itemId = `${id}_${hashId(key)}`;
      itemWrites++;
      writes.push({ type: 'set', ref: db.collection(C.customsItems).doc(itemId), data: {
        ...it,
        itemKey: key,
        itemId,
        normalizedImportador: norm,
        normalizedImportadorKey: normalizeMatchKey(it.importador || norm),
        customsGroupId: id,
        prospectId: id,
        sourceFile: filename,
        sourceJobId,
        updatedAt: nowISO(),
        createdAt: FieldValue.serverTimestamp()
      }, options: { merge: true } });
    }
  }
  await batchCommitWrites(writes);
  for (const g of groupMeta) {
    await recomputeCustomsGroup(g.id, g.importador, g.normalizedName, filename, userName, sourceJobId);
  }

  return {
    valid, skipped, totalRowsIgnored, inheritedImportadorRows, itemWrites,
    groupsTouched: groupMeta.length,
    currentImportador: current.importador,
    currentFecha: current.fecha,
    currentAduana: current.aduana
  };
}

async function processCustomsJobStep(jobId, user, maxChunks = 1) {
  const jobRef = db.collection(C.jobs).doc(jobId);
  const jobSnap = await jobRef.get();
  if (!jobSnap.exists) throw new Error('Job no encontrado');
  const job = { id: jobSnap.id, ...jobSnap.data() };
  if (job.type !== 'customs_upload_async') throw new Error('El job no es de aduana async');
  if (job.deleted) throw new Error('La carga está borrada');
  const alreadyComplete = Number(job.chunksDone || 0) >= Number(job.chunkCount || 0) || Number(job.processedRows || 0) >= Number(job.rows || 0);
  if (job.status === 'done' || alreadyComplete) {
    let sync = job.sync || null;
    if (job.status !== 'done') {
      await jobRef.set({ status: 'done', completedAt: nowISO(), updatedAt: nowISO() }, { merge: true });
      try {
        const keys = await getCustomsMatchKeysForJob(jobId);
        sync = await syncMatchesForKeys(keys, 'customs_upload_done');
        await rebuildProspectIndexesInternal();
        await jobRef.set({ sync, updatedAt: nowISO() }, { merge: true });
      } catch (e) {
        await jobRef.set({ syncError: e.message, updatedAt: nowISO() }, { merge: true });
      }
    }
    const endSnap = await jobRef.get();
    return { done: true, processedChunks: 0, job: { id: endSnap.id, ...endSnap.data() }, sync };
  }

  let processedChunks = 0;
  let acc = { valid: 0, skipped: 0, totalRowsIgnored: 0, inheritedImportadorRows: 0, itemWrites: 0, groupsTouched: 0 };
  let state = {
    currentImportador: job.currentImportador || '',
    currentFecha: job.currentFecha || '',
    currentAduana: job.currentAduana || ''
  };

  await jobRef.set({ status: 'processing', updatedAt: nowISO(), error: '' }, { merge: true });

  while (processedChunks < maxChunks) {
    const chunkSnap = await db.collection(C.jobRows)
      .where('jobId', '==', jobId)
      .where('done', '==', false)
      .orderBy('index')
      .limit(1)
      .get();
    if (chunkSnap.empty) break;
    const doc = chunkSnap.docs[0];
    const chunk = doc.data();
    const r = await processCustomsRowsChunk(chunk.rows || [], job.filename || 'aduana.xlsx', job.user || user.name, jobId, state);
    state = { currentImportador: r.currentImportador, currentFecha: r.currentFecha, currentAduana: r.currentAduana };
    await doc.ref.set({ done: true, processedAt: nowISO(), result: r }, { merge: true });
    processedChunks++;
    for (const k of Object.keys(acc)) acc[k] += Number(r[k] || 0);
    await jobRef.set({
      chunksDone: FieldValue.increment(1),
      processedRows: FieldValue.increment((chunk.rows || []).length),
      valid: FieldValue.increment(r.valid || 0),
      skipped: FieldValue.increment(r.skipped || 0),
      totalRowsIgnored: FieldValue.increment(r.totalRowsIgnored || 0),
      inheritedImportadorRows: FieldValue.increment(r.inheritedImportadorRows || 0),
      itemWrites: FieldValue.increment(r.itemWrites || 0),
      groups: FieldValue.increment(r.groupsTouched || 0),
      currentImportador: state.currentImportador || '',
      currentFecha: state.currentFecha || '',
      currentAduana: state.currentAduana || '',
      updatedAt: nowISO()
    }, { merge: true });
  }

  const freshSnap = await jobRef.get();
  let fresh = { id: freshSnap.id, ...freshSnap.data() };
  const done = Number(fresh.chunksDone || 0) >= Number(fresh.chunkCount || 0);
  let sync = null;
  if (done) {
    await jobRef.set({ status: 'done', completedAt: nowISO(), updatedAt: nowISO() }, { merge: true });
    try {
      const keys = await getCustomsMatchKeysForJob(jobId);
      sync = await syncMatchesForKeys(keys, 'customs_upload_done');
      await rebuildProspectIndexesInternal();
      await jobRef.set({ sync, updatedAt: nowISO() }, { merge: true });
    } catch (e) {
      await jobRef.set({ syncError: e.message, updatedAt: nowISO() }, { merge: true });
    }
    const endSnap = await jobRef.get();
    fresh = { id: endSnap.id, ...endSnap.data() };
  }
  return { done, processedChunks, chunkResult: acc, job: fresh, sync };
}

async function getJobStatus(jobId) {
  const snap = await db.collection(C.jobs).doc(jobId).get();
  if (!snap.exists) throw new Error('Job no encontrado');
  return { id: snap.id, ...snap.data() };
}

async function importCustoms(buffer, filename, user) {
  logEvent('info', 'upload_customs_start', { filename, user: user.name });
  const rows = readXlsxRows(buffer);
  const jobRef = db.collection(C.jobs).doc();
  const sourceJobId = jobRef.id;
  const groups = new Map();
  let valid = 0, skipped = 0, totalRowsIgnored = 0, inheritedImportadorRows = 0;
  const current = { importador: '', fecha: '', aduana: '' };

  for (const row of rows) {
    const rawImportador = cleanImporterName(getHeader(row, ['Importador','Empresa','Nombre','Razon Social','Razón Social']));
    const rawFecha = cleanText(getHeader(row, ['Fecha','Date']));
    const rawAduana = cleanText(getHeader(row, ['Aduana']));

    // Ignora filas de totales/subtotales en cualquier columna relevante.
    if (Object.values(row || {}).some(v => isTotalLike(v))) {
      totalRowsIgnored++; skipped++; continue;
    }

    // Formato agrupado/pivot: una fila trae Importador/Fecha/Aduana y las
    // siguientes pueden venir vacías. Heredamos solo campos de agrupación,
    // NO heredamos posición/item/descripción porque eso define un ítem distinto.
    if (rawImportador && !isTotalLike(rawImportador)) current.importador = rawImportador;
    if (rawFecha && !isTotalLike(rawFecha)) current.fecha = rawFecha;
    if (rawAduana && !isTotalLike(rawAduana)) current.aduana = rawAduana;

    const item = mapCustomsRow(row, current);

    if (!rawImportador && item.importador) inheritedImportadorRows++;
    if (!isValidCustomsItem(item)) { skipped++; continue; }

    valid++;
    const norm = normalizeName(item.importador);
    if (!groups.has(norm)) groups.set(norm, { importador: item.importador, normalizedName: norm, items: [] });
    groups.get(norm).items.push(item);
  }

  // Guardamos ítems con itemKey 100% estricto. Si se sube de nuevo el mismo ítem,
  // cae en el mismo docId y no se duplica. Si cambia cualquier campo clave, es otro ítem.
  const writes = [];
  const groupMeta = [];
  let itemWrites = 0;
  for (const [norm, g] of groups.entries()) {
    const id = safeId(norm);
    groupMeta.push({ id, importador: g.importador, normalizedName: norm, matchKey: normalizeMatchKey(g.importador || norm) });
    for (const it of g.items) {
      const key = customsItemKey(it, norm);
      const itemId = `${id}_${hashId(key)}`;
      itemWrites++;
      writes.push({ type: 'set', ref: db.collection(C.customsItems).doc(itemId), data: {
        ...it,
        itemKey: key,
        itemId,
        normalizedImportador: norm,
        normalizedImportadorKey: normalizeMatchKey(it.importador || norm),
        customsGroupId: id,
        prospectId: id,
        sourceFile: filename,
        sourceJobId,
        updatedAt: nowISO(),
        createdAt: FieldValue.serverTimestamp()
      }, options: { merge: true } });
    }
  }
  await batchCommitWrites(writes);

  // Recalculamos resumen acumulado por empresa tomando todos los ítems ya guardados,
  // para que puedas subir aduana en archivos de 1000 filas y se vaya sumando.
  for (const g of groupMeta) {
    await recomputeCustomsGroup(g.id, g.importador, g.normalizedName, filename, user.name, sourceJobId);
  }

  await jobRef.set({
    id: sourceJobId, type: 'customs_upload', filename, rows: rows.length, valid, skipped,
    groups: groups.size, totalRowsIgnored, inheritedImportadorRows, itemWrites,
    strictItemKey: true, user: user.name, createdAt: nowISO(), deleted: false
  });
  const sync = await syncMatchesForKeys(groupMeta.map(g => g.matchKey).filter(Boolean), 'customs_upload');
  const out = { sourceJobId, rows: rows.length, valid, skipped, groups: groups.size, totalRowsIgnored, inheritedImportadorRows, itemWrites, strictItemKey: true, sync };
  logEvent('info', 'upload_customs_done', { filename, ...out });
  return out;
}

async function deleteQuery(q, maxLoops = 200) {
  let total = 0;
  for (let i = 0; i < maxLoops; i++) {
    const snap = await q.limit(450).get();
    if (snap.empty) break;
    const writes = snap.docs.map(d => ({ type: 'delete', ref: d.ref }));
    await batchCommitWrites(writes);
    total += snap.size;
    if (snap.size < 450) break;
  }
  return total;
}
async function adminJobs(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const snap = await db.collection(C.jobs).orderBy('createdAt', 'desc').limit(100).get();
  sendJson(res, { ok: true, jobs: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
}

async function adminAuditContacts(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const mode = cleanText(req.query.mode || 'all');
  const rawQ = cleanText(req.query.q || '');
  const q = upperNoAccents(rawQ);
  const qNorm = normalizeName(rawQ);
  const qKey = normalizeMatchKey(rawQ);
  const limit = Math.min(Math.max(Number(req.query.limit || 20), 1), 50);
  let ref = db.collection(C.contactSources);
  if (mode === 'matched') ref = ref.where('auditMatched', '==', true);
  if (mode === 'unmatched') ref = ref.where('auditMatched', '==', false);
  const fetchLimit = q ? Math.min(200, Math.max(limit * 5, 20)) : limit;
  const promises = [
    safeCollectionCount(C.contactSources),
    safeQueryCount(db.collection(C.contactSources).where('auditMatched', '==', true), 'contacts_matched'),
    safeQueryCount(db.collection(C.contactSources).where('auditMatched', '==', false), 'contacts_unmatched'),
    ref.limit(fetchLimit).get()
  ];
  if (q) {
    promises.push(db.collection(C.contactSources).doc(safeId(rawQ)).get().catch(()=>null));
    if (qNorm) promises.push(db.collection(C.contactSources).where('normalizedName', '==', qNorm).limit(limit).get().catch(()=>null));
    if (qKey) promises.push(db.collection(C.contactSources).where('matchKey', '==', qKey).limit(limit).get().catch(()=>null));
  }
  const out = await Promise.all(promises);
  const [allCount, matchedCount, unmatchedCount, snap] = out;
  const byId = new Map();
  function addDoc(d) {
    if (!d || !d.exists) return;
    const c = { id: d.id, ...d.data() };
    if (mode === 'matched' && c.auditMatched !== true) return;
    if (mode === 'unmatched' && c.auditMatched !== false) return;
    byId.set(c.id, c);
  }
  for (const d of snap.docs) addDoc(d);
  for (const extra of out.slice(4)) {
    if (!extra) continue;
    if (extra.docs) extra.docs.forEach(addDoc); else addDoc(extra);
  }
  let rows = [...byId.values()].map(c => {
    const matched = c.auditMatched === true;
    return { ...c, matched, matchStatus: c.auditMatchStatus || (matched ? 'matched' : 'unmatched') };
  });
  if (q) rows = rows.filter(x => {
    const text = upperNoAccents([x.companyName, x.importador, x.normalizedName, x.city, x.province, x.phone, x.email, x.website].filter(Boolean).join(' '));
    const xKey = x.matchKey || normalizeMatchKey(x.companyName || x.importador || x.normalizedName || '');
    return text.includes(q) || (qNorm && x.normalizedName === qNorm) || (qKey && xKey === qKey);
  }).slice(0, limit);
  const counts = { all: allCount, matched: matchedCount, unmatched: unmatchedCount, scanLimit: fetchLimit, directLookup: Boolean(q) };
  sendJson(res, { ok: true, mode, counts, rows, lowReads: true });
}
async function adminAuditCustoms(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const mode = cleanText(req.query.mode || 'all');
  const rawQ = cleanText(req.query.q || '');
  const q = upperNoAccents(rawQ);
  const qNorm = normalizeName(rawQ);
  const qKey = normalizeMatchKey(rawQ);
  const limit = Math.min(Math.max(Number(req.query.limit || 20), 1), 50);
  let ref = db.collection(C.customsGroups);
  if (mode === 'matched') ref = ref.where('auditMatched', '==', true);
  if (mode === 'unmatched') ref = ref.where('auditMatched', '==', false);
  const fetchLimit = q ? Math.min(200, Math.max(limit * 5, 20)) : limit;
  const promises = [
    safeCollectionCount(C.customsGroups),
    safeQueryCount(db.collection(C.customsGroups).where('auditMatched', '==', true), 'customs_matched'),
    safeQueryCount(db.collection(C.customsGroups).where('auditMatched', '==', false), 'customs_unmatched'),
    ref.limit(fetchLimit).get()
  ];
  if (q) {
    promises.push(db.collection(C.customsGroups).doc(safeId(rawQ)).get().catch(()=>null));
    if (qNorm) promises.push(db.collection(C.customsGroups).where('normalizedName', '==', qNorm).limit(limit).get().catch(()=>null));
    if (qKey) promises.push(db.collection(C.customsGroups).where('matchKey', '==', qKey).limit(limit).get().catch(()=>null));
  }
  const out = await Promise.all(promises);
  const [allCount, matchedCount, unmatchedCount, snap] = out;
  const byId = new Map();
  function addDoc(d) {
    if (!d || !d.exists) return;
    const cg = { id: d.id, ...d.data() };
    if (mode === 'matched' && cg.auditMatched !== true) return;
    if (mode === 'unmatched' && cg.auditMatched !== false) return;
    byId.set(cg.id, cg);
  }
  for (const d of snap.docs) addDoc(d);
  for (const extra of out.slice(4)) {
    if (!extra) continue;
    if (extra.docs) extra.docs.forEach(addDoc); else addDoc(extra);
  }
  let rows = [...byId.values()].map(cg => {
    const matched = cg.auditMatched === true;
    return { ...cg, matched, matchStatus: cg.auditMatchStatus || (matched ? 'matched' : 'unmatched') };
  });
  if (q) rows = rows.filter(x => {
    const text = upperNoAccents([x.importador, x.companyName, x.normalizedName, (x.summary?.origins||[]).join(' '), (x.summary?.chapters||[]).join(' '), (x.summary?.positions||[]).join(' '), (x.summary?.descriptionsPreview||[]).join(' ')].filter(Boolean).join(' '));
    const xKey = x.matchKey || normalizeMatchKey(x.importador || x.companyName || x.normalizedName || '');
    return text.includes(q) || (qNorm && x.normalizedName === qNorm) || (qKey && xKey === qKey);
  }).slice(0, limit);
  const counts = { all: allCount, matched: matchedCount, unmatched: unmatchedCount, scanLimit: fetchLimit, directLookup: Boolean(q) };
  sendJson(res, { ok: true, mode, counts, rows, lowReads: true });
}

async function adminAuditCustomsItems(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const groupId = cleanText(req.query.customsGroupId || req.query.id || '');
  const limit = Math.min(Math.max(Number(req.query.limit || 200), 1), 500);
  if (!groupId) return sendJson(res, { ok: false, error: 'Falta customsGroupId' }, 400);
  const gdoc = await db.collection(C.customsGroups).doc(groupId).get();
  if (!gdoc.exists) return sendJson(res, { ok: false, error: 'Grupo aduanero no encontrado.' }, 404);
  const group = { id: gdoc.id, ...gdoc.data() };
  const norm = group.normalizedName || groupId;

  // Ver ítems debe buscar por importador normalizado, no solo por groupId.
  // Si por cambios viejos de parser algún ítem quedó con otro customsGroupId,
  // igual aparece en el detalle del importador correcto.
  let snap;
  try {
    snap = await db.collection(C.customsItems).where('normalizedImportador', '==', norm).limit(limit).get();
  } catch (e) {
    snap = await db.collection(C.customsItems).where('customsGroupId', '==', groupId).limit(limit).get();
  }
  let items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  items.sort((a,b) => {
    const ka = [a.fecha, a.destinacion, String(a.item || '').padStart(8,'0'), a.posicion, a.descripcion].join('|');
    const kb = [b.fecha, b.destinacion, String(b.item || '').padStart(8,'0'), b.posicion, b.descripcion].join('|');
    return ka.localeCompare(kb, 'es');
  });
  sendJson(res, { ok: true, group, items, showing: items.length, limit, lowReads: true, byNormalizedImportador: norm });
}

async function adminAuditSellerProspects(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const sellerId = cleanText(req.query.sellerId || '');
  const status = cleanText(req.query.status || 'open');
  const q = upperNoAccents(req.query.q || '');
  const limit = Math.min(Math.max(Number(req.query.limit || 20), 1), 50);
  if (!sellerId) return sendJson(res, { ok: false, error: 'Falta sellerId' }, 400);
  let ref = db.collection(C.prospects).where('commercial.assignedTo', '==', sellerId);
  const snap = await ref.limit(q ? Math.min(200, Math.max(limit * 5, 20)) : limit).get();
  let rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  if (status === 'open') rows = rows.filter(p => ['assigned','in_progress'].includes(p.commercial?.status || ''));
  else if (status === 'completed') rows = rows.filter(p => ['completed','discarded'].includes(p.commercial?.status || ''));
  else if (status === 'assigned') rows = rows.filter(p => (p.commercial?.status || '') === 'assigned');
  else if (status === 'in_progress') rows = rows.filter(p => (p.commercial?.status || '') === 'in_progress');
  if (q) rows = rows.filter(p => upperNoAccents([p.companyName, p.contact?.city, p.contact?.province, p.commercial?.lastResult, (p.customsSummary?.chapters||[]).join(' '), (p.customsSummary?.origins||[]).join(' ')].filter(Boolean).join(' ')).includes(q));
  rows = rows.slice(0, limit);
  const [openCount, completedCount, totalCount] = await Promise.all([
    getQueryCount(db.collection(C.prospects).where('commercial.assignedTo', '==', sellerId).where('commercial.status', 'in', ['assigned','in_progress']), 1000).catch(()=>null),
    getQueryCount(db.collection(C.prospects).where('commercial.assignedTo', '==', sellerId).where('commercial.status', 'in', ['completed','discarded']), 1000).catch(()=>null),
    getQueryCount(db.collection(C.prospects).where('commercial.assignedTo', '==', sellerId), 1000).catch(()=>null)
  ]);
  sendJson(res, { ok: true, sellerId, status, counts: { total: totalCount, open: openCount, completed: completedCount }, rows, lowReads: true });
}
async function adminReleaseSellerProspects(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const sellerId = cleanText(req.body.sellerId || req.query.sellerId || '');
  const ids = Array.isArray(req.body.ids) ? req.body.ids.map(cleanText).filter(Boolean) : [];
  const confirm = cleanText(req.body.confirm || '');
  if (!sellerId) return sendJson(res, { ok: false, error: 'Falta sellerId' }, 400);
  if (!ids.length) return sendJson(res, { ok: false, error: 'No seleccionaste prospectos.' }, 400);
  if (ids.length > 500) return sendJson(res, { ok: false, error: 'Máximo 500 por operación.' }, 400);
  if (confirm !== 'LIBERAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: LIBERAR' }, 400);
  let released = 0, skipped = 0;
  const writes = [];
  for (const id of ids) {
    const ref = db.collection(C.prospects).doc(id);
    const d = await ref.get();
    if (!d.exists) { skipped++; continue; }
    const p = d.data();
    if (p.commercial?.assignedTo !== sellerId) { skipped++; continue; }
    writes.push({ type: 'set', ref, data: { commercial: { ...(p.commercial || {}), status: 'available', assignedTo: null, assignedToName: null, assignedAt: null, assignedBy: null, releasedAt: nowISO(), releasedBy: currentUser(req).name }, updatedAt: nowISO() }, options: { merge: true } });
    released++;
  }
  await batchCommitWrites(writes);
  sendJson(res, { ok: true, released, skipped });
}
async function adminReleaseAllSellerOpen(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const sellerId = cleanText(req.body.sellerId || req.query.sellerId || '');
  const confirm = cleanText(req.body.confirm || '');
  const limit = Math.min(Math.max(Number(req.body.limit || 200), 1), 500);
  if (!sellerId) return sendJson(res, { ok: false, error: 'Falta sellerId' }, 400);
  if (confirm !== 'LIBERAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: LIBERAR' }, 400);
  const snap = await db.collection(C.prospects).where('commercial.assignedTo', '==', sellerId).where('commercial.status', 'in', ['assigned','in_progress']).limit(limit).get();
  const writes = [];
  for (const d of snap.docs) {
    const p = d.data();
    writes.push({ type: 'set', ref: d.ref, data: { commercial: { ...(p.commercial || {}), status: 'available', assignedTo: null, assignedToName: null, assignedAt: null, assignedBy: null, releasedAt: nowISO(), releasedBy: currentUser(req).name }, updatedAt: nowISO() }, options: { merge: true } });
  }
  await batchCommitWrites(writes);
  sendJson(res, { ok: true, released: writes.length, limit });
}

async function adminDeleteContact(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  if (cleanText(req.body.confirm || req.query.confirm) !== 'BORRAR') return sendJson(res, { ok: false, error: 'Confirmación inválida. Escribí BORRAR.' }, 400);
  const id = cleanText(req.body.id || req.query.id);
  if (!id) return sendJson(res, { ok: false, error: 'Falta id' }, 400);
  await db.collection(C.contactSources).doc(id).delete();
  await db.collection(C.prospects).doc(id).delete().catch(()=>{});
  await deleteQuery(db.collection(C.notes).where('prospectId', '==', id));
  sendJson(res, { ok: true, deleted: { contact: 1, prospect: 1 } });
}
async function adminDeleteCustomsGroup(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  if (cleanText(req.body.confirm || req.query.confirm) !== 'BORRAR') return sendJson(res, { ok: false, error: 'Confirmación inválida. Escribí BORRAR.' }, 400);
  const id = cleanText(req.body.id || req.query.id);
  if (!id) return sendJson(res, { ok: false, error: 'Falta id' }, 400);
  const items = await deleteQuery(db.collection(C.customsItems).where('customsGroupId', '==', id));
  await db.collection(C.customsGroups).doc(id).delete().catch(()=>{});
  await db.collection(C.prospects).doc(id).delete().catch(()=>{});
  await deleteQuery(db.collection(C.notes).where('prospectId', '==', id));
  sendJson(res, { ok: true, deleted: { customsGroup: 1, customsItems: items, prospect: 1 } });
}
async function adminReleaseProspect(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const id = cleanText(req.body.prospectId || req.query.id);
  if (!id) return sendJson(res, { ok: false, error: 'Falta prospectId' }, 400);
  const ref = db.collection(C.prospects).doc(id);
  const doc = await ref.get();
  if (!doc.exists) return sendJson(res, { ok: false, error: 'Prospecto no encontrado' }, 404);
  const p = doc.data();
  await ref.set({ commercial: { ...(p.commercial || {}), status: 'available', assignedTo: null, assignedToName: null, assignedAt: null }, updatedAt: nowISO() }, { merge: true });
  sendJson(res, { ok: true, released: id });
}
async function adminDeleteProspect(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const id = cleanText(req.body.prospectId || req.query.id);
  const mode = cleanText(req.body.mode || req.query.mode || 'prospect_only');
  const confirm = cleanText(req.body.confirm || req.query.confirm);
  if (confirm !== 'BORRAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: BORRAR' }, 400);
  if (!id) return sendJson(res, { ok: false, error: 'Falta prospectId' }, 400);
  const pdoc = await db.collection(C.prospects).doc(id).get();
  const p = pdoc.exists ? pdoc.data() : null;
  let deleted = { prospect: 0, contact: 0, customsGroup: 0, customsItems: 0, notes: 0 };
  deleted.notes = await deleteQuery(db.collection(C.notes).where('prospectId', '==', id));
  await db.collection(C.tasks).doc(id).delete().catch(()=>{});
  await db.collection(C.prospects).doc(id).delete(); deleted.prospect = 1;
  if (mode === 'contact_and_customs' || mode === 'full') {
    await db.collection(C.contactSources).doc(id).delete().catch(()=>{}); deleted.contact = 1;
    const groupId = p?.match?.customsGroupId || id;
    deleted.customsItems = await deleteQuery(db.collection(C.customsItems).where('customsGroupId', '==', groupId));
    await db.collection(C.customsGroups).doc(groupId).delete().catch(()=>{}); deleted.customsGroup = 1;
  } else if (mode === 'contact_only') {
    await db.collection(C.contactSources).doc(id).delete().catch(()=>{}); deleted.contact = 1;
  }
  sendJson(res, { ok: true, deleted, mode });
}

async function adminDeleteJobStep(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const jobId = cleanText(req.body.jobId || req.query.jobId);
  const confirm = cleanText(req.body.confirm || req.query.confirm);
  if (confirm !== 'BORRAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: BORRAR' }, 400);
  if (!jobId) return sendJson(res, { ok: false, error: 'Falta jobId' }, 400);

  const jobRef = db.collection(C.jobs).doc(jobId);
  const jobDoc = await jobRef.get();
  if (!jobDoc.exists) return sendJson(res, { ok: false, error: 'Carga no encontrada' }, 404);
  const job = { id: jobDoc.id, ...jobDoc.data() };
  if (job.deleted === true || job.deleteStatus === 'done') {
    return sendJson(res, { ok: true, done: true, jobId, message: 'La carga ya estaba borrada.', progress: job.deleteProgress || {} });
  }

  const startedAt = job.deleteStartedAt || nowISO();
  const progress = job.deleteProgress || { contacts: 0, prospects: 0, notes: 0, customsItems: 0, customsGroupsDeleted: 0, customsGroupsRecomputed: 0, jobRowsDeleted: 0, steps: 0 };
  const maxDocs = Math.min(Math.max(Number(req.body.maxDocs || req.query.maxDocs || 300), 50), 450);
  let touched = 0;
  let finished = false;
  let message = '';

  async function deleteNotesForProspect(id) {
    const n = await deleteQuery(db.collection(C.notes).where('prospectId', '==', id), 2);
    progress.notes = Number(progress.notes || 0) + n;
    await db.collection(C.tasks).doc(id).delete().catch(()=>{});
  }

  if (job.type === 'contact_upload') {
    let snap = await db.collection(C.contactSources).where('sourceJobId', '==', jobId).limit(maxDocs).get();
    if (snap.empty && job.filename && !job.deleteFallbackUsed) {
      snap = await db.collection(C.contactSources).where('sourceFile', '==', job.filename).limit(maxDocs).get();
      await jobRef.set({ deleteFallbackUsed: true }, { merge: true });
    }
    if (!snap.empty) {
      const ids = snap.docs.map(d => d.id);
      await batchCommitWrites(snap.docs.map(d => ({ type: 'delete', ref: d.ref })));
      progress.contacts = Number(progress.contacts || 0) + snap.size;
      touched += snap.size;
      for (const id of ids) {
        await db.collection(C.prospects).doc(id).delete().then(()=>{ progress.prospects = Number(progress.prospects || 0) + 1; }).catch(()=>{});
        await deleteNotesForProspect(id);
      }
      message = `Borrando contactos... ${progress.contacts}`;
    } else {
      finished = true;
    }
  } else if (job.type === 'customs_upload' || job.type === 'customs_upload_async') {
    let snap = await db.collection(C.customsItems).where('sourceJobId', '==', jobId).limit(maxDocs).get();
    if (snap.empty && job.filename && !job.deleteFallbackUsed) {
      snap = await db.collection(C.customsItems).where('sourceFile', '==', job.filename).limit(maxDocs).get();
      await jobRef.set({ deleteFallbackUsed: true }, { merge: true });
    }
    if (!snap.empty) {
      const groupIds = [...new Set(snap.docs.map(d => d.data().customsGroupId).filter(Boolean))];
      await batchCommitWrites(snap.docs.map(d => ({ type: 'delete', ref: d.ref })));
      progress.customsItems = Number(progress.customsItems || 0) + snap.size;
      touched += snap.size;
      for (const groupId of groupIds) {
        const rest = await db.collection(C.customsItems).where('customsGroupId', '==', groupId).limit(1).get();
        if (rest.empty) {
          await db.collection(C.customsGroups).doc(groupId).delete().catch(()=>{});
          await db.collection(C.prospects).doc(groupId).delete().catch(()=>{});
          await deleteNotesForProspect(groupId);
          progress.customsGroupsDeleted = Number(progress.customsGroupsDeleted || 0) + 1;
        } else {
          const gdoc = await db.collection(C.customsGroups).doc(groupId).get();
          const g = gdoc.exists ? gdoc.data() : { importador: groupId, normalizedName: groupId };
          await recomputeCustomsGroup(groupId, g.importador || groupId, g.normalizedName || groupId, job.filename || '', currentUser(req).name, '');
          progress.customsGroupsRecomputed = Number(progress.customsGroupsRecomputed || 0) + 1;
        }
      }
      message = `Borrando ítems aduaneros... ${progress.customsItems}`;
    } else if (job.type === 'customs_upload_async') {
      const rs = await db.collection(C.jobRows).where('jobId', '==', jobId).limit(maxDocs).get();
      if (!rs.empty) {
        await batchCommitWrites(rs.docs.map(d => ({ type: 'delete', ref: d.ref })));
        progress.jobRowsDeleted = Number(progress.jobRowsDeleted || 0) + rs.size;
        touched += rs.size;
        message = `Borrando filas temporales del job... ${progress.jobRowsDeleted}`;
      } else {
        finished = true;
      }
    } else {
      finished = true;
    }
  } else {
    return sendJson(res, { ok: false, error: 'Tipo de carga no soportado para borrado por progreso', job }, 400);
  }

  progress.steps = Number(progress.steps || 0) + 1;
  const estimatedTotal = Number(job.itemWrites || job.valid || job.rows || 0) || 0;
  const deletedMain = job.type === 'contact_upload' ? Number(progress.contacts || 0) : Number(progress.customsItems || 0);
  const percent = estimatedTotal ? Math.min(100, Math.round((deletedMain / estimatedTotal) * 100)) : (finished ? 100 : 0);

  if (finished) {
    if (job.type === 'customs_upload' || job.type === 'customs_upload_async') {
      await syncMatches().catch(e => logEvent('warn', 'sync_after_delete_failed', { jobId, error: e.message }));
    }
    await jobRef.set({
      deleted: true,
      deletedAt: nowISO(),
      deletedBy: currentUser(req).name,
      deleteStatus: 'done',
      deleteFinishedAt: nowISO(),
      deleteProgress: { ...progress, percent: 100, estimatedTotal },
      deleteResult: progress
    }, { merge: true });
    return sendJson(res, { ok: true, done: true, jobId, percent: 100, progress, message: 'Borrado terminado.' });
  }

  await jobRef.set({
    deleteStatus: 'processing',
    deleteStartedAt: startedAt,
    deleteUpdatedAt: nowISO(),
    deleteProgress: { ...progress, percent, estimatedTotal }
  }, { merge: true });
  return sendJson(res, { ok: true, done: false, jobId, percent, progress, touched, message });
}

async function adminDeleteJob(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const jobId = cleanText(req.body.jobId || req.query.jobId);
  const confirm = cleanText(req.body.confirm || req.query.confirm);
  if (confirm !== 'BORRAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: BORRAR' }, 400);
  if (!jobId) return sendJson(res, { ok: false, error: 'Falta jobId' }, 400);
  const jobRef = db.collection(C.jobs).doc(jobId);
  const jobDoc = await jobRef.get();
  if (!jobDoc.exists) return sendJson(res, { ok: false, error: 'Carga no encontrada' }, 404);
  const job = { id: jobDoc.id, ...jobDoc.data() };
  let result = { jobId, type: job.type, contacts: 0, prospects: 0, customsItems: 0, customsGroupsDeleted: 0, customsGroupsRecomputed: 0, notes: 0, fallbackBySourceFile: false };
  if (job.type === 'contact_upload') {
    let snap = await db.collection(C.contactSources).where('sourceJobId', '==', jobId).limit(5000).get();
    if (snap.empty && job.filename) { snap = await db.collection(C.contactSources).where('sourceFile', '==', job.filename).limit(5000).get(); result.fallbackBySourceFile = true; }
    const ids = snap.docs.map(d => d.id);
    result.contacts = snap.size;
    await batchCommitWrites(snap.docs.map(d => ({ type: 'delete', ref: d.ref })));
    for (const id of ids) {
      await db.collection(C.prospects).doc(id).delete().then(()=>{result.prospects++}).catch(()=>{});
      result.notes += await deleteQuery(db.collection(C.notes).where('prospectId', '==', id));
      await db.collection(C.tasks).doc(id).delete().catch(()=>{});
    }
  } else if (job.type === 'customs_upload' || job.type === 'customs_upload_async') {
    let snap = await db.collection(C.customsItems).where('sourceJobId', '==', jobId).limit(10000).get();
    if (snap.empty && job.filename) { snap = await db.collection(C.customsItems).where('sourceFile', '==', job.filename).limit(10000).get(); result.fallbackBySourceFile = true; }
    const groupIds = [...new Set(snap.docs.map(d => d.data().customsGroupId).filter(Boolean))];
    result.customsItems = snap.size;
    await batchCommitWrites(snap.docs.map(d => ({ type: 'delete', ref: d.ref })));
    for (const groupId of groupIds) {
      const rest = await db.collection(C.customsItems).where('customsGroupId', '==', groupId).limit(1).get();
      if (rest.empty) {
        await db.collection(C.customsGroups).doc(groupId).delete().catch(()=>{});
        result.customsGroupsDeleted++;
      } else {
        const gdoc = await db.collection(C.customsGroups).doc(groupId).get();
        const g = gdoc.exists ? gdoc.data() : { importador: groupId, normalizedName: groupId };
        await recomputeCustomsGroup(groupId, g.importador || groupId, g.normalizedName || groupId, job.filename || '', currentUser(req).name, '');
        result.customsGroupsRecomputed++;
      }
    }
    if (job.type === 'customs_upload_async') result.jobRowsDeleted = await deleteQuery(db.collection(C.jobRows).where('jobId', '==', jobId));
    await syncMatches();
  } else {
    return sendJson(res, { ok: false, error: 'Tipo de carga no soportado para borrado', job }, 400);
  }
  await jobRef.set({ deleted: true, deletedAt: nowISO(), deletedBy: currentUser(req).name, deleteResult: result }, { merge: true });
  sendJson(res, { ok: true, result });
}
async function adminDeleteAll(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const confirm = cleanText(req.body.confirm || req.query.confirm);
  if (confirm !== 'BORRAR TODO') return sendJson(res, { ok: false, error: 'Confirmación requerida: BORRAR TODO' }, 400);
  const result = {};
  for (const [key, col] of Object.entries(C)) {
    result[key] = await deleteQuery(db.collection(col));
  }
  sendJson(res, { ok: true, deleted: result });
}
function applyProspectFiltersLocal(p, filters) {
  const province = normFilterValue(filters.province || '');
  const city = normFilterValue(filters.city || '');
  const origin = normFilterValue(filters.origin || '');
  const desc = normFilterValue(filters.desc || '');
  const chapter = String(filters.chapter || '').trim();
  const pProvinceNorm = provinceFilterKey(p.contact?.province || '');
  const pCityNorm = normFilterValue(p.contact?.city || '');
  if (province && pProvinceNorm !== province) return false;
  if (city && pCityNorm !== city && pCityNorm.includes(city) === false) return false;
  if (chapter && !(p.customsSummary?.chapters || []).map(String).includes(chapter)) return false;
  if (origin && !(p.customsSummary?.origins || []).join(' ').toUpperCase().includes(origin)) return false;
  if (desc && !normFilterValue([p.searchText, p.customsDescriptionsNorm].filter(Boolean).join(' ')).includes(desc)) return false;
  const totalFob = Number(p.customsSummary?.totalFob || 0);
  if (filters.minFob && totalFob < Number(filters.minFob)) return false;
  if (filters.maxFob && totalFob > Number(filters.maxFob)) return false;
  if (filters.fobRange) {
    const r = String(filters.fobRange);
    if (r === '0-5000' && !(totalFob <= 5000)) return false;
    if (r === '5000-25000' && !(totalFob >= 5000 && totalFob <= 25000)) return false;
    if (r === '25000-50000' && !(totalFob >= 25000 && totalFob <= 50000)) return false;
    if (r === '50000-75000' && !(totalFob >= 50000 && totalFob <= 75000)) return false;
    if (r === '100000+' && !(totalFob >= 100000)) return false;
  }
  return true;
}
function queryHasProspectFilters(filters) {
  return Boolean(filters.province || filters.city || filters.chapter || filters.origin || filters.desc || filters.minFob || filters.maxFob || filters.fobRange);
}
function addIndexedProspectFilters(ref, filters) {
  // Usamos filtros indexados solo cuando son exactos para no leer toda la colección.
  // Provincia/Ciudad deben buscarse por el nombre completo: Catamarca, Rosario, etc.
  const province = normFilterValue(filters.province || '');
  const city = normFilterValue(filters.city || '');
  const chapter = String(filters.chapter || '').trim();
  const origin = normFilterValue(filters.origin || '');
  if (province) ref = ref.where('contactProvinceNorm', '==', province);
  if (city) ref = ref.where('contactCityNorm', '==', city);
  if (chapter) ref = ref.where('customsChapters', 'array-contains', chapter);
  // No combinamos origen como array-contains si ya hay chapter para evitar índices compuestos innecesarios.
  if (origin && !chapter) ref = ref.where('customsOriginsNorm', 'array-contains', origin);
  return ref;
}
async function rebuildProspectIndexesInternal() {
  const snap = await db.collection(C.prospects).limit(20000).get();
  const writes = [];
  for (const d of snap.docs) {
    const p = d.data();
    const contact = p.contact || {};
    const summary = p.customsSummary || {};
    writes.push({ type: 'set', ref: d.ref, data: { ...prospectIndexFields(contact, summary), indexUpdatedAt: nowISO() }, options: { merge: true } });
  }
  await batchCommitWrites(writes);
  return { updated: writes.length };
}

async function rebuildProspectIndexes(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const snap = await db.collection(C.prospects).limit(20000).get();
  let writes = [], updated = 0;
  for (const d of snap.docs) {
    const p = d.data();
    writes.push({ type: 'set', ref: d.ref, data: prospectIndexFields(p.contact || {}, p.customsSummary || {}), options: { merge: true } });
    updated++;
  }
  await batchCommitWrites(writes);
  sendJson(res, { ok: true, updated, note: 'Índices de filtros reconstruidos. Ahora Disponibles filtra con low reads.' });
}

async function adminReprocessMatch(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const confirm = cleanText(req.body?.confirm || req.query.confirm || '');
  if (confirm !== 'MATCH') return sendJson(res, { ok: false, error: 'Confirmación requerida: MATCH' }, 400);
  const jobRef = db.collection(C.jobs).doc();
  const [contactsTotal, customsTotal] = await Promise.all([
    getQueryCount(db.collection(C.contactSources), 50000).catch(()=>0),
    getQueryCount(db.collection(C.customsGroups), 50000).catch(()=>0)
  ]);
  const payload = {
    type: 'match_reprocess_async',
    filename: 'Reprocesar match',
    status: 'queued',
    stage: 'customs',
    rows: Number(contactsTotal || 0) + Number(customsTotal || 0),
    valid: 0,
    contactsTotal: Number(contactsTotal || 0),
    customsTotal: Number(customsTotal || 0),
    processedContacts: 0,
    processedCustoms: 0,
    matched: 0,
    unmatched: 0,
    indexWrites: 0,
    prospectWrites: 0,
    preserveAssignments: true,
    createdAt: nowISO(),
    updatedAt: nowISO(),
    user: currentUser(req).name
  };
  await jobRef.set(payload);
  sendJson(res, { ok: true, mode: 'async', jobId: jobRef.id, job: { id: jobRef.id, ...payload }, note: 'Job de reproceso creado. Procesar por tandas para evitar timeout y exceso de reads.' });
}

async function processReprocessMatchJobStep(jobId, user, maxDocs = 100) {
  if (!jobId) throw new Error('Falta jobId');
  const jobRef = db.collection(C.jobs).doc(jobId);
  const snap = await jobRef.get();
  if (!snap.exists) throw new Error('Job de match no encontrado');
  const job = { id: snap.id, ...snap.data() };
  if (job.type !== 'match_reprocess_async') throw new Error('El job no es de reprocesar match');
  if (job.deleted) throw new Error('El job está borrado');
  if (job.status === 'done') return { done: true, job };

  const limit = Math.min(Math.max(Number(maxDocs || 100), 25), 250);
  let stage = job.stage || 'customs';
  let processed = 0;
  let stageDone = false;
  let matched = 0;
  let unmatched = 0;
  let indexWrites = 0;
  let prospectWrites = 0;

  await jobRef.set({ status: 'processing', updatedAt: nowISO(), error: '' }, { merge: true });

  if (stage === 'customs') {
    let q = db.collection(C.customsGroups).orderBy(FieldPath.documentId()).limit(limit);
    if (job.lastCustomsDocId) q = q.startAfter(job.lastCustomsDocId);
    const qs = await q.get();
    if (qs.empty) {
      stageDone = true;
    } else {
      const writes = [];
      for (const d of qs.docs) {
        const cg = { id: d.id, ...d.data() };
        const key = entityMatchKey(cg);
        if (!key) continue;
        const idxRef = db.collection(C.matchIndex).doc(key);
        writes.push({ type: 'set', ref: d.ref, data: {
          matchKey: key,
          auditMatched: false,
          auditMatchStatus: 'unmatched',
          auditUpdatedAt: nowISO()
        }});
        writes.push({ type: 'set', ref: idxRef, data: {
          matchKey: key,
          customsGroupId: d.id,
          importador: cg.importador || cg.companyName || '',
          normalizedName: cg.normalizedName || normalizeName(cg.importador || ''),
          summary: cg.summary || {},
          source: 'customsGroups',
          updatedAt: nowISO()
        }});
        indexWrites++;
      }
      await batchCommitWrites(writes);
      processed = qs.size;
      const lastId = qs.docs[qs.docs.length - 1].id;
      const nextStage = qs.size < limit ? 'contacts' : 'customs';
      await jobRef.set({
        stage: nextStage,
        processedCustoms: FieldValue.increment(qs.size),
        indexWrites: FieldValue.increment(indexWrites),
        lastCustomsDocId: lastId,
        updatedAt: nowISO()
      }, { merge: true });
      if (nextStage === 'contacts') stageDone = true;
    }
    if (stageDone) {
      await jobRef.set({ stage: 'contacts', customsStageDoneAt: nowISO(), updatedAt: nowISO() }, { merge: true });
      stage = 'contacts';
    }
  }

  if (stage === 'contacts' && processed === 0) {
    const freshSnap = await jobRef.get();
    const freshJob = freshSnap.data() || job;
    let q = db.collection(C.contactSources).orderBy(FieldPath.documentId()).limit(limit);
    if (freshJob.lastContactDocId) q = q.startAfter(freshJob.lastContactDocId);
    const qs = await q.get();
    if (qs.empty) {
      await jobRef.set({ status: 'done', stage: 'done', completedAt: nowISO(), updatedAt: nowISO() }, { merge: true });
      const end = await jobRef.get();
      return { done: true, processed: 0, job: { id: end.id, ...end.data() } };
    }

    const contacts = qs.docs.map(d => ({ id: d.id, ref: d.ref, ...d.data(), _doc: d }));
    const writes = [];
    for (let i=0; i<contacts.length; i++) {
      const c = contacts[i];
      const cKey = entityMatchKey(c);
      if (!cKey) {
        writes.push({ type: 'set', ref: c.ref, data: {
          matchKey: '',
          auditMatched: false,
          auditMatchStatus: 'unmatched',
          auditBestScore: 0,
          auditUpdatedAt: nowISO()
        }});
        unmatched++;
        continue;
      }

      // Buscar TODOS los grupos aduaneros con la misma llave.
      // Una empresa puede tener varios grupos/cargas/NCM. Antes se tomaba un solo groupId
      // y los otros quedaban unmatched aunque pertenecieran al mismo contacto.
      const customsSnap = await db.collection(C.customsGroups).where('matchKey', '==', cKey).limit(1000).get();
      if (!customsSnap.empty) {
        const groups = customsSnap.docs.map(g => ({ id: g.id, ref: g.ref, ...g.data() }));
        const mergedSummary = mergeCustomsSummaries(groups.map(g => g.summary || {}));
        const syntheticGroup = {
          id: groups[0].id,
          groupIds: groups.map(g => g.id),
          importador: groups[0].importador || '',
          normalizedName: groups[0].normalizedName || '',
          matchKey: cKey,
          summary: mergedSummary
        };
        await upsertProspectFromContact({ ...c, matchKey: cKey }, syntheticGroup, 100, 'matched');
        writes.push({ type: 'set', ref: c.ref, data: {
          matchKey: cKey,
          auditMatched: true,
          auditMatchStatus: 'matched',
          auditBestScore: 100,
          auditBestCustomsName: syntheticGroup.importador || '',
          auditUpdatedAt: nowISO()
        }});
        for (const g of groups) {
          writes.push({ type: 'set', ref: g.ref, data: {
            matchKey: cKey,
            auditMatched: true,
            auditMatchStatus: 'matched',
            auditUpdatedAt: nowISO()
          }});
        }
        matched++;
        prospectWrites++;
      } else {
        await upsertProspectFromContact({ ...c, matchKey: cKey }, null, 0, 'unmatched');
        writes.push({ type: 'set', ref: c.ref, data: {
          matchKey: cKey,
          auditMatched: false,
          auditMatchStatus: 'unmatched',
          auditBestScore: 0,
          auditUpdatedAt: nowISO()
        }});
        unmatched++;
        prospectWrites++;
      }
    }
    await batchCommitWrites(writes);
    processed = qs.size;
    const lastId = qs.docs[qs.docs.length - 1].id;
    const isLast = qs.size < limit;
    await jobRef.set({
      stage: isLast ? 'done' : 'contacts',
      status: isLast ? 'done' : 'processing',
      processedContacts: FieldValue.increment(qs.size),
      matched: FieldValue.increment(matched),
      unmatched: FieldValue.increment(unmatched),
      prospectWrites: FieldValue.increment(prospectWrites),
      valid: FieldValue.increment(matched),
      lastContactDocId: lastId,
      completedAt: isLast ? nowISO() : FieldValue.delete(),
      updatedAt: nowISO()
    }, { merge: true });
  }

  const endSnap = await jobRef.get();
  const endJob = { id: endSnap.id, ...endSnap.data() };
  return { done: endJob.status === 'done', processed, matched, unmatched, indexWrites, prospectWrites, job: endJob };
}


async function adminImporterPurge(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const body = req.body || {};
  if (!body.dataBase64) return sendJson(res, { ok: false, error: 'Falta archivo base64' }, 400);
  const filename = cleanText(body.filename || 'importadores.xlsx');
  const buffer = Buffer.from(String(body.dataBase64), 'base64');
  const rows = readXlsxRows(buffer);

  const existingContactKeys = new Map();
  const existingProspectKeys = new Map();
  const existingCustomsKeys = new Map();

  const [contactSnap, prospectSnap, customsSnap] = await Promise.all([
    db.collection(C.contactSources).limit(100000).get(),
    db.collection(C.prospects).limit(100000).get(),
    db.collection(C.customsGroups).limit(100000).get()
  ]);

  for (const d of contactSnap.docs) {
    const x = { id: d.id, ...d.data() };
    const key = entityMatchKey(x);
    if (key && !existingContactKeys.has(key)) existingContactKeys.set(key, x.companyName || x.importador || x.normalizedName || d.id);
  }
  for (const d of prospectSnap.docs) {
    const x = { id: d.id, ...d.data() };
    const key = entityMatchKey(x);
    const hasUsefulContact = Boolean(x.hasContact || x.contact?.phone || x.contact?.address || x.contact?.website || x.contact?.email || x.contact?.googleMapsUrl);
    if (key && hasUsefulContact && !existingProspectKeys.has(key)) existingProspectKeys.set(key, x.companyName || x.importador || x.normalizedName || d.id);
  }
  for (const d of customsSnap.docs) {
    const x = { id: d.id, ...d.data() };
    const key = entityMatchKey(x);
    if (key && !existingCustomsKeys.has(key)) existingCustomsKeys.set(key, x.importador || x.companyName || x.normalizedName || d.id);
  }

  const seenUploadKeys = new Map();
  const nuevos = [];
  const yaExisten = [];
  const duplicadosExcel = [];
  const sinImportador = [];
  let onlyCustomsExisting = 0;

  function rowWithAudit(row, extra) {
    return { ...row, ...extra };
  }

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i] || {};
    const importador = cleanImporterName(getHeader(row, ['Importador','Empresa','Nombre','Razon Social','Razón Social','Cliente','Company','Name']));
    const normalizedName = normalizeName(importador);
    const matchKey = normalizeMatchKey(importador);
    const baseAudit = {
      PurgadorFila: i + 2,
      PurgadorImportador: importador,
      PurgadorNormalizado: normalizedName,
      PurgadorMatchKey: matchKey
    };

    if (!importador || !matchKey) {
      sinImportador.push(rowWithAudit(row, { ...baseAudit, PurgadorEstado: 'SIN_IMPORTADOR' }));
      continue;
    }

    const existingName = existingContactKeys.get(matchKey) || existingProspectKeys.get(matchKey) || '';
    if (existingName) {
      yaExisten.push(rowWithAudit(row, {
        ...baseAudit,
        PurgadorEstado: 'YA_EXISTE_CONTACTO',
        PurgadorNombreExistente: existingName,
        PurgadorFuente: existingContactKeys.has(matchKey) ? 'contactos_cargados' : 'prospectos_con_contacto'
      }));
      continue;
    }

    if (seenUploadKeys.has(matchKey)) {
      duplicadosExcel.push(rowWithAudit(row, {
        ...baseAudit,
        PurgadorEstado: 'DUPLICADO_EN_EXCEL',
        PurgadorPrimeraFila: seenUploadKeys.get(matchKey)
      }));
      continue;
    }

    seenUploadKeys.set(matchKey, i + 2);
    const customsName = existingCustomsKeys.get(matchKey) || '';
    if (customsName) onlyCustomsExisting++;
    nuevos.push(rowWithAudit(row, {
      ...baseAudit,
      PurgadorEstado: 'NUEVO_PARA_BUSCAR',
      PurgadorSoloAduanaExistente: customsName ? 'SI' : 'NO',
      PurgadorNombreAduana: customsName
    }));
  }

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(nuevos), 'NUEVOS_PARA_GOOGLE');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(yaExisten), 'YA_EXISTEN_NO_BUSCAR');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(duplicadosExcel), 'DUPLICADOS_EXCEL');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sinImportador), 'SIN_IMPORTADOR');
  const outBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  const outName = filename.replace(/\.[^.]+$/, '') + '_PURGADO.xlsx';

  sendJson(res, {
    ok: true,
    filename,
    outputFilename: outName,
    counts: {
      rows: rows.length,
      nuevosParaGoogle: nuevos.length,
      yaExistenNoBuscar: yaExisten.length,
      duplicadosEnExcel: duplicadosExcel.length,
      sinImportador: sinImportador.length,
      nuevosQueYaTenianSoloAduana: onlyCustomsExisting,
      baseContactosLeidos: contactSnap.size,
      baseProspectosLeidos: prospectSnap.size,
      baseAduanaLeida: customsSnap.size
    },
    preview: {
      nuevos: nuevos.slice(0, 50),
      yaExisten: yaExisten.slice(0, 50),
      duplicadosExcel: duplicadosExcel.slice(0, 50),
      sinImportador: sinImportador.slice(0, 50)
    },
    fileBase64: outBuffer.toString('base64'),
    note: 'Usá la hoja NUEVOS_PARA_GOOGLE para gastar Google APIs solo en importadores no encontrados en contactos/prospectos. Si figura SoloAduanaExistente=SI, existe en aduana pero no como contacto enriquecido.'
  });
}

async function filterOptions(req, res) {
  // Opciones para desplegables. Se cachean del lado del navegador y se piden solo al abrir Disponibles.
  // Lee prospectos disponibles con aduana, limitado para evitar explosión de reads.
  const snap = await db.collection(C.prospects)
    .where('commercial.status', '==', 'available')
    .where('hasCustoms', '==', true)
    .limit(10000)
    .get();
  const provinces = new Map();
  const provinceCities = {};
  const chapters = new Set();
  const origins = new Set();
  for (const d of snap.docs) {
    const p = d.data();
    const provinceRaw = cleanText(p.contact?.province || '');
    const province = canonicalArgProvince(provinceRaw);
    const city = cleanText(p.contact?.city || '');
    if (province) {
      const pn = normFilterValue(province);
      if (!provinces.has(pn)) provinces.set(pn, province);
      provinceCities[pn] = provinceCities[pn] || new Map();
      if (city) provinceCities[pn].set(normFilterValue(city), city);
    }
    for (const ch of p.customsSummary?.chapters || []) if (ch) chapters.add(String(ch));
    for (const o of p.customsSummary?.origins || []) if (o) origins.add(cleanText(o));
  }
  const provinceCitiesOut = {};
  for (const [pn, m] of Object.entries(provinceCities)) {
    provinceCitiesOut[pn] = Array.from(m.values()).sort((a,b)=>a.localeCompare(b,'es'));
  }
  sendJson(res, {
    ok: true,
    count: snap.size,
    lowReads: true,
    provinces: Array.from(provinces.values()).sort((a,b)=>a.localeCompare(b,'es')),
    provinceCities: provinceCitiesOut,
    chapters: Array.from(chapters).sort((a,b)=>String(a).localeCompare(String(b),'es')),
    origins: Array.from(origins).sort((a,b)=>String(a).localeCompare(String(b),'es')),
    fobRanges: [
      { value: '', label: 'Todos los FOB' },
      { value: '0-5000', label: 'Hasta 5.000' },
      { value: '5000-25000', label: '5.000 a 25.000' },
      { value: '25000-50000', label: '25.000 a 50.000' },
      { value: '50000-75000', label: '50.000 a 75.000' },
      { value: '100000+', label: '+100.000' }
    ]
  });
}


async function getQueryCount(ref, fallbackLimit = 5000) {
  try {
    const agg = await ref.count().get();
    return Number(agg.data().count || 0);
  } catch (e) {
    const snap = await ref.limit(fallbackLimit).get();
    return snap.size;
  }
}
function simpleStatusProspectQuery(filters = {}) {
  // Consulta segura: usa como máximo un filtro de estado para no pedir índices compuestos.
  // Provincia/Ciudad/NCM/Origen/FOB/Descripción se filtran localmente sobre una ventana controlada.
  const status = cleanText(filters.status || filters.statusFilter || 'available');
  let ref = db.collection(C.prospects);
  if (status === 'available' || status === 'disponibles') ref = ref.where('commercial.status', '==', 'available');
  else if (status === 'assigned' || status === 'asignados') ref = ref.where('commercial.status', 'in', ['assigned','in_progress']);
  else if (status === 'completed' || status === 'gestionados') ref = ref.where('commercial.status', '==', 'completed');
  // status all/todos no filtra por estado para que admin pueda ver disponibles y asignados juntos.
  return ref;
}
function statusFilteredProspectQuery(filters = {}) {
  // Mantengo el nombre para compatibilidad, pero ya no combina índices compuestos.
  return simpleStatusProspectQuery(filters || {});
}
function availableBaseQuery(filters = {}) {
  return simpleStatusProspectQuery({ ...(filters || {}), status: 'available' });
}

function parseZoneList(v) {
  if (Array.isArray(v)) return v.map(cleanText).filter(Boolean);
  return String(v || '')
    .split(/[,;\n]/)
    .map(cleanText)
    .filter(Boolean);
}
function zoneListNorm(list) {
  return Array.from(new Set((list || []).map(x => normFilterValue(x)).filter(Boolean)));
}
async function getSellerSettings(sellerId) {
  const id = safeId(sellerId || '');
  if (!id) return null;
  const d = await db.collection(C.users).doc(id).get();
  if (!d.exists) return null;
  return { id: d.id, ...(d.data() || {}) };
}
function prospectMatchesSellerZones(p, seller) {
  if (!seller || seller.role === 'admin') return true;
  const allowedCities = zoneListNorm(seller.allowedCitiesNorm || seller.allowedCities || []);
  const allowedProvinces = Array.from(new Set([
    ...zoneListNorm(seller.allowedProvincesNorm || []),
    ...zoneListNormProvince(seller.allowedProvinces || [])
  ].filter(Boolean)));
  // Vendedor sin zona asignada queda bloqueado para pedir más.
  if (!allowedCities.length && !allowedProvinces.length) return false;
  const city = normFilterValue(p.contact?.city || '');
  const province = provinceFilterKey(p.contact?.province || '');
  if (allowedCities.length) return allowedCities.includes(city);
  return allowedProvinces.includes(province);
}
function sellerZoneText(seller) {
  const ps = (seller?.allowedProvinces || []).join(', ');
  const cs = (seller?.allowedCities || []).join(', ');
  if (!ps && !cs) return 'Sin zona fija';
  return (ps ? 'Prov: ' + ps : '') + (ps && cs ? ' | ' : '') + (cs ? 'Ciudades: ' + cs : '');
}

async function listSellers(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const snap = await db.collection(C.users).limit(500).get();
  const sellers = snap.docs.map(d => { const x = { id: d.id, ...d.data() }; x.hasPassword = Boolean(x.passwordHash); delete x.passwordHash; return x; })
    .filter(x => x.active !== false)
    .sort((a,b) => String(a.name || a.id).localeCompare(String(b.name || b.id), 'es'));
  // Si no hay vendedores cargados todavía, mostramos admin como opción mínima.
  if (!sellers.find(s => s.id === 'admin')) sellers.unshift({ id: 'admin', name: 'admin', role: 'admin', active: true, systemFallback: true });
  sendJson(res, { ok: true, sellers });
}
async function saveSeller(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const name = cleanText(req.body.name);
  if (!name) return sendJson(res, { ok: false, error: 'Falta nombre del vendedor.' }, 400);
  const id = safeId(req.body.id || name);
  const role = ['admin','seller'].includes(cleanText(req.body.role)) ? cleanText(req.body.role) : 'seller';
  const allowedProvinces = parseZoneList(req.body.allowedProvinces || req.body.provinces || '');
  const allowedCities = parseZoneList(req.body.allowedCities || req.body.cities || '');
  const ref = db.collection(C.users).doc(id);
  const old = await ref.get();
  const payload = {
    id,
    name,
    role,
    active: req.body.active === false ? false : true,
    allowedProvinces,
    allowedProvincesNorm: zoneListNormProvince(allowedProvinces),
    allowedCities,
    allowedCitiesNorm: zoneListNorm(allowedCities),
    createdAt: old.exists ? (old.data().createdAt || nowISO()) : nowISO(),
    updatedAt: nowISO(),
    updatedBy: currentUser(req).name
  };
  const pass = cleanText(req.body.password || '');
  if (pass) {
    if (pass.length < 4) return sendJson(res, { ok: false, error: 'La clave debe tener al menos 4 caracteres.' }, 400);
    payload.passwordHash = passwordHash(pass);
    payload.passwordUpdatedAt = nowISO();
  }
  await ref.set(payload, { merge: true });
  sendJson(res, { ok: true, seller: { id, name, role, active: payload.active, allowedProvinces, allowedCities, passwordSet: Boolean(pass) } });
}
async function deleteSeller(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const id = cleanText(req.body.id || req.query.id);
  if (!id) return sendJson(res, { ok: false, error: 'Falta id vendedor.' }, 400);
  await db.collection(C.users).doc(id).set({ active: false, deletedAt: nowISO(), deletedBy: currentUser(req).name }, { merge: true });
  sendJson(res, { ok: true, id, deactivated: true });
}

async function authLogin(req, res) {
  const usernameRaw = cleanText(req.body.user || req.query.user || '');
  const pass = cleanText(req.body.password || req.headers['x-scb-pass'] || '');
  if (!usernameRaw) return sendJson(res, { ok: false, error: 'Falta usuario.' }, 400);
  const username = safeId(usernameRaw);

  // Admin entra con la clave general BASIC_PASS desde el formulario, sin popup Basic del navegador.
  if (username === 'admin' || (BASIC_USER && usernameRaw === BASIC_USER)) {
    if (BASIC_PASS && pass !== BASIC_PASS) return sendJson(res, { ok: false, error: 'Clave admin incorrecta.' }, 403);
    return sendJson(res, { ok: true, user: { id: 'admin', name: 'admin', role: 'admin' }, note: 'Admin autenticado.' });
  }

  const id = username;
  const d = await db.collection(C.users).doc(id).get();
  if (!d.exists || d.data().active === false) return sendJson(res, { ok: false, error: 'Usuario vendedor no existe o está inactivo.' }, 403);
  const data = d.data();
  if (!data.passwordHash) return sendJson(res, { ok: false, error: 'Este vendedor no tiene clave cargada. Admin debe editarlo en Vendedores.' }, 403);
  if (!verifyPassword(pass, data.passwordHash)) return sendJson(res, { ok: false, error: 'Clave incorrecta.' }, 403);
  return sendJson(res, { ok: true, user: { id: d.id, name: data.name || usernameRaw, role: data.role || 'seller' } });
}
async function enforceAppAuth(req, res) {
  const u = currentUser(req);
  const pass = cleanText(req.headers['x-scb-pass'] || req.query.pass || (req.body && req.body.password) || '');
  if (u.name === 'admin' || u.id === 'admin') {
    if (BASIC_PASS && pass !== BASIC_PASS) {
      sendJson(res, { ok: false, error: 'Admin no autorizado: clave incorrecta.' }, 403); return false;
    }
    return true;
  }
  const d = await db.collection(C.users).doc(u.id).get();
  if (!d.exists || d.data().active === false) {
    sendJson(res, { ok: false, error: 'Usuario no autorizado. Crealo en Vendedores.' }, 403); return false;
  }
  const data = d.data();
  if (!data.passwordHash) {
    sendJson(res, { ok: false, error: 'Este vendedor no tiene clave cargada. Admin debe editarlo en Vendedores.' }, 403); return false;
  }
  if (!verifyPassword(pass, data.passwordHash)) {
    sendJson(res, { ok: false, error: 'Clave incorrecta.' }, 403); return false;
  }
  return true;
}
async function availableCount(req, res) {
  const q = req.query || {};
  const cap = Math.min(Number(q.cap || 8000), 12000);
  let snap;
  let queryFallback = false;
  try {
    snap = await simpleStatusProspectQuery(q).limit(cap).get();
  } catch (e) {
    console.error('availableCount simple status query failed, fallback full local scan', e.message);
    queryFallback = true;
    snap = await db.collection(C.prospects).limit(cap).get();
  }
  const arrRaw = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(p => {
    const st = cleanText(q.status || q.statusFilter || 'available');
    if (!p.hasCustoms) return false;
    if ((st === 'available' || st === 'disponibles') && p.commercial?.status !== 'available') return false;
    if ((st === 'assigned' || st === 'asignados') && !['assigned','in_progress'].includes(p.commercial?.status)) return false;
    if ((st === 'completed' || st === 'gestionados') && p.commercial?.status !== 'completed') return false;
    return applyProspectFiltersLocal(p, q);
  });
  const arr = dedupeProspectRows(arrRaw);
  sendJson(res, { ok: true, count: arr.length, rawCount: arrRaw.length, duplicatesHidden: Math.max(0, arrRaw.length - arr.length), exact: snap.size < cap, limited: snap.size >= cap, scanned: snap.size, lowReads: false, queryFallback, note: 'Conteo seguro por ventana local: evita índices compuestos de Firestore. Deduplica empresas por matchKey.' });
}
async function resolveSellerForAssign(sellerId, sellerName) {
  let id = cleanText(sellerId || '');
  let name = cleanText(sellerName || '');
  if (id) {
    const d = await db.collection(C.users).doc(id).get();
    if (d.exists) {
      const u = d.data();
      if (u.active === false) throw new Error('Vendedor inactivo.');
      return { id: d.id, name: u.name || d.id };
    }
  }
  if (name) return { id: safeId(name), name };
  throw new Error('Falta vendedor.');
}
async function assignProspectRefs(refs, seller, assignedBy) {
  let assigned = 0, skipped = 0, duplicateSkipped = 0;
  const writes = [];
  const assignedKeysInThisRun = new Set();

  for (const ref of refs) {
    const d = await ref.get();
    if (!d.exists) { skipped++; continue; }
    const p = { id: d.id, ...d.data() };
    if (p.commercial?.status !== 'available') { skipped++; continue; }

    const key = prospectDedupeKey(p);
    if (key && assignedKeysInThisRun.has(key)) { skipped++; duplicateSkipped++; continue; }

    if (await hasNonAvailableDuplicateForProspect(p, d.id)) {
      skipped++;
      duplicateSkipped++;
      continue;
    }

    writes.push({ type: 'set', ref, data: { commercial: { ...(p.commercial || {}), status: 'assigned', assignedTo: seller.id, assignedToName: seller.name, assignedAt: nowISO(), assignedBy: assignedBy.name }, updatedAt: nowISO() }, options: { merge: true } });
    if (key) assignedKeysInThisRun.add(key);
    assigned++;
  }
  await batchCommitWrites(writes);
  return { assigned, skipped, duplicateSkipped };
}
async function adminAssignSelected(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const ids = Array.isArray(req.body.ids) ? req.body.ids.map(cleanText).filter(Boolean) : [];
  if (!ids.length) return sendJson(res, { ok: false, error: 'No seleccionaste prospectos.' }, 400);
  if (ids.length > 500) return sendJson(res, { ok: false, error: 'Máximo 500 prospectos por asignación.' }, 400);
  const seller = await resolveSellerForAssign(req.body.sellerId, req.body.sellerName);
  const refs = ids.map(id => db.collection(C.prospects).doc(id));
  const result = await assignProspectRefs(refs, seller, currentUser(req));
  sendJson(res, { ok: true, seller, ...result });
}
async function adminAssignFiltered(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin.' }, 403);
  const confirm = cleanText(req.body.confirm || '');
  if (confirm !== 'ASIGNAR') return sendJson(res, { ok: false, error: 'Confirmación requerida: ASIGNAR' }, 400);
  const seller = await resolveSellerForAssign(req.body.sellerId, req.body.sellerName);
  const filters = req.body.filters || {};
  const maxAssign = Math.min(Number(req.body.limit || 200), 500);
  const scanLimit = Math.min(Math.max(maxAssign * 20, 2000), 12000);
  let snap;
  try {
    snap = await availableBaseQuery(filters).limit(scanLimit).get();
  } catch (e) {
    console.error('assignFiltered safe query failed, fallback full local scan', e.message);
    snap = await db.collection(C.prospects).limit(scanLimit).get();
  }
  const sortedCandidates = sortAvailableProspects(snap.docs.map(d => ({ id: d.id, ref: d.ref, ...d.data() })).filter(p => {
    if (!p.hasCustoms) return false;
    if (p.commercial?.status !== 'available') return false;
    return applyProspectFiltersLocal(p, filters);
  }), filters.order || 'mix');
  const candidates = dedupeProspectRows(sortedCandidates).slice(0, maxAssign).map(p => p.ref);
  const result = await assignProspectRefs(candidates, seller, currentUser(req));
  sendJson(res, { ok: true, seller, requestedLimit: maxAssign, candidates: candidates.length, ...result });
}



function stableHashInt(v) {
  const s = String(v || '');
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h >>> 0);
}
function availableFobBucket(p) {
  const f = Number(p.customsSummary?.totalFob || 0);
  if (f <= 5000) return 'A_0_5000';
  if (f <= 25000) return 'B_5000_25000';
  if (f <= 50000) return 'C_25000_50000';
  if (f <= 75000) return 'D_50000_75000';
  if (f <= 100000) return 'E_75000_100000';
  return 'F_100000_PLUS';
}
function availableAlphaBucket(p) {
  const base = normalizeMatchKey(p.companyName || p.normalizedName || p.matchKey || p.id || '');
  return (base || '#').slice(0, 1);
}
function sortAvailableProspects(rows, order = 'mix') {
  const mode = cleanText(order || 'mix');
  const arr = [...(rows || [])];
  if (mode === 'alpha') {
    return arr.sort((a,b)=>String(a.companyName||'').localeCompare(String(b.companyName||''),'es'));
  }
  if (mode === 'fob_desc') {
    return arr.sort((a,b)=>Number(b.customsSummary?.totalFob||0)-Number(a.customsSummary?.totalFob||0));
  }
  if (mode === 'fob_asc') {
    return arr.sort((a,b)=>Number(a.customsSummary?.totalFob||0)-Number(b.customsSummary?.totalFob||0));
  }
  // Mix default: intercala letra inicial + rango FOB para no entregar todos A/M o un solo rango de FOB juntos.
  const groups = new Map();
  for (const p of arr) {
    const key = availableFobBucket(p) + '|' + availableAlphaBucket(p);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(p);
  }
  for (const [k, list] of groups.entries()) {
    list.sort((a,b)=>stableHashInt(a.id || a.companyName) - stableHashInt(b.id || b.companyName));
  }
  let keys = Array.from(groups.keys()).sort((a,b)=>stableHashInt(a)-stableHashInt(b));
  const out = [];
  while (keys.length) {
    const nextKeys = [];
    for (const k of keys) {
      const list = groups.get(k) || [];
      if (list.length) out.push(list.shift());
      if (list.length) nextKeys.push(k);
    }
    keys = nextKeys;
  }
  return out;
}


function prospectDedupeKey(p) {
  const key = cleanText(p?.matchKey || entityMatchKey(p) || normalizeMatchKey(p?.companyName || p?.normalizedName || p?.id || ''));
  return key || cleanText(p?.id || '');
}
function dedupeProspectRows(rows) {
  // Evita que la misma empresa aparezca dos veces en Disponibles o en asignaciones masivas.
  // Se deduplica por matchKey normalizado; no borra nada de Firestore.
  const byKey = new Map();
  for (const p of rows || []) {
    const key = prospectDedupeKey(p);
    if (!key) continue;
    const prev = byKey.get(key);
    if (!prev) {
      byKey.set(key, p);
      continue;
    }
    // Si hay duplicados, conservar el más completo / más valioso para mostrar.
    const prevScore = (prev.hasContact ? 10 : 0) + (prev.hasCustoms ? 10 : 0) + Number(prev.customsSummary?.totalFob || 0) / 100000000;
    const curScore = (p.hasContact ? 10 : 0) + (p.hasCustoms ? 10 : 0) + Number(p.customsSummary?.totalFob || 0) / 100000000;
    if (curScore > prevScore) byKey.set(key, p);
  }
  return Array.from(byKey.values());
}
async function hasNonAvailableDuplicateForProspect(p, selfId = '') {
  // Protección de asignación: si otra ficha de la misma empresa ya está asignada/gestionada,
  // no asignamos un duplicado disponible a otro vendedor.
  const key = prospectDedupeKey(p);
  if (!key) return false;
  const snap = await db.collection(C.prospects).where('matchKey', '==', key).limit(50).get();
  for (const d of snap.docs) {
    if (selfId && d.id === selfId) continue;
    const x = d.data() || {};
    const st = cleanText(x.commercial?.status || 'available');
    if (st && st !== 'available') return true;
  }
  return false;
}

function sellerMineStatusMatch(p, status) {
  status = cleanText(status || 'all');
  const c = p.commercial || {};
  const today = new Date().toISOString().slice(0,10);
  const result = normalizeName(c.lastResult || '').toLowerCase();
  const commercialStatus = cleanText(c.status || '').toLowerCase();
  const hasGestion = Boolean(c.lastNoteAt && c.lastResult);
  const due = cleanText(c.taskDueDate || c.nextActionDate || '');
  const isClosed = ['completed','discarded'].includes(commercialStatus) || ['descartado','no_interesado','dato_incorrecto'].some(x => result.includes(x));
  const isFollow = Boolean(c.followUpOpen || c.taskOpen || due);
  if (!status || status === 'all' || status === 'todos') return true;
  if (status === 'sin_gestion') return !hasGestion;
  if (status === 'gestionados') return hasGestion;
  if (status === 'vencidos') return !isClosed && due && due < today;
  if (status === 'hoy') return !isClosed && due && due === today;
  if (status === 'proximas') return !isClosed && due && due > today;
  if (status === 'seguimiento') return !isClosed && isFollow;
  if (status === 'interesados') return result.includes('interesado') || result.includes('contactado');
  if (status === 'no_responde') return result.includes('no_responde') || result.includes('no responde');
  if (status === 'cotizacion') return result.includes('cotizacion') || result.includes('cotización') || result.includes('cotizado');
  if (status === 'descartados') return isClosed;
  return true;
}
function sellerMineSearchMatch(p, term) {
  const q = normalizeName(term || '').toLowerCase().replace(/\s+/g,'');
  if (!q) return true;
  const c = p.contact || {};
  const cs = p.customsSummary || {};
  const raw = [
    p.companyName, p.normalizedName, p.matchKey,
    c.city, c.province, c.phone, c.email, c.website,
    (cs.chapters || []).join(' '), (cs.positions || []).join(' '), (cs.origins || []).join(' '), (cs.mainDescriptions || []).join(' '),
    p.commercial?.lastResult, p.commercial?.nextActionDate, p.commercial?.taskDueDate
  ].filter(Boolean).join(' ');
  const hay = normalizeName(raw).toLowerCase().replace(/\s+/g,'');
  return hay.includes(q);
}
function mineFilterCounts(rows) {
  const counts = { total: rows.length, sin_gestion:0, vencidos:0, hoy:0, proximas:0, seguimiento:0, interesados:0, no_responde:0, cotizacion:0, descartados:0, gestionados:0 };
  for (const p of rows) {
    for (const k of Object.keys(counts)) {
      if (k !== 'total' && sellerMineStatusMatch(p, k)) counts[k]++;
    }
  }
  return counts;
}

async function listProspects(req, res) {
  const u = currentUser(req);
  const q = req.query || {};
  const mode = cleanText(q.mode || 'available');
  const limit = mode === 'mine' ? Math.min(Math.max(Number(q.limit || 500), 1), 500) : Math.min(Number(q.limit || 50), 500);
  const scanLimit = mode === 'available' ? Math.min(Math.max(Number(q.scan || 8000), limit), 12000) : Math.max(limit, 20);
  let ref = db.collection(C.prospects);
  if (mode === 'mine') ref = ref.where('commercial.assignedTo', '==', u.id);
  else if (mode === 'available') ref = simpleStatusProspectQuery(q);
  else if (mode === 'all' && !isAdmin(req)) ref = ref.where('commercial.assignedTo', '==', u.id);
  else if (mode === 'unmatched') ref = ref.where('match.matchStatus', '==', 'unmatched');
  let snap;
  let queryFallback = false;
  try {
    snap = await ref.limit(scanLimit).get();
  } catch (e) {
    console.error('listProspects safe query failed, fallback full local scan', e.message);
    queryFallback = true;
    const fallbackLimit = mode === 'available' ? 12000 : Math.min(Math.max(scanLimit * 2, 200), 2000);
    snap = await db.collection(C.prospects).limit(fallbackLimit).get();
  }
  let data = snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(p => {
    if (mode === 'mine' && p.commercial?.assignedTo !== u.id) return false;
    if (mode === 'available') {
      const st = cleanText(q.status || q.statusFilter || 'available');
      if (!p.hasCustoms) return false;
      if ((st === 'available' || st === 'disponibles') && p.commercial?.status !== 'available') return false;
      if ((st === 'assigned' || st === 'asignados') && !['assigned','in_progress'].includes(p.commercial?.status)) return false;
      if ((st === 'completed' || st === 'gestionados') && p.commercial?.status !== 'completed') return false;
    }
    if (mode === 'all' && !isAdmin(req) && p.commercial?.assignedTo !== u.id) return false;
    if (mode === 'unmatched' && p.match?.matchStatus !== 'unmatched') return false;
    return applyProspectFiltersLocal(p, q);
  });
  let mineCounts = null;
  if (mode === 'available') {
    const beforeDedupe = data.length;
    data = dedupeProspectRows(sortAvailableProspects(data, q.order || 'mix'));
    var availableDuplicatesHidden = Math.max(0, beforeDedupe - data.length);
  }
  if (mode === 'mine') {
    mineCounts = mineFilterCounts(data);
    data = data.filter(p => sellerMineStatusMatch(p, q.mineStatus || 'all') && sellerMineSearchMatch(p, q.mineQ || q.q || ''));
    data.sort((a,b) => {
      const ap = (!a.commercial?.lastNoteAt || !a.commercial?.lastResult) ? 0 : 1;
      const bp = (!b.commercial?.lastNoteAt || !b.commercial?.lastResult) ? 0 : 1;
      if (ap !== bp) return ap - bp;
      const ad = a.commercial?.nextActionDate || '9999-12-31';
      const bd = b.commercial?.nextActionDate || '9999-12-31';
      return String(ad).localeCompare(String(bd));
    });
  }
  data = data.slice(0, limit);
  sendJson(res, { ok: true, user: u, prospects: data, mineCounts, lowReads: false, queryFallback, scanned: snap.size, limit, duplicatesHidden: mode === 'available' ? (availableDuplicatesHidden || 0) : 0, note: mode === 'available' ? 'Disponibles usa consulta segura sin índices compuestos; mezcla por letras + FOB después de filtrar y deduplica empresas por matchKey.' : '' });
}
async function takeBatch(req, res) {
  const u = currentUser(req);
  const batchSize = Math.min(Number(req.body.batchSize || req.query.batchSize || DEFAULT_BATCH_SIZE), 25);
  const myOpenSnap = await db.collection(C.prospects)
    .where('commercial.assignedTo', '==', u.id)
    .where('commercial.status', 'in', ['assigned','in_progress'])
    .limit(500).get();
  const pending = myOpenSnap.docs.map(d => ({ id: d.id, ...d.data() })).filter(p => !p.commercial?.lastNoteAt || !p.commercial?.lastResult);
  if (pending.length > 0) {
    return sendJson(res, { ok: false, error: `Tenés ${pending.length} prospectos pendientes sin nota/resultado. Completalos antes de tomar ${batchSize} más.`, pending: pending.map(p => ({ id: p.id, companyName: p.companyName })) }, 409);
  }
  const sellerSettings = await getSellerSettings(u.id);
  const sellerProvinceZones = zoneListNormProvince(sellerSettings?.allowedProvinces || []);
  const sellerCityZones = zoneListNorm(sellerSettings?.allowedCitiesNorm || sellerSettings?.allowedCities || []);
  const zoneApplied = sellerSettings && sellerSettings.role !== 'admin' && (sellerCityZones.length || sellerProvinceZones.length);
  if (!zoneApplied) {
    return sendJson(res, { ok: false, error: 'Tu usuario no tiene provincias/ciudades asignadas. Pedile al admin que te asigne una zona antes de pedir más prospectos.' }, 403);
  }
  const filters = { ...(req.body.filters || req.query || {}) };
  const scanLimit = Math.min(Math.max(Number(req.body.scan || req.query.scan || 10000), batchSize * 30), 15000);
  let snap;
  try {
    snap = await db.collection(C.prospects).where('commercial.status', '==', 'available').limit(scanLimit).get();
  } catch (e) {
    console.error('takeBatch safe query failed, fallback full scan', e.message);
    snap = await db.collection(C.prospects).limit(scanLimit).get();
  }
  let candidates = snap.docs.map(d => ({ id: d.id, data: d.data(), ref: d.ref })).filter(x => {
    const p = x.data || {};
    if (!p.hasCustoms) return false;
    if (p.commercial?.status !== 'available') return false;
    if (!applyProspectFiltersLocal(p, filters)) return false;
    if (!prospectMatchesSellerZones(p, sellerSettings)) return false;
    return true;
  });
  candidates = dedupeProspectRows(sortAvailableProspects(candidates.map(x => ({ ...x.data, id: x.id, _ref: x.ref })), filters.order || 'mix'))
    .slice(0, batchSize)
    .map(p => ({ id: p.id, ref: p._ref, data: p }));

  const assigned = [];
  const assignedKeysInThisRun = new Set();
  let duplicateSkipped = 0;
  for (const c of candidates) {
    const key = prospectDedupeKey(c.data || {});
    if (key && assignedKeysInThisRun.has(key)) { duplicateSkipped++; continue; }
    if (await hasNonAvailableDuplicateForProspect(c.data || {}, c.id)) { duplicateSkipped++; continue; }

    await db.runTransaction(async tx => {
      const doc = await tx.get(c.ref);
      const p = doc.data();
      if (!p || p.commercial?.status !== 'available') return;
      tx.set(c.ref, { commercial: { ...(p.commercial || {}), status: 'assigned', assignedTo: u.id, assignedToName: u.name, assignedAt: nowISO(), assignedBy: 'self_request' }, updatedAt: nowISO() }, { merge: true });
      if (key) assignedKeysInThisRun.add(key);
      assigned.push({ id: c.id, companyName: p.companyName, city: p.contact?.city || '', province: p.contact?.province || '' });
    });
  }
  sendJson(res, { ok: true, assignedCount: assigned.length, duplicateSkipped, assigned, scanned: snap.size, zoneApplied: Boolean(zoneApplied), sellerZone: sellerZoneText(sellerSettings || {}), message: `Se buscaron prospectos dentro de tu zona: ${sellerZoneText(sellerSettings)}` });
}

function taskLabel(v) {
  const map = {
    volver_llamar: 'Volver a llamar',
    mandar_email: 'Mandar email',
    enviar_whatsapp: 'Enviar WhatsApp',
    enviar_cotizacion: 'Enviar cotización',
    pedir_datos: 'Pedir datos',
    seguimiento_general: 'Seguimiento general'
  };
  return map[v] || v || '';
}
function defaultTaskTypeForResult(result) {
  if (result === 'no_responde' || result === 'llamar_luego') return 'volver_llamar';
  if (result === 'pidio_cotizacion') return 'enviar_cotizacion';
  if (result === 'interesado' || result === 'contactado') return 'seguimiento_general';
  return '';
}
function isClosedResult(result) {
  return ['descartado','dato_incorrecto','no_interesado'].includes(result);
}
function todayYMD() { return new Date().toISOString().slice(0,10); }
function addDaysYMD(days) { const d = new Date(); d.setDate(d.getDate() + Number(days||0)); return d.toISOString().slice(0,10); }
function taskStatusByDue(dueDate, status) {
  if (status === 'completed') return 'completed';
  if (!dueDate) return 'open';
  const t = todayYMD();
  if (dueDate < t) return 'overdue';
  if (dueDate === t) return 'today';
  return 'upcoming';
}
async function upsertActiveTask({ prospectId, prospect, user, taskType, dueDate, note, sourceResult }) {
  if (!prospectId || !taskType || !dueDate) return null;
  const now = nowISO();
  const task = {
    prospectId,
    companyName: prospect.companyName || prospect.importador || '',
    assignedTo: prospect.commercial?.assignedTo || user.id,
    assignedToName: prospect.commercial?.assignedToName || user.name,
    type: taskType,
    typeLabel: taskLabel(taskType),
    dueDate,
    note: note || '',
    sourceResult: sourceResult || '',
    status: 'open',
    completedAt: null,
    completedBy: null,
    contact: prospect.contact || {},
    customsSummary: prospect.customsSummary || {},
    updatedAt: now,
    createdAt: now
  };
  const ref = db.collection(C.tasks).doc(prospectId);
  const old = await ref.get();
  if (old.exists && old.data()?.createdAt) task.createdAt = old.data().createdAt;
  await ref.set(task, { merge: true });
  return task;
}
async function closeActiveTask(prospectId, user, reason) {
  if (!prospectId) return;
  const ref = db.collection(C.tasks).doc(prospectId);
  const d = await ref.get();
  if (!d.exists) return;
  await ref.set({ status: 'completed', completedAt: nowISO(), completedBy: user.id, completedByName: user.name, closeReason: reason || 'closed', updatedAt: nowISO() }, { merge: true });
}
async function listTasks(req, res) {
  const u = currentUser(req);
  const q = req.query || {};
  const mode = cleanText(q.mode || 'open');
  const sellerId = cleanText(q.sellerId || u.id);
  const limit = Math.min(Number(q.limit || 100), 200);
  let ref = db.collection(C.tasks);
  if (isAdmin(req) && sellerId && sellerId !== 'all') ref = ref.where('assignedTo', '==', sellerId);
  else if (!isAdmin(req)) ref = ref.where('assignedTo', '==', u.id);
  else if (!sellerId || sellerId === 'all') ref = ref.limit(500);
  const snap = await ref.limit(500).get();
  const today = todayYMD();
  let rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  rows = rows.filter(t => {
    const st = t.status || 'open';
    const due = String(t.dueDate || '9999-12-31');
    if (mode === 'completed') return st === 'completed';
    if (mode === 'overdue') return st !== 'completed' && due < today;
    if (mode === 'today') return st !== 'completed' && due === today;
    if (mode === 'upcoming') return st !== 'completed' && due > today;
    if (mode === 'open') return st !== 'completed';
    return true;
  });
  const search = cleanText(q.q || '').toLowerCase();
  if (search) rows = rows.filter(t => JSON.stringify([t.companyName, t.typeLabel, t.note, t.contact?.city, t.contact?.province]).toLowerCase().includes(search));
  rows.sort((a,b) => {
    const aw = taskStatusByDue(a.dueDate, a.status), bw = taskStatusByDue(b.dueDate, b.status);
    const rank = { overdue:0, today:1, open:2, upcoming:3, completed:4 };
    const ar = rank[aw] ?? 9, br = rank[bw] ?? 9;
    if (ar !== br) return ar - br;
    return String(a.dueDate||'9999-12-31').localeCompare(String(b.dueDate||'9999-12-31'));
  });
  const counts = { open:0, overdue:0, today:0, upcoming:0, completed:0 };
  for (const t of snap.docs.map(d=>d.data())) counts[taskStatusByDue(t.dueDate, t.status)] = (counts[taskStatusByDue(t.dueDate, t.status)] || 0) + 1;
  sendJson(res, { ok: true, tasks: rows.slice(0, limit), counts, today, limit });
}
async function completeTask(req, res) {
  const u = currentUser(req);
  const id = cleanText(req.body.id || req.body.prospectId || req.query.id);
  const note = cleanText(req.body.note || 'Tarea completada');
  if (!id) return sendJson(res, { ok:false, error:'Falta tarea/prospecto' }, 400);
  const ref = db.collection(C.tasks).doc(id);
  const d = await ref.get();
  if (!d.exists) return sendJson(res, { ok:false, error:'Tarea no encontrada' }, 404);
  const t = d.data();
  if (!isAdmin(req) && t.assignedTo !== u.id) return sendJson(res, { ok:false, error:'La tarea pertenece a otro vendedor' }, 403);
  await ref.set({ status:'completed', completedAt: nowISO(), completedBy: u.id, completedByName: u.name, updatedAt: nowISO() }, { merge:true });
  await db.collection(C.notes).add({ prospectId: t.prospectId || id, userId:u.id, userName:u.name, result:'tarea_completada', note, nextActionDate:'', taskType:t.type || '', taskCompleted:true, createdAt: nowISO() });
  await db.collection(C.prospects).doc(t.prospectId || id).set({ commercial: { taskOpen:false, taskType:null, taskDueDate:null, lastNoteAt: nowISO(), lastResult:'tarea_completada' }, updatedAt: nowISO() }, { merge:true });
  sendJson(res, { ok:true });
}
async function reprogramTask(req, res) {
  const u = currentUser(req);
  const id = cleanText(req.body.id || req.body.prospectId || req.query.id);
  const days = Number(req.body.days || req.query.days || 0);
  const explicitDate = cleanText(req.body.dueDate || req.query.dueDate || '');
  const dueDate = explicitDate || addDaysYMD(days || 0);
  if (!id || !dueDate) return sendJson(res, { ok:false, error:'Falta tarea/prospecto o fecha' }, 400);
  const ref = db.collection(C.tasks).doc(id);
  const d = await ref.get();
  if (!d.exists) return sendJson(res, { ok:false, error:'Tarea no encontrada' }, 404);
  const t = d.data();
  if (!isAdmin(req) && t.assignedTo !== u.id) return sendJson(res, { ok:false, error:'La tarea pertenece a otro vendedor' }, 403);
  const note = cleanText(req.body.note || `Reprogramado para ${dueDate}`);
  await ref.set({ dueDate, status:'open', note: note || t.note || '', updatedAt: nowISO() }, { merge:true });
  await db.collection(C.notes).add({ prospectId: t.prospectId || id, userId:u.id, userName:u.name, result:'tarea_reprogramada', note, nextActionDate: dueDate, taskType:t.type || '', createdAt: nowISO() });
  await db.collection(C.prospects).doc(t.prospectId || id).set({ commercial: { taskOpen:true, taskType:t.type || '', taskDueDate:dueDate, nextActionDate:dueDate, followUpOpen:true }, updatedAt: nowISO() }, { merge:true });
  sendJson(res, { ok:true, dueDate });
}

async function saveNote(req, res) {
  const u = currentUser(req);
  const prospectId = cleanText(req.params?.id || req.query.id || req.body.prospectId);
  if (!prospectId) return sendJson(res, { ok: false, error: 'Falta prospectId' }, 400);
  const result = cleanText(req.body.result);
  const note = cleanText(req.body.note);
  const nextActionDate = cleanText(req.body.nextActionDate);
  let taskType = cleanText(req.body.taskType || '');
  if (!taskType) taskType = defaultTaskTypeForResult(result);
  if (!result || !note) return sendJson(res, { ok: false, error: 'Tenés que cargar resultado y nota.' }, 400);
  const followUpResults = ['no_responde', 'llamar_luego'];
  if (followUpResults.includes(result) && !nextActionDate) {
    return sendJson(res, { ok: false, error: 'Para No responde / Llamar luego cargá una fecha de próxima acción.' }, 400);
  }
  const statusMap = {
    'interesado': 'completed', 'pidio_cotizacion': 'completed', 'descartado': 'completed', 'dato_incorrecto': 'completed',
    'no_responde': 'in_progress', 'contactado': 'in_progress', 'llamar_luego': 'in_progress'
  };
  const newStatus = statusMap[result] || 'in_progress';
  const prospectRef = db.collection(C.prospects).doc(prospectId);
  const pdoc = await prospectRef.get();
  if (!pdoc.exists) return sendJson(res, { ok: false, error: 'Prospecto no encontrado' }, 404);
  const p = pdoc.data();
  if (!isAdmin(req) && p.commercial?.assignedTo && p.commercial.assignedTo !== u.id) {
    return sendJson(res, { ok: false, error: 'Este prospecto está asignado a otro vendedor.' }, 403);
  }
  const isFollowUp = ['no_responde','llamar_luego','contactado','interesado','pidio_cotizacion'].includes(result) && !isClosedResult(result);
  await db.collection(C.notes).add({ prospectId, userId: u.id, userName: u.name, result, note, nextActionDate, taskType, taskTypeLabel: taskLabel(taskType), isFollowUp, createdAt: nowISO() });
  let task = null;
  if (isClosedResult(result) || ['completed','discarded'].includes(newStatus)) {
    await closeActiveTask(prospectId, u, result);
  } else if (taskType && nextActionDate) {
    task = await upsertActiveTask({ prospectId, prospect: p, user: u, taskType, dueDate: nextActionDate, note, sourceResult: result });
  }
  await prospectRef.set({ commercial: { ...(p.commercial || {}), status: newStatus, assignedTo: p.commercial?.assignedTo || u.id, assignedToName: p.commercial?.assignedToName || u.name, lastNoteAt: nowISO(), lastResult: result, nextActionDate: nextActionDate || null, followUpOpen: isFollowUp, taskOpen: !!task, taskType: task ? task.type : null, taskDueDate: task ? task.dueDate : null, completedAt: ['completed','discarded'].includes(newStatus) ? nowISO() : null }, updatedAt: nowISO() }, { merge: true });
  sendJson(res, { ok: true, status: newStatus, followUpOpen: isFollowUp, nextActionDate: nextActionDate || null, task });
}
async function detail(req, res) {
  const id = cleanText(req.query.id);
  if (!id) return sendJson(res, { ok: false, error: 'Falta id' }, 400);
  const pdoc = await db.collection(C.prospects).doc(id).get();
  if (!pdoc.exists) return sendJson(res, { ok: false, error: 'No encontrado' }, 404);
  const p = { id: pdoc.id, ...pdoc.data() };
  const u = currentUser(req);
  if (!isAdmin(req) && p.commercial?.assignedTo !== u.id) {
    return sendJson(res, { ok: false, error: 'Este prospecto no está asignado a tu usuario.' }, 403);
  }
  const itemsSnap = await db.collection(C.customsItems).where('customsGroupId', '==', p.match?.customsGroupId || p.id).limit(500).get();
  const notesSnap = await db.collection(C.notes).where('prospectId', '==', id).limit(100).get();
  const notes = notesSnap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  sendJson(res, { ok: true, prospect: p, customsItems: itemsSnap.docs.map(d => ({ id: d.id, ...d.data() })), notes });
}
async function stats(req, res) {
  const prospects = await getAllDocs(C.prospects, 10000);
  const out = { total: prospects.length, available: 0, assigned: 0, in_progress: 0, completed: 0, unmatched: 0, totalFob: 0, bySeller: {}, byProvince: {}, byChapter: {} };
  for (const p of prospects) {
    const st = p.commercial?.status || 'available'; out[st] = (out[st] || 0) + 1;
    if (p.match?.matchStatus === 'unmatched') out.unmatched++;
    out.totalFob += Number(p.customsSummary?.totalFob || 0);
    const seller = p.commercial?.assignedToName || 'Sin asignar'; out.bySeller[seller] = (out.bySeller[seller] || 0) + 1;
    const prov = p.contact?.province || 'Sin provincia'; out.byProvince[prov] = (out.byProvince[prov] || 0) + 1;
    for (const ch of p.customsSummary?.chapters || []) out.byChapter[ch] = (out.byChapter[ch] || 0) + 1;
  }
  sendJson(res, { ok: true, stats: out });
}

function resultLabel(v) {
  const map = {
    no_responde: 'No responde',
    contactado: 'Contactado',
    llamar_luego: 'Llamar luego',
    interesado: 'Interesado',
    pidio_cotizacion: 'Pidió cotización',
    descartado: 'Descartado',
    dato_incorrecto: 'Dato incorrecto',
    tarea_completada: 'Tarea completada',
    tarea_reprogramada: 'Tarea reprogramada'
  };
  return map[v] || v || '';
}
function nextDateYMD(dateStr) {
  const d = new Date(String(dateStr || todayYMD()) + 'T00:00:00.000Z');
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}
function addDaysToYMD(dateStr, days) {
  const d = new Date(String(dateStr || todayYMD()) + 'T00:00:00.000Z');
  d.setUTCDate(d.getUTCDate() + Number(days || 0));
  return d.toISOString().slice(0, 10);
}
function firstDayOfMonthYMD(dateStr) {
  const d = new Date(String(dateStr || todayYMD()) + 'T00:00:00.000Z');
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-01`;
}
function nextMonthYMD(dateStr) {
  const d = new Date(String(dateStr || todayYMD()) + 'T00:00:00.000Z');
  d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth()+1);
  return d.toISOString().slice(0, 10);
}
function weekMondayYMD(dateStr) {
  const d = new Date(String(dateStr || todayYMD()) + 'T00:00:00.000Z');
  const day = d.getUTCDay();
  const diff = (day + 6) % 7;
  d.setUTCDate(d.getUTCDate() - diff);
  return d.toISOString().slice(0, 10);
}
function dateInRangeYMD(dateStr, start, endInclusive) {
  if (!dateStr) return false;
  const d = String(dateStr).slice(0,10);
  if (start && d < start) return false;
  if (endInclusive && d > endInclusive) return false;
  return true;
}
function resolveReportRange({ period, date, from, to }) {
  const p = cleanText(period || 'day');
  const base = cleanText(date || todayYMD());
  if (p === 'history') return { start: '', endInclusive: '', endExclusive: '', label: 'Histórico' };
  if (p === 'custom') {
    const s = cleanText(from || base || todayYMD());
    const e = cleanText(to || s);
    return { start: s, endInclusive: e, endExclusive: nextDateYMD(e), label: `Personalizado ${s} a ${e}` };
  }
  if (p === 'week') {
    const s = weekMondayYMD(base);
    const e = addDaysToYMD(s, 6);
    return { start: s, endInclusive: e, endExclusive: nextDateYMD(e), label: `Semana ${s} a ${e}` };
  }
  if (p === 'month') {
    const s = firstDayOfMonthYMD(base);
    const ex = nextMonthYMD(base);
    const e = addDaysToYMD(ex, -1);
    return { start: s, endInclusive: e, endExclusive: ex, label: `Mes ${s.slice(0,7)}` };
  }
  return { start: base, endInclusive: base, endExclusive: nextDateYMD(base), label: `Día ${base}` };
}
async function getProspectsByIds(ids) {
  const unique = [...new Set((ids || []).filter(Boolean))];
  const out = {};
  for (let i = 0; i < unique.length; i += 250) {
    const chunk = unique.slice(i, i + 250);
    if (!chunk.length) continue;
    const docs = await db.getAll(...chunk.map(id => db.collection(C.prospects).doc(id)));
    docs.forEach(d => { if (d.exists) out[d.id] = { id: d.id, ...d.data() }; });
  }
  return out;
}
async function adminDailyReport(req, res) {
  if (!isAdmin(req)) return sendJson(res, { ok: false, error: 'Solo admin' }, 403);
  const q = req.query || {};
  const period = cleanText(q.period || 'day');
  const baseDate = cleanText(q.date || todayYMD());
  const sellerId = cleanText(q.sellerId || 'all');
  const range = resolveReportRange({ period, date: baseDate, from: q.from, to: q.to });
  const limit = Math.min(Math.max(Number(q.limit || 1500), 50), 5000);

  let notesRef = db.collection(C.notes);
  if (range.start) notesRef = notesRef.where('createdAt', '>=', range.start + 'T00:00:00.000Z');
  if (range.endExclusive) notesRef = notesRef.where('createdAt', '<', range.endExclusive + 'T00:00:00.000Z');
  const notesSnap = await notesRef.limit(limit).get();
  let notes = notesSnap.docs.map(d => ({ id: d.id, ...d.data() }));
  if (sellerId && sellerId !== 'all') notes = notes.filter(n => String(n.userId || '') === sellerId);

  const prospectMap = await getProspectsByIds(notes.map(n => n.prospectId));
  const summary = {};
  function sellerRow(id, name) {
    const key = id || 'sin_usuario';
    if (!summary[key]) summary[key] = { sellerId: key, sellerName: name || key, gestiones: 0, results: {}, tareasCreadas: 0, tareasCompletadas: 0, tareasAbiertas: 0, tareasVencidas: 0, tareasHoy: 0, tareasProximas: 0 };
    if (name && (!summary[key].sellerName || summary[key].sellerName === key)) summary[key].sellerName = name;
    return summary[key];
  }
  const detail = notes.map(n => {
    const pr = prospectMap[n.prospectId] || {};
    const row = sellerRow(n.userId, n.userName);
    row.gestiones += 1;
    const r = resultLabel(n.result) || 'Sin resultado';
    row.results[r] = (row.results[r] || 0) + 1;
    return {
      time: String(n.createdAt || '').slice(11, 19),
      date: String(n.createdAt || '').slice(0, 10),
      createdAt: n.createdAt || '',
      sellerId: n.userId || '',
      sellerName: n.userName || '',
      prospectId: n.prospectId || '',
      companyName: pr.companyName || pr.importador || n.companyName || '',
      city: pr.contact?.city || '',
      province: pr.contact?.province || '',
      result: n.result || '',
      resultLabel: r,
      taskType: n.taskTypeLabel || taskLabel(n.taskType) || '',
      nextActionDate: n.nextActionDate || '',
      note: n.note || ''
    };
  }).sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)));

  let tasksRef = db.collection(C.tasks);
  if (sellerId && sellerId !== 'all') tasksRef = tasksRef.where('assignedTo', '==', sellerId);
  const tasksSnap = await tasksRef.limit(period === 'history' ? 5000 : 2500).get();
  const today = todayYMD();
  for (const d of tasksSnap.docs) {
    const t = d.data();
    const row = sellerRow(t.assignedTo, t.assignedToName);
    const createdDay = String(t.createdAt || '').slice(0,10);
    const completedDay = String(t.completedAt || '').slice(0,10);
    if (dateInRangeYMD(createdDay, range.start, range.endInclusive)) row.tareasCreadas += 1;
    if (dateInRangeYMD(completedDay, range.start, range.endInclusive)) row.tareasCompletadas += 1;
    if ((t.status || 'open') !== 'completed') {
      row.tareasAbiertas += 1;
      const due = String(t.dueDate || '9999-12-31');
      if (due < today) row.tareasVencidas += 1;
      else if (due === today) row.tareasHoy += 1;
      else row.tareasProximas += 1;
    }
  }

  const sellers = Object.values(summary).sort((a,b) => (b.gestiones - a.gestiones) || String(a.sellerName).localeCompare(String(b.sellerName)));
  const totals = sellers.reduce((acc, s) => {
    acc.gestiones += s.gestiones;
    acc.tareasCreadas += s.tareasCreadas;
    acc.tareasCompletadas += s.tareasCompletadas;
    acc.tareasAbiertas += s.tareasAbiertas;
    acc.tareasVencidas += s.tareasVencidas;
    acc.tareasHoy += s.tareasHoy;
    acc.tareasProximas += s.tareasProximas;
    return acc;
  }, { gestiones:0, tareasCreadas:0, tareasCompletadas:0, tareasAbiertas:0, tareasVencidas:0, tareasHoy:0, tareasProximas:0 });
  sendJson(res, { ok: true, period, date: baseDate, from: range.start || '', to: range.endInclusive || '', label: range.label, sellerId, totals, sellers, detail, notesScanned: notesSnap.size, tasksScanned: tasksSnap.size, limit });
}

async function exportCsv(req, res) {
  const prospects = await getAllDocs(C.prospects, 20000);
  const header = ['Importador','Ciudad','Provincia','Telefono','Email','Web','FOB Total','Items','Capitulos','Origenes','Estado','Vendedor','Match','Nota Resultado'];
  const lines = [header.join(',')];
  for (const p of prospects) {
    const row = [p.companyName, p.contact?.city, p.contact?.province, p.contact?.phone, p.contact?.email, p.contact?.website, p.customsSummary?.totalFob, p.customsSummary?.importCount, (p.customsSummary?.chapters || []).join('|'), (p.customsSummary?.origins || []).join('|'), p.commercial?.status, p.commercial?.assignedToName, p.match?.matchStatus, p.commercial?.lastResult]
      .map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"');
    lines.push(row.join(','));
  }
  res.status(200).set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="scb-hunter-campo-prospectos.csv"' }).send(lines.join('\n'));
}
const CLIENT_JS = String.raw`
function user(){return localStorage.getItem('scbHunterUser')||document.getElementById('user')?.value||''}
function userPass(){return localStorage.getItem('scbHunterPass')||document.getElementById('userPass')?.value||''}
function userRole(){return localStorage.getItem('scbHunterRole')||'guest'}
function isLoggedIn(){return Boolean(localStorage.getItem('scbHunterUser')&&localStorage.getItem('scbHunterPass'))}
function isAdminFront(){return isLoggedIn() && userRole()==='admin'}
async function saveUser(){const u=(document.getElementById('user')?.value||'').trim();const p=document.getElementById('userPass')?.value||'';if(!u||!p)return alert('Ingresá usuario y clave');try{const j=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user:u,password:p})}).then(r=>r.json());if(!j.ok) return alert(j.error||'No autorizado');localStorage.setItem('scbHunterUser',u);localStorage.setItem('scbHunterPass',p);localStorage.setItem('scbHunterRole',j.user?.role||((u==='admin')?'admin':'seller'));localStorage.setItem('scbHunterName',j.user?.name||u);applyRoleUI();}catch(e){alert(e.message||e)}}
function logoutHunter(){localStorage.removeItem('scbHunterUser');localStorage.removeItem('scbHunterPass');localStorage.removeItem('scbHunterRole');localStorage.removeItem('scbHunterName');location.reload()}
if(document.getElementById('user')) document.getElementById('user').value=localStorage.getItem('scbHunterUser')||''; if(document.getElementById('userPass')) document.getElementById('userPass').value='';
function tab(id,btn){document.querySelectorAll('.view').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');document.getElementById('detailBox').classList.add('hidden')}
function applyRoleUI(){const login=document.getElementById('loginScreen');const appTop=document.getElementById('appTop');const appWrap=document.getElementById('appWrap');if(!isLoggedIn()){if(login)login.classList.remove('hidden');if(appTop)appTop.classList.add('hidden');if(appWrap)appWrap.classList.add('hidden');return;}if(login)login.classList.add('hidden');if(appTop)appTop.classList.remove('hidden');if(appWrap)appWrap.classList.remove('hidden');const n=localStorage.getItem('scbHunterName')||user();const lu=document.getElementById('loggedUserName');if(lu)lu.textContent=n;const admin=isAdminFront();document.body.dataset.role=admin?'admin':'seller';document.querySelectorAll('.adminOnly').forEach(x=>x.classList.toggle('hidden',!admin));document.querySelectorAll('.sellerOnly').forEach(x=>x.classList.toggle('hidden',admin));if(admin){tab('panel',document.getElementById('tabPanel'));}else{tab('mios',document.getElementById('tabMios'));loadProspects('mine');}}
let filterOptionsCache=null;
let sellersCache=[];
let availableVisibleIds=[];
let selectedProspects=new Set();
function setSelectOptions(id, values, firstLabel){const el=document.getElementById(id);if(!el)return;const current=el.value;let h='<option value="">'+esc(firstLabel||'Todos')+'</option>';for(const v of values||[]){h+='<option value="'+esc(v)+'">'+esc(v)+'</option>'}el.innerHTML=h;if(current)el.value=current;}
function setFobOptions(ranges){const el=document.getElementById('fFobRange');if(!el)return;let h='';for(const r of ranges||[]){h+='<option value="'+esc(r.value)+'">'+esc(r.label)+'</option>'}el.innerHTML=h;}
function updateCityOptions(){if(!filterOptionsCache)return;const prov=document.getElementById('fProvince')?.value||'';const pn=normFront(prov);const cities=prov?filterOptionsCache.provinceCities[pn]||[]:Object.values(filterOptionsCache.provinceCities||{}).flat();setSelectOptions('fCity',cities,'Todas las ciudades')}
function normFront(x){return String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toUpperCase().replace(/\s+/g,' ')}
async function loadFilterOptions(){if(filterOptionsCache){return}try{const j=await api('/api/filter-options?user='+encodeURIComponent(user()));filterOptionsCache=j;setSelectOptions('fProvince',j.provinces,'Todas las provincias');setSelectOptions('fChapter',j.chapters,'Todos los capítulos');setSelectOptions('fOrigin',j.origins,'Todos los orígenes');setFobOptions(j.fobRanges);updateCityOptions();}catch(e){console.warn('No pude cargar opciones filtros',e)}}
async function loadSellers(){try{const j=await api('/api/admin/sellers?user='+encodeURIComponent(user()));sellersCache=j.sellers||[];renderSellerSelects();}catch(e){console.warn('No pude cargar vendedores',e)}}
function renderSellerSelects(){const html='<option value="">Elegir vendedor</option>'+sellersCache.map(s=>'<option value="'+esc(s.id)+'">'+esc(s.name||s.id)+' '+(s.role==='admin'?'(admin)':'')+'</option>').join('');['assignSeller','newSellerRoleDummy'].forEach(id=>{});const el=document.getElementById('assignSeller');if(el)el.innerHTML=html;}
async function refreshAvailableCount(){let url='/api/available-count?user='+encodeURIComponent(user());const f=filters();Object.keys(f).forEach(k=>{if(f[k])url+='&'+k+'='+encodeURIComponent(f[k])});const box=document.getElementById('availableCount');if(box)box.textContent='Contando...';try{const j=await api(url);if(box)box.textContent='Total con filtros: '+j.count+(j.exact?'':' (conteo limitado)')+(j.note?' - '+j.note:'');}catch(e){if(box)box.textContent='No pude contar: '+(e.error||e.message||JSON.stringify(e));}}
async function openAvailable(btn){tab('disponibles',btn);await loadFilterOptions();await loadSellers();await refreshAvailableCount();await loadProspects('available')}
async function api(url,opt={}){opt.headers=opt.headers||{};opt.headers['x-scb-user']=user();opt.headers['x-scb-pass']=userPass();try{const sep=url.includes('?')?'&':'?';if(!url.includes('pass='))url+=sep+'pass='+encodeURIComponent(userPass());if(!url.includes('user='))url+=(url.includes('?')?'&':'?')+'user='+encodeURIComponent(user());}catch(_){ }const r=await fetch(url,opt);const ct=r.headers.get('content-type')||'';if(ct.includes('json')){const j=await r.json(); if(!r.ok) throw j; return j;} const t=await r.text(); if(!r.ok) throw new Error(t); return t;}
function filters(){return {status:fStatus.value,province:fProvince.value,city:fCity.value,chapter:fChapter.value,origin:fOrigin.value,desc:fDesc.value,fobRange:fFobRange.value,order:(document.getElementById('fOrder')?.value||'mix')}}
async function fileToBase64(file){const buf=await file.arrayBuffer();let binary='';const bytes=new Uint8Array(buf);const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk){binary+=String.fromCharCode.apply(null,bytes.subarray(i,i+chunk));}return btoa(binary)}
async function uploadFile(type){
  const el=document.getElementById(type==='contact'?'contactFile':'customsFile');
  if(!el.files[0]) return alert('Elegí un archivo');
  const file=el.files[0];
  const msg=document.getElementById('importMsg');
  msg.classList.remove('hidden');
  msg.textContent='Leyendo archivo...';
  try{
    const dataBase64=await fileToBase64(file);
    if(type==='customs'){
      msg.textContent='Preparando carga larga. Esto solo arma el job, después procesa por tandas...';
      const j=await api('/api/upload/customs?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:file.name,dataBase64,async:true})});
      msg.textContent='Job creado. Procesando...\n'+JSON.stringify(j,null,2);
      if(j.sourceJobId) await processUploadJobLoop(j.sourceJobId);
      return;
    }
    msg.textContent='Procesando contactos en servidor...';
    const j=await api('/api/upload/contact?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:file.name,dataBase64})});
    msg.textContent=JSON.stringify(j,null,2);
  }catch(e){msg.textContent='ERROR: '+JSON.stringify(e,null,2)}
}
async function processUploadJobLoop(jobId){
  const msg=document.getElementById('importMsg');
  let safety=0;
  while(safety++<10000){
    const r=await api('/api/job/process?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:jobId,maxChunks:1})});
    const j=r.job||{};
    const pct=j.rows?Math.round((Number(j.processedRows||0)/Number(j.rows||1))*100):0;
    msg.textContent='Procesando aduana... '+pct+'%\nFilas: '+(j.processedRows||0)+' / '+(j.rows||0)+'\nVálidas: '+(j.valid||0)+' | Ignoradas: '+(j.skipped||0)+' | Ítems guardados: '+(j.itemWrites||0)+'\nChunks: '+(j.chunksDone||0)+' / '+(j.chunkCount||0)+'\nEstado: '+(j.status||'')+'\nJob: '+jobId;
    if(r.done || j.status==='done'){
      msg.textContent+='\n\nTERMINADO. Match e índices reconstruidos.';
      await loadAdminJobs().catch(()=>{});
      return;
    }
    await new Promise(resolve=>setTimeout(resolve,300));
  }
  msg.textContent+='\nSe pausó por seguridad. Podés continuar desde Admin / Borrado con el botón Continuar.';
}
async function continueJob(jobId){
  const msg=document.getElementById('adminMsg');
  if(msg){msg.classList.remove('hidden');msg.textContent='Continuando job '+jobId+'...'}
  await processUploadJobLoop(jobId);
  await loadAdminJobs();
}


function taskPill(t){const today=new Date().toISOString().slice(0,10);if((t.status||'open')==='completed')return '<span class="pill">Completada</span>';if(t.dueDate<today)return '<span class="pill" style="background:#fee2e2;color:#991b1b">Vencida</span>';if(t.dueDate===today)return '<span class="pill" style="background:#fef3c7;color:#92400e">Hoy</span>';return '<span class="pill" style="background:#dcfce7;color:#166534">Próxima</span>'}
async function loadTasks(){
  const mode=document.getElementById('taskMode')?.value||'open';
  const q=document.getElementById('taskQ')?.value||'';
  const limit=document.getElementById('taskLimit')?.value||100;
  const j=await api('/api/tasks?user='+encodeURIComponent(user())+'&mode='+encodeURIComponent(mode)+'&q='+encodeURIComponent(q)+'&limit='+encodeURIComponent(limit));
  const c=j.counts||{};
  const sum=document.getElementById('tasksSummary');
  if(sum) sum.textContent='Abiertas: '+(c.open||0)+' | Vencidas: '+(c.overdue||0)+' | Hoy: '+(c.today||0)+' | Próximas: '+(c.upcoming||0)+' | Completadas: '+(c.completed||0);
  renderTasks(j.tasks||[]);
}
function renderTasks(rows){
  const box=document.getElementById('tasksList');
  if(!rows.length){box.innerHTML='<p class="muted">Sin tareas para este filtro.</p>';return}
  let h='<table><thead><tr><th>Fecha</th><th>Tarea</th><th>Empresa</th><th>Nota</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>';
  for(const t of rows){h+='<tr><td><b>'+esc(t.dueDate||'')+'</b></td><td>'+esc(t.typeLabel||t.type||'')+'</td><td><b>'+esc(t.companyName||'')+'</b><br><span class="muted small">'+esc([t.contact?.city,t.contact?.province].filter(Boolean).join(', '))+'</span></td><td>'+esc(t.note||'')+'</td><td>'+taskPill(t)+'</td><td class="row-actions"><button data-id="'+esc(t.prospectId||t.id)+'" onclick="openDetail(this.dataset.id)">Abrir</button>'+(t.status==='completed'?'':'<button class="ok" data-id="'+esc(t.id)+'" onclick="completeTask(this.dataset.id)">Completar</button><button class="secondary" data-id="'+esc(t.id)+'" onclick="reprogramTask(this.dataset.id,2)">+2 días</button><button class="secondary" data-id="'+esc(t.id)+'" onclick="reprogramTask(this.dataset.id,7)">+7 días</button><button class="secondary" data-id="'+esc(t.id)+'" onclick="chooseTaskDate(this.dataset.id)">Elegir fecha</button>')+'</td></tr>'}
  box.innerHTML=h+'</tbody></table>';
}
async function completeTask(id){const note=prompt('Nota de cierre de tarea','Tarea completada');if(note===null)return;try{await api('/api/task/complete?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,note})});await loadTasks();await loadProspects('mine').catch(()=>{});}catch(e){alert(e.error||JSON.stringify(e))}}
async function reprogramTask(id,days){try{await api('/api/task/reprogram?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,days,note:'Reprogramado '+(days?('+'+days+' días'):'')})});await loadTasks();await loadProspects('mine').catch(()=>{});}catch(e){alert(e.error||JSON.stringify(e))}}
async function chooseTaskDate(id){const d=prompt('Nueva fecha AAAA-MM-DD',new Date().toISOString().slice(0,10));if(!d)return;try{await api('/api/task/reprogram?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,dueDate:d,note:'Reprogramado para '+d})});await loadTasks();await loadProspects('mine').catch(()=>{});}catch(e){alert(e.error||JSON.stringify(e))}}


async function openDailyReport(btn){
  tab('reporte',btn);
  await loadSellers();
  renderReportSellerSelect();
  const today=new Date().toISOString().slice(0,10);
  const d=document.getElementById('reportDate'); if(d&&!d.value)d.value=today;
  const f=document.getElementById('reportFrom'); if(f&&!f.value)f.value=today;
  const t=document.getElementById('reportTo'); if(t&&!t.value)t.value=today;
  updateReportPeriodUI();
  loadDailyReport();
}
function renderReportSellerSelect(){const el=document.getElementById('reportSeller');if(!el)return;const cur=el.value||'all';let h='<option value="all">Todos los vendedores</option>';for(const s of sellersCache||[]){if(s.active===false)continue;h+='<option value="'+esc(s.id)+'">'+esc(s.name||s.id)+'</option>'}el.innerHTML=h;el.value=cur;}
function updateReportPeriodUI(){const p=document.getElementById('reportPeriod')?.value||'day';document.querySelectorAll('.reportCustom').forEach(x=>x.classList.toggle('hidden',p!=='custom'));document.querySelectorAll('.reportDateOne').forEach(x=>x.classList.toggle('hidden',p==='custom'||p==='history'));}
function setReportPeriodQuick(p){const el=document.getElementById('reportPeriod');if(el)el.value=p;updateReportPeriodUI();loadDailyReport();}
function resultCountsText(obj){return Object.keys(obj||{}).map(k=>esc(k)+': '+(obj[k]||0)).join(' · ')||'-'}
async function loadDailyReport(){try{await loadSellers();renderReportSellerSelect();const period=document.getElementById('reportPeriod')?.value||'day';const date=document.getElementById('reportDate')?.value||new Date().toISOString().slice(0,10);const from=document.getElementById('reportFrom')?.value||date;const to=document.getElementById('reportTo')?.value||from;const seller=document.getElementById('reportSeller')?.value||'all';const limit=document.getElementById('reportLimit')?.value||1500;let url='/api/admin/daily-report?user='+encodeURIComponent(user())+'&period='+encodeURIComponent(period)+'&date='+encodeURIComponent(date)+'&from='+encodeURIComponent(from)+'&to='+encodeURIComponent(to)+'&sellerId='+encodeURIComponent(seller)+'&limit='+encodeURIComponent(limit);const j=await api(url);renderDailyReport(j);}catch(e){alert(e.error||JSON.stringify(e))}}
function renderDailyReport(j){const t=j.totals||{};const periodo=j.label||j.date||'';document.getElementById('reportSummary').innerHTML='<b>Período:</b> '+esc(periodo)+' · <b>Gestiones:</b> '+(t.gestiones||0)+' · <b>Tareas creadas:</b> '+(t.tareasCreadas||0)+' · <b>Tareas completadas:</b> '+(t.tareasCompletadas||0)+' · <b>Abiertas:</b> '+(t.tareasAbiertas||0)+' · <b>Vencidas:</b> '+(t.tareasVencidas||0)+' · <b>Hoy:</b> '+(t.tareasHoy||0)+'<br><span class="muted small">Reads controlados: gestiones escaneadas '+(j.notesScanned||0)+' / tareas escaneadas '+(j.tasksScanned||0)+'. Límite detalle: '+(j.limit||'')+'.</span>';let hs='<table><thead><tr><th>Vendedor</th><th>Gestiones</th><th>Resultados</th><th>Tareas creadas</th><th>Completadas</th><th>Abiertas</th><th>Vencidas</th><th>Hoy</th><th>Próximas</th></tr></thead><tbody>';for(const s of j.sellers||[]){hs+='<tr><td><b>'+esc(s.sellerName||s.sellerId)+'</b></td><td>'+s.gestiones+'</td><td>'+resultCountsText(s.results)+'</td><td>'+s.tareasCreadas+'</td><td>'+s.tareasCompletadas+'</td><td>'+s.tareasAbiertas+'</td><td>'+s.tareasVencidas+'</td><td>'+s.tareasHoy+'</td><td>'+s.tareasProximas+'</td></tr>'}document.getElementById('reportSellersBox').innerHTML=hs+'</tbody></table>';let hd='<table><thead><tr><th>Fecha</th><th>Hora</th><th>Vendedor</th><th>Empresa</th><th>Resultado</th><th>Tarea</th><th>Próx.</th><th>Nota</th></tr></thead><tbody>';for(const r of j.detail||[]){hd+='<tr><td>'+esc(r.date||'')+'</td><td>'+esc(r.time||'')+'</td><td>'+esc(r.sellerName||r.sellerId||'')+'</td><td><b>'+esc(r.companyName||'')+'</b><br><span class="muted small">'+esc([r.city,r.province].filter(Boolean).join(', '))+'</span></td><td>'+esc(r.resultLabel||r.result||'')+'</td><td>'+esc(r.taskType||'')+'</td><td>'+esc(r.nextActionDate||'')+'</td><td>'+esc(r.note||'')+'</td></tr>'}document.getElementById('reportDetailBox').innerHTML=hd+'</tbody></table>';}



function renderMineSummary(j){
  const c=j.mineCounts||{};
  const el=document.getElementById('mineSummary');
  if(!el)return;
  el.innerHTML='<b>Total asignados visibles:</b> '+(c.total||0)+' · <b>Sin gestión:</b> '+(c.sin_gestion||0)+' · <b>Vencidos:</b> '+(c.vencidos||0)+' · <b>Hoy:</b> '+(c.hoy||0)+' · <b>Próximas:</b> '+(c.proximas||0)+' · <b>Interesados:</b> '+(c.interesados||0)+' · <b>No responde:</b> '+(c.no_responde||0)+' · <b>Cotización:</b> '+(c.cotizacion||0)+'<br><span class="muted small">Mostrando '+((j.prospects||[]).length)+' filtrados. Si tenés más de 500 asignados, el sistema muestra los primeros 500 para cuidar Firestore.</span>';
}
function quickMine(status){const s=document.getElementById('mineStatus');if(s)s.value=status;loadProspects('mine');}

async function loadProspects(mode){let url='/api/prospects?mode='+mode+'&user='+encodeURIComponent(user());if(mode==='mine'){const st=document.getElementById('mineStatus')?.value||'all';const q=document.getElementById('mineQ')?.value||'';url+='&limit=500&mineStatus='+encodeURIComponent(st)+'&mineQ='+encodeURIComponent(q);}if(mode==='available'){selectedProspects.clear();const f=filters();Object.keys(f).forEach(k=>{if(f[k])url+='&'+k+'='+encodeURIComponent(f[k])});await refreshAvailableCount();}const j=await api(url);if(mode==='mine')renderMineSummary(j);renderList(mode==='mine'?'mineList':'availableList',j.prospects,mode);updateSelectedInfo();}
function money(n){return 'USD '+Number(n||0).toLocaleString('es-AR',{maximumFractionDigits:0})}
function renderList(id,arr,mode){availableVisibleIds=mode==='available'?arr.map(p=>p.id):availableVisibleIds;if(!arr.length){document.getElementById(id).innerHTML='<p class="muted">Sin resultados.</p>';return}let h=(mode==='mine'?'<p class="muted small">Mostrando hasta 500 prospectos asignados. Usá los filtros para que no se pierdan seguimientos.</p>':'')+'<table><thead><tr>'+(mode==='available'?'<th><input type="checkbox" onchange="toggleSelectAllVisible(this.checked)"></th>':'')+'<th>Empresa</th><th>Contacto</th><th>Aduana</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>';for(const p of arr){const canSelect=mode==='available' && (p.commercial?.status||'available')==='available';const cb=mode==='available'?'<td>'+(canSelect?'<input class="prospectChk" type="checkbox" value="'+esc(p.id)+'" onchange="toggleOneProspect(this.value,this.checked)" '+(selectedProspects.has(p.id)?'checked':'')+'>':'')+'</td>':'';h+='<tr>'+cb+'<td><b>'+esc(p.companyName)+'</b><br><span class="muted small">Match: '+esc(p.match?.matchStatus||'')+' '+(p.match?.matchScore||0)+'%</span></td><td>'+esc([p.contact?.city,p.contact?.province].filter(Boolean).join(', '))+'<br>'+esc(p.contact?.phone||'')+'<br>'+esc(p.contact?.email||'')+'</td><td><span class="money">'+money(p.customsSummary?.totalFob)+'</span><br>Items: '+(p.customsSummary?.importCount||0)+'<br>NCM: '+esc((p.customsSummary?.chapters||[]).join(', '))+'<br>Origen: '+esc((p.customsSummary?.origins||[]).join(', '))+'</td><td><span class="pill">'+esc(p.commercial?.status||'')+'</span><br>'+esc(p.commercial?.assignedToName||'')+(p.commercial?.lastResult?'<br><span class="muted small">'+esc(p.commercial.lastResult)+'</span>':'')+(p.commercial?.nextActionDate?'<br><span class="muted small">Seg.: '+esc(p.commercial.nextActionDate)+'</span>':'')+(p.commercial?.taskOpen?'<br><span class="pill">Tarea: '+esc(p.commercial.taskDueDate||'')+'</span>':'')+'</td><td class="row-actions"><button data-id="'+esc(p.id)+'" onclick="openDetail(this.dataset.id)">Ver</button></td></tr>'}h+='</tbody></table>';document.getElementById(id).innerHTML=h}
async function takeBatch(){try{const j=await api('/api/take-batch?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filters:isAdminFront()?filters():{},batchSize:10})});alert('Asignados: '+j.assignedCount);loadProspects('mine')}catch(e){alert(e.error||JSON.stringify(e))}}
async function pedirMas(){try{const j=await api('/api/take-batch?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filters:{order:'mix'},batchSize:10})});let msg=j.assignedCount?('Te asigné '+j.assignedCount+' prospectos más.'): 'No hay más prospectos disponibles para asignar.';if(j.zoneApplied)msg+='\nZona aplicada: '+(j.sellerZone||'');loadProspects('mine');alert(msg)}catch(e){alert(e.error||JSON.stringify(e))}}
function toggleOneProspect(id,checked){if(checked)selectedProspects.add(id);else selectedProspects.delete(id);updateSelectedInfo()}
function toggleSelectAllVisible(checked){for(const id of availableVisibleIds){if(checked)selectedProspects.add(id);else selectedProspects.delete(id)}document.querySelectorAll('.prospectChk').forEach(x=>x.checked=checked);updateSelectedInfo()}
function clearSelected(){selectedProspects.clear();document.querySelectorAll('.prospectChk').forEach(x=>x.checked=false);updateSelectedInfo()}
function updateSelectedInfo(){const el=document.getElementById('selectedInfo');if(el)el.textContent='Seleccionados visibles/manuales: '+selectedProspects.size}
async function assignSelected(){const sellerId=document.getElementById('assignSeller')?.value||'';if(!sellerId)return alert('Elegí vendedor');const ids=[...selectedProspects];if(!ids.length)return alert('Seleccioná al menos un prospecto');if(!confirm('Asignar '+ids.length+' prospectos seleccionados?'))return;try{const j=await api('/api/admin/assign-selected?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids,sellerId})});alert('Asignados: '+j.assigned+' | Salteados: '+j.skipped);clearSelected();await loadProspects('available');}catch(e){alert(e.error||JSON.stringify(e))}}
async function assignFiltered(){const sellerId=document.getElementById('assignSeller')?.value||'';if(!sellerId)return alert('Elegí vendedor');const limit=Number(document.getElementById('assignLimit')?.value||200);const c=prompt('Para asignar todos los disponibles con estos filtros, máximo '+limit+', escribí ASIGNAR');if(c!=='ASIGNAR')return;try{const j=await api('/api/admin/assign-filtered?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filters:filters(),sellerId,limit,confirm:'ASIGNAR'})});alert('Asignados: '+j.assigned+' | Salteados: '+j.skipped);clearSelected();await loadProspects('available');}catch(e){alert(e.error||JSON.stringify(e))}}
async function openDetail(id){
  const j=await api('/api/detail?id='+encodeURIComponent(id)+'&user='+encodeURIComponent(user()));
  const p=j.prospect;
  const lastNote = (j.notes && j.notes[0]) || {};
  const lastResult = p.commercial?.lastResult || lastNote.result || '';
  const lastNext = p.commercial?.nextActionDate || lastNote.nextActionDate || '';
  const adminActions = isAdminFront()?'<div class="row-actions"><button class="secondary" data-id="'+esc(p.id)+'" onclick="adminRelease(this.dataset.id)">Liberar asignación</button><button class="bad" data-id="'+esc(p.id)+'" onclick="adminDeleteProspect(this.dataset.id)">Borrar prospecto</button></div><br>':'';
  let h='<h3>'+esc(p.companyName)+'</h3>'+
    adminActions+
    '<div class="grid">'+
    '<div class="col6"><h4>Contacto</h4><p><b>Ciudad:</b> '+esc(p.contact?.city||'')+'<br><b>Provincia:</b> '+esc(p.contact?.province||'')+'<br><b>Dirección:</b> '+esc(p.contact?.address||'')+'<br><b>Tel:</b> '+esc(p.contact?.phone||'')+'<br><b>Email:</b> '+esc(p.contact?.email||'')+'<br><b>Web:</b> '+esc(p.contact?.website||'')+'</p></div>'+
    '<div class="col6"><h4>Resumen aduanero</h4><p><b>FOB:</b> '+money(p.customsSummary?.totalFob)+'<br><b>Items:</b> '+(p.customsSummary?.importCount||0)+'<br><b>Capítulos:</b> '+esc((p.customsSummary?.chapters||[]).join(', '))+'<br><b>Origenes:</b> '+esc((p.customsSummary?.origins||[]).join(', '))+'<br><b>Estado comercial:</b> '+esc(p.commercial?.status||'')+'<br><b>Último resultado:</b> '+esc(lastResult||'-')+'</p></div>'+
    '<div class="col12"><h4>Gestión guardada</h4>'+renderNotes(j.notes || [])+'</div>'+
    '<div class="col12"><h4>Cargar nueva gestión</h4><div class="grid">'+
    '<div class="col4"><select id="r_'+p.id+'"><option value="">Resultado</option><option value="no_responde">No responde</option><option value="contactado">Contactado</option><option value="llamar_luego">Llamar luego</option><option value="interesado">Interesado</option><option value="pidio_cotizacion">Pidió cotización</option><option value="descartado">Descartado</option><option value="dato_incorrecto">Dato incorrecto</option></select></div>'+
    '<div class="col4"><input type="date" id="d_'+p.id+'" value="'+esc(lastNext||'')+'"></div>'+
    '<div class="col4"><select id="t_'+p.id+'"><option value="">Próxima tarea</option><option value="volver_llamar">Volver a llamar</option><option value="mandar_email">Mandar email</option><option value="enviar_whatsapp">Enviar WhatsApp</option><option value="enviar_cotizacion">Enviar cotización</option><option value="pedir_datos">Pedir datos</option><option value="seguimiento_general">Seguimiento general</option></select></div>'+
    '<div class="col12"><textarea id="n_'+p.id+'" placeholder="Nota obligatoria"></textarea></div>'+
    '<div class="col12"><button class="ok" data-id="'+esc(p.id)+'" onclick="saveNote(this.dataset.id)">Guardar gestión</button></div>'+
    '</div></div><div class="col12"><h4>Ítems aduaneros</h4>'+renderItems(j.customsItems)+'</div></div>';
  const box=document.getElementById('detailBox');
  box.innerHTML=h;
  if(lastResult && document.getElementById('r_'+p.id)) document.getElementById('r_'+p.id).value=lastResult;
  if(p.commercial?.taskType && document.getElementById('t_'+p.id)) document.getElementById('t_'+p.id).value=p.commercial.taskType;
  box.classList.remove('hidden');
  box.scrollIntoView({behavior:'smooth'});
}
function renderNotes(notes){
  if(!notes.length) return '<p class="muted">Todavía no hay gestiones cargadas.</p>';
  let h='<table><thead><tr><th>Fecha</th><th>Vendedor</th><th>Resultado</th><th>Próxima acción</th><th>Nota</th></tr></thead><tbody>';
  for(const n of notes){h+='<tr><td>'+esc((n.createdAt||'').slice(0,19).replace('T',' '))+'</td><td>'+esc(n.userName||n.userId||'')+'</td><td>'+esc(n.result||'')+'</td><td>'+esc(n.nextActionDate||'')+'</td><td>'+esc(n.note||'')+'</td></tr>'}
  return h+'</tbody></table>';
}
function renderItems(items){if(!items.length)return '<p class="muted">Sin ítems.</p>';let h='<table><thead><tr><th>Aduana</th><th>Posición</th><th>Descripción</th><th>Dest.</th><th>Item</th><th>Transporte</th><th>Cantidad</th><th>FOB</th><th>Origen</th><th>Proc.</th><th>Divisa</th></tr></thead><tbody>';for(const x of items){h+='<tr><td>'+esc(x.aduana)+'</td><td>'+esc(x.posicion)+'</td><td>'+esc(x.descripcion)+'</td><td>'+esc(x.destinacion)+'</td><td>'+esc(x.item)+'</td><td>'+esc(x.transporte)+'</td><td>'+esc(x.cantidad)+'</td><td>'+money(x.fob)+'</td><td>'+esc(x.origen)+'</td><td>'+esc(x.procedencia)+'</td><td>'+esc(x.divisa)+'</td></tr>'}return h+'</tbody></table>'}
async function saveNote(id){const result=document.getElementById('r_'+id).value,note=document.getElementById('n_'+id).value,nextActionDate=document.getElementById('d_'+id).value,taskType=document.getElementById('t_'+id)?.value||'';if(!result||!note)return alert('Resultado y nota son obligatorios');if((result==='no_responde'||result==='llamar_luego')&&!nextActionDate)return alert('Para No responde / Llamar luego cargá fecha de próxima acción');try{const j=await api('/api/note?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prospectId:id,result,note,nextActionDate,taskType})});alert(j.task?'Gestión guardada y tarea creada/actualizada.':(j.followUpOpen?'Guardado en seguimiento. No bloquea pedir 10 más.':'Guardado: '+j.status));await loadProspects('mine');await loadTasks().catch(()=>{});await openDetail(id)}catch(e){alert(e.error||JSON.stringify(e))}}
async function loadSellerAdmin(){tab('vendedores',document.getElementById('tabVendedores'));await loadFilterOptions();await loadSellers();renderSellerAdmin()}
function zoneJoin(a){return (a||[]).join(', ')}
function getMultiValues(id){return Array.from(document.getElementById(id)?.selectedOptions||[]).map(o=>o.value).filter(Boolean)}
function setMultiOptions(id,values,placeholder,selected){const el=document.getElementById(id);if(!el)return;const sel=new Set((selected||[]).map(normFront));let h='';for(const v of values||[]){const n=normFront(v);h+='<option value="'+esc(v)+'" '+(sel.has(n)?'selected':'')+'>'+esc(v)+'</option>'}el.innerHTML=h}
function updateSellerCityOptions(selected){if(!filterOptionsCache)return;const provs=getMultiValues('sellerProvinces');let cities=[];if(provs.length){for(const p of provs){cities=cities.concat(filterOptionsCache.provinceCities[normFront(p)]||[])}}else{cities=Object.values(filterOptionsCache.provinceCities||{}).flat()}cities=[...new Set(cities)].sort((a,b)=>a.localeCompare(b,'es'));setMultiOptions('sellerCities',cities,'Ciudades',selected||getMultiValues('sellerCities'))}
function setSellerZoneOptions(selectedProvinces,selectedCities){if(!filterOptionsCache)return;setMultiOptions('sellerProvinces',filterOptionsCache.provinces||[],'Provincias',selectedProvinces||[]);updateSellerCityOptions(selectedCities||[])}
function renderSellerAdmin(){let h='<div class="grid"><div class="col3"><input id="sellerName" placeholder="Nombre vendedor ej: Nicolas"></div><div class="col3"><input id="sellerPassword" placeholder="Clave vendedor" type="text"></div><div class="col2"><select id="sellerRole"><option value="seller">seller</option><option value="admin">admin</option></select></div><div class="col3"><label class="small muted">Provincias asignadas</label><select id="sellerProvinces" multiple size="7" onchange="updateSellerCityOptions()"></select></div><div class="col3"><label class="small muted">Ciudades asignadas</label><select id="sellerCities" multiple size="7"></select></div><div class="col3"><button onclick="saveSellerAdmin()">Guardar vendedor</button></div></div><p class="muted small">Las provincias/ciudades salen de opciones válidas de Argentina. Usá CTRL para seleccionar varias. Si el vendedor no tiene zona asignada, queda bloqueado para pedir 10 más.</p>';h+='<table><thead><tr><th>Vendedor</th><th>Rol</th><th>ID</th><th>Clave</th><th>Zonas asignadas</th><th>Acciones</th></tr></thead><tbody>';for(const s of sellersCache){const prov=zoneJoin(s.allowedProvinces);const cities=zoneJoin(s.allowedCities);h+='<tr><td>'+esc(s.name||s.id)+'</td><td>'+esc(s.role||'seller')+'</td><td>'+esc(s.id)+'</td><td>'+(s.hasPassword?'Cargada':'Sin clave')+'</td><td><b>Prov:</b> '+esc(prov||'-')+'<br><b>Ciudades:</b> '+esc(cities||'-')+'</td><td><button onclick="editSellerName(\''+esc(s.id)+'\',\''+esc(s.name||s.id)+'\',\''+esc(s.role||'seller')+'\',\''+esc(prov)+'\',\''+esc(cities)+'\')">Editar</button> <button class="bad" onclick="deleteSellerAdmin(\''+esc(s.id)+'\')">Desactivar</button></td></tr>'}h+='</tbody></table>';document.getElementById('sellersBox').innerHTML=h;setSellerZoneOptions([],[])}
function editSellerName(id,name,role,provinces,cities){document.getElementById('sellerName').value=name;document.getElementById('sellerRole').value=role||'seller';document.getElementById('sellerPassword').value='';document.getElementById('sellerName').dataset.editId=id;setSellerZoneOptions((provinces||'').split(',').map(x=>x.trim()).filter(Boolean),(cities||'').split(',').map(x=>x.trim()).filter(Boolean));}
async function saveSellerAdmin(){const name=document.getElementById('sellerName').value.trim();if(!name)return alert('Falta nombre');const id=document.getElementById('sellerName').dataset.editId||'';const role=document.getElementById('sellerRole').value||'seller';const password=document.getElementById('sellerPassword').value||'';const allowedProvinces=getMultiValues('sellerProvinces');const allowedCities=getMultiValues('sellerCities');try{await api('/api/admin/sellers/save?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,name,role,password,allowedProvinces,allowedCities})});document.getElementById('sellerName').value='';document.getElementById('sellerPassword').value='';document.getElementById('sellerName').dataset.editId='';await loadSellers();renderSellerAdmin();alert('Vendedor guardado');}catch(e){alert(e.error||JSON.stringify(e))}}
async function deleteSellerAdmin(id){if(!confirm('Desactivar vendedor?'))return;try{await api('/api/admin/sellers/delete?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});await loadSellers();renderSellerAdmin();}catch(e){alert(e.error||JSON.stringify(e))}}
async function loadStats(){const j=await api('/api/stats?user='+encodeURIComponent(user()));const s=j.stats;let h='<div class="grid"><div class="col3 kpi"><b>Total</b><br>'+s.total+'</div><div class="col3 kpi"><b>Disponibles</b><br>'+s.available+'</div><div class="col3 kpi"><b>Asignados</b><br>'+s.assigned+'</div><div class="col3 kpi"><b>FOB Total</b><br>'+money(s.totalFob)+'</div></div><h4>Por vendedor</h4>'+objTable(s.bySeller)+'<h4>Por provincia</h4>'+objTable(s.byProvince)+'<h4>Por capítulo</h4>'+objTable(s.byChapter);document.getElementById('stats').innerHTML=h}
function objTable(o){let h='<table><tbody>';Object.entries(o||{}).sort((a,b)=>b[1]-a[1]).slice(0,50).forEach(([k,v])=>h+='<tr><td>'+esc(k)+'</td><td>'+v+'</td></tr>');return h+'</tbody></table>'}



const auditSellerSelected=new Set();
function renderAuditSellerSelect(){const sel=document.getElementById('auditSellerSelect');if(!sel)return;const list=(sellersCache||[]).filter(s=>s.active!==false);sel.innerHTML='<option value="">Elegir vendedor</option>'+list.map(s=>'<option value="'+esc(s.id)+'">'+esc(s.name||s.id)+'</option>').join('')}
function clearAuditSellerSelection(){auditSellerSelected.clear();updateAuditSellerSelectionInfo();document.querySelectorAll('.auditSellerChk').forEach(c=>c.checked=false)}
function selectAuditSellerVisible(){document.querySelectorAll('.auditSellerChk').forEach(c=>{c.checked=true;auditSellerSelected.add(c.value)});updateAuditSellerSelectionInfo()}
function toggleAuditSeller(id,checked){if(checked)auditSellerSelected.add(id);else auditSellerSelected.delete(id);updateAuditSellerSelectionInfo()}
function updateAuditSellerSelectionInfo(){const el=document.getElementById('auditSellerSelInfo');if(el)el.textContent='Seleccionados: '+auditSellerSelected.size}
async function loadAuditSellerProspects(){
  const sellerId=document.getElementById('auditSellerSelect').value;
  if(!sellerId)return alert('Elegí vendedor');
  const status=document.getElementById('auditSellerStatus').value;
  const q=document.getElementById('auditSellerQ').value;
  const limit=document.getElementById('auditSellerLimit').value||20;
  const box=document.getElementById('auditSellerBox');
  auditSellerSelected.clear();
  box.innerHTML='<p class="muted">Cargando asignaciones...</p>';
  try{
    const j=await api('/api/admin/audit/seller-prospects?user='+encodeURIComponent(user())+'&sellerId='+encodeURIComponent(sellerId)+'&status='+encodeURIComponent(status)+'&q='+encodeURIComponent(q)+'&limit='+encodeURIComponent(limit));
    let h='<p><b>Total vendedor:</b> '+esc(j.counts.total ?? '-')+' | <b>Pendientes:</b> '+esc(j.counts.open ?? '-')+' | <b>Terminados:</b> '+esc(j.counts.completed ?? '-')+' | Mostrando: '+j.rows.length+' <span id="auditSellerSelInfo" class="pill">Seleccionados: 0</span></p>';
    if(!j.rows.length){box.innerHTML=h+'<p class="muted">Sin prospectos para ese filtro.</p>';return}
    h+='<table><thead><tr><th></th><th>Empresa</th><th>Ubicación</th><th>Aduana</th><th>Estado</th><th>Gestión</th><th>Acciones</th></tr></thead><tbody>';
    for(const p of j.rows){const open=['assigned','in_progress'].includes(p.commercial?.status||'');h+='<tr><td>'+(open?'<input class="auditSellerChk" type="checkbox" value="'+esc(p.id)+'" onchange="toggleAuditSeller(this.value,this.checked)">':'')+'</td><td><b>'+esc(p.companyName||'')+'</b><br><span class="muted small">'+esc(p.id||'')+'</span></td><td>'+esc([p.contact?.city,p.contact?.province].filter(Boolean).join(', '))+'</td><td>Items: '+esc(p.customsSummary?.importCount||0)+'<br>FOB: '+money(p.customsSummary?.totalFob||0)+'<br>NCM: '+esc((p.customsSummary?.chapters||[]).join(', '))+'</td><td><span class="pill">'+esc(p.commercial?.status||'')+'</span><br>'+esc(p.commercial?.assignedToName||'')+(p.commercial?.lastResult?'<br><span class="muted small">'+esc(p.commercial.lastResult)+'</span>':'')+(p.commercial?.nextActionDate?'<br><span class="muted small">Seg.: '+esc(p.commercial.nextActionDate)+'</span>':'')+'</td><td>'+esc(p.commercial?.lastResult||'')+'<br><span class="muted small">'+esc(p.commercial?.lastNoteAt||'')+'</span></td><td><button data-id="'+esc(p.id)+'" onclick="openDetail(this.dataset.id)">Ver</button> '+(open?'<button class="bad" data-id="'+esc(p.id)+'" onclick="releaseOneFromAudit(this.dataset.id)">Liberar</button>':'')+'</td></tr>'}
    h+='</tbody></table>';box.innerHTML=h;updateAuditSellerSelectionInfo();
  }catch(e){box.innerHTML='<div class="msg">ERROR: '+esc(e.error||e.message||JSON.stringify(e))+'</div>'}
}
async function releaseOneFromAudit(id){const sellerId=document.getElementById('auditSellerSelect').value;if(!confirm('Liberar este prospecto y devolverlo a disponibles?'))return;try{await api('/api/admin/release-seller-prospects?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sellerId,ids:[id],confirm:'LIBERAR'})});await loadAuditSellerProspects();}catch(e){alert(e.error||JSON.stringify(e))}}
async function releaseAuditSellerSelected(){const sellerId=document.getElementById('auditSellerSelect').value;const ids=[...auditSellerSelected];if(!sellerId)return alert('Elegí vendedor');if(!ids.length)return alert('No seleccionaste prospectos');const c=prompt('Para liberar '+ids.length+' prospectos escribí LIBERAR');if(c!=='LIBERAR')return;try{const j=await api('/api/admin/release-seller-prospects?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sellerId,ids,confirm:'LIBERAR'})});alert('Liberados: '+j.released+' | Salteados: '+j.skipped);await loadAuditSellerProspects();}catch(e){alert(e.error||JSON.stringify(e))}}
async function releaseAllSellerOpen(){const sellerId=document.getElementById('auditSellerSelect').value;if(!sellerId)return alert('Elegí vendedor');const c=prompt('Libera todos los pendientes abiertos de este vendedor. Para confirmar escribí LIBERAR');if(c!=='LIBERAR')return;try{const j=await api('/api/admin/release-all-seller-open?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sellerId,limit:500,confirm:'LIBERAR'})});alert('Liberados: '+j.released);await loadAuditSellerProspects();}catch(e){alert(e.error||JSON.stringify(e))}}

async function loadAuditContacts(){
  const mode=document.getElementById('auditContactMode').value;
  const q=document.getElementById('auditContactQ').value;
  const limit=document.getElementById('auditContactLimit').value || 20;
  const box=document.getElementById('auditContactsBox');
  box.innerHTML='<p class="muted">Cargando contactos...</p>';
  try{
    const j=await api('/api/admin/audit/contacts?user='+encodeURIComponent(user())+'&mode='+encodeURIComponent(mode)+'&q='+encodeURIComponent(q)+'&limit='+encodeURIComponent(limit));
    let h='<p><b>Total:</b> '+j.counts.all+' | <b>Con match:</b> '+j.counts.matched+' | <b>Sin match:</b> '+j.counts.unmatched+' | Mostrando: '+j.rows.length+'</p>';
    if(!j.rows.length){box.innerHTML=h+'<p class="muted">Sin resultados.</p>';return}
    h+='<table><thead><tr><th>Estado</th><th>Importador</th><th>Contacto</th><th>Ubicación</th><th>Carga</th><th>Acciones</th></tr></thead><tbody>';
    for(const x of j.rows){h+='<tr><td><span class="pill">'+esc(x.matchStatus)+'</span></td><td><b>'+esc(x.companyName||'')+'</b><br><span class="muted small">'+esc(x.normalizedName||'')+'</span></td><td>'+esc(x.phone||'')+'<br>'+esc(x.email||'')+'<br>'+esc(x.website||'')+'</td><td>'+esc([x.city,x.province].filter(Boolean).join(', '))+'<br>'+esc(x.address||'')+'</td><td>'+esc(x.sourceFile||'')+'<br><span class="muted small">'+esc(x.sourceJobId||'')+'</span></td><td><button class="bad" data-id="'+esc(x.id)+'" onclick="deleteAuditContact(this.dataset.id)">Borrar contacto</button></td></tr>'}
    h+='</tbody></table>'; box.innerHTML=h;
  }catch(e){box.innerHTML='<div class="msg">ERROR: '+esc(e.error||e.message||JSON.stringify(e))+'</div>'}
}
async function loadAuditCustoms(){
  const mode=document.getElementById('auditCustomsMode').value;
  const q=document.getElementById('auditCustomsQ').value;
  const limit=document.getElementById('auditCustomsLimit').value || 20;
  const box=document.getElementById('auditCustomsBox');
  box.innerHTML='<p class="muted">Cargando aduana...</p>';
  try{
    const j=await api('/api/admin/audit/customs?user='+encodeURIComponent(user())+'&mode='+encodeURIComponent(mode)+'&q='+encodeURIComponent(q)+'&limit='+encodeURIComponent(limit));
    let h='<p><b>Total:</b> '+j.counts.all+' | <b>Con match:</b> '+j.counts.matched+' | <b>Sin match:</b> '+j.counts.unmatched+' | Mostrando: '+j.rows.length+'</p>';
    if(!j.rows.length){box.innerHTML=h+'<p class="muted">Sin resultados.</p>';return}
    h+='<table><thead><tr><th>Estado</th><th>Importador aduana</th><th>Resumen</th><th>Origen/NCM</th><th>Carga</th><th>Acciones</th></tr></thead><tbody>';
    for(const x of j.rows){h+='<tr><td><span class="pill">'+esc(x.matchStatus)+'</span></td><td><b>'+esc(x.importador||'')+'</b><br><span class="muted small">'+esc(x.normalizedName||'')+'</span></td><td>Items: '+esc(x.summary?.importCount||0)+'<br>FOB: '+money(x.summary?.totalFob||0)+'<br>'+esc((x.summary?.descriptionsPreview||[]).slice(0,2).join(' | '))+'</td><td>NCM: '+esc((x.summary?.chapters||[]).join(', '))+'<br>Origen: '+esc((x.summary?.origins||[]).join(', '))+'</td><td>'+esc(x.sourceFile||'')+'<br><span class="muted small">'+esc(x.sourceJobId||'')+'</span></td><td><button data-id="'+esc(x.id)+'" onclick="loadAuditCustomsItems(this.dataset.id)">Ver ítems</button> <button class="bad" data-id="'+esc(x.id)+'" onclick="deleteAuditCustoms(this.dataset.id)">Borrar aduana</button></td></tr>'}
    h+='</tbody></table>'; box.innerHTML=h;
  }catch(e){box.innerHTML='<div class="msg">ERROR: '+esc(e.error||e.message||JSON.stringify(e))+'</div>'}
}

async function loadAuditCustomsItems(id){
  const box=document.getElementById('auditCustomsItemsBox');
  if(!box)return;
  box.classList.remove('hidden');
  box.innerHTML='Cargando ítems aduaneros...';
  try{
    const j=await api('/api/admin/audit/customs-items?user='+encodeURIComponent(user())+'&customsGroupId='+encodeURIComponent(id)+'&limit=500');
    const g=j.group||{};
    let h='<div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><div><b>Ítems de '+esc(g.importador||g.id||id)+'</b><br><span class="muted small">Mostrando '+esc(j.items.length)+' ítems. Grupo: '+esc(id)+'</span></div><button class="secondary" onclick="document.getElementById(\'auditCustomsItemsBox\').classList.add(\'hidden\')">Cerrar</button></div>';
    if(!j.items.length){box.innerHTML=h+'<p class="muted">No hay ítems para este importador.</p>';return}
    h+='<div style="max-height:420px;overflow:auto;margin-top:10px"><table><thead><tr><th>Fecha</th><th>Aduana</th><th>Destinación</th><th>Posición</th><th>Item</th><th>Descripción</th><th>FOB</th><th>Cantidad</th><th>Origen</th><th>Procedencia</th><th>Carga</th></tr></thead><tbody>';
    for(const it of j.items){
      h+='<tr><td>'+esc(it.fecha||'')+'</td><td>'+esc(it.aduana||'')+'</td><td>'+esc(it.destinacion||'')+'</td><td><b>'+esc(it.posicion||'')+'</b></td><td>'+esc(it.item||'')+'</td><td>'+esc(it.descripcion||'')+'</td><td>'+money(it.fob||0)+'</td><td>'+esc(it.cantidad||'')+'</td><td>'+esc(it.origen||'')+'</td><td>'+esc(it.procedencia||'')+'</td><td><span class="muted small">'+esc(it.sourceFile||'')+'</span></td></tr>';
    }
    h+='</tbody></table></div>';
    box.innerHTML=h;
  }catch(e){box.innerHTML='<div class="msg">ERROR: '+esc(e.error||e.message||JSON.stringify(e))+'</div>'}
}

async function deleteAuditContact(id){const c=prompt('Para borrar este contacto y su prospecto, escribí BORRAR'); if(c!=='BORRAR') return alert('Cancelado'); try{const j=await api('/api/admin/delete-contact?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,confirm:'BORRAR'})});alert('Borrado');await loadAuditContacts();}catch(e){alert(e.error||JSON.stringify(e))}}
async function deleteAuditCustoms(id){const c=prompt('Para borrar este grupo aduanero, sus ítems y su prospecto, escribí BORRAR'); if(c!=='BORRAR') return alert('Cancelado'); try{const j=await api('/api/admin/delete-customs-group?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,confirm:'BORRAR'})});alert('Borrado');await loadAuditCustoms();}catch(e){alert(e.error||JSON.stringify(e))}}

async function loadAdminJobs(){
  const msg=document.getElementById('adminMsg'); if(msg){msg.classList.add('hidden')}
  try{
    const j=await api('/api/admin/jobs?user='+encodeURIComponent(user()));
    let h='<table><thead><tr><th>Fecha</th><th>Tipo</th><th>Archivo</th><th>Filas</th><th>Válidas</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>';
    for(const x of j.jobs){
      let prog='';
      if(x.type==='customs_upload_async') prog='<br><span class="muted small">Procesadas: '+esc(x.processedRows||0)+' / '+esc(x.rows||0)+' | Chunks: '+esc(x.chunksDone||0)+' / '+esc(x.chunkCount||0)+'</span>';
      if(x.type==='match_reprocess_async') prog='<br><span class="muted small">Match: Aduana '+esc(x.processedCustoms||0)+' / '+esc(x.customsTotal||0)+' | Contactos '+esc(x.processedContacts||0)+' / '+esc(x.contactsTotal||0)+' | M: '+esc(x.matched||0)+' | S/M: '+esc(x.unmatched||0)+'</span>';
      const delProg=x.deleteStatus==='processing'?('<br><span class="muted small">Borrando: '+esc(x.deleteProgress?.percent||0)+'% | Ítems: '+esc(x.deleteProgress?.customsItems||0)+' | Contactos: '+esc(x.deleteProgress?.contacts||0)+'</span>'):'';
      const status=x.deleted?'BORRADA':(x.deleteStatus==='processing'?'borrando...':(x.status||'Activa'));
      const jobComplete=(x.type==='customs_upload_async' && (Number(x.processedRows||0)>=Number(x.rows||0) || Number(x.chunksDone||0)>=Number(x.chunkCount||0)));
      let extraAction='';
      if(x.type==='customs_upload_async'&&x.status!=='done') extraAction='<button class="ok" data-id="'+esc(x.id)+'" onclick="continueJob(this.dataset.id)">'+(jobComplete?'Finalizar':'Continuar')+'</button>';
      if(x.type==='match_reprocess_async'&&x.status!=='done') extraAction='<button class="ok" data-id="'+esc(x.id)+'" onclick="reprocessMatchLoop(this.dataset.id)">Continuar match</button>';
      const actions=x.deleted?'-':('<button class="bad" data-id="'+esc(x.id)+'" onclick="deleteJob(this.dataset.id)">Borrar carga</button> '+extraAction);
      h+='<tr><td>'+esc((x.createdAt||'').slice(0,19).replace('T',' '))+'</td><td>'+esc(x.type||'')+'</td><td>'+esc(x.filename||'')+'<br><span class="muted small">'+esc(x.id||'')+'</span>'+prog+delProg+'</td><td>'+esc(x.rows||0)+'</td><td>'+esc(x.valid||0)+'</td><td>'+esc(status)+'</td><td>'+actions+'</td></tr>';
    }
    h+='</tbody></table>';
    document.getElementById('adminJobs').innerHTML=h;
  }catch(e){showAdminMsg('ERROR: '+(e.error||e.message||JSON.stringify(e)))}
}
function showAdminMsg(t){const m=document.getElementById('adminMsg');m.classList.remove('hidden');m.textContent=t;}
async function deleteJob(jobId){
  const c=prompt('Para borrar esta carga escribí BORRAR');
  if(c!=='BORRAR') return alert('Cancelado');
  showAdminMsg('Iniciando borrado de carga '+jobId+'...');
  await deleteJobLoop(jobId, c);
}
async function deleteJobLoop(jobId, confirmText){
  let done=false;
  let last=null;
  for(let i=0;i<120 && !done;i++){
    try{
      const j=await api('/api/admin/delete-job-step?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jobId,confirm:confirmText,maxDocs:250})});
      last=j;
      const p=j.progress||{};
      const pct=(j.percent!=null?j.percent:(p.percent||0));
      showAdminMsg('Borrando carga... '+pct+'%\n'+
        'Job: '+jobId+'\n'+
        'Contactos borrados: '+(p.contacts||0)+' | Prospectos: '+(p.prospects||0)+' | Notas: '+(p.notes||0)+'\n'+
        'Ítems aduaneros borrados: '+(p.customsItems||0)+' | Grupos borrados: '+(p.customsGroupsDeleted||0)+' | Grupos recalculados: '+(p.customsGroupsRecomputed||0)+'\n'+
        'Filas temporales borradas: '+(p.jobRowsDeleted||0)+'\n'+
        'Estado: '+(j.done?'done':'processing')+'\n'+
        (j.message||''));
      done=!!j.done;
      if(!done) await new Promise(r=>setTimeout(r,350));
    }catch(e){
      showAdminMsg('ERROR borrando carga: '+(e.error||e.message||JSON.stringify(e))+'\nPodés tocar Borrar carga otra vez para continuar.');
      return;
    }
  }
  await loadAdminJobs();
  if(done) showAdminMsg('Borrado terminado.\n'+JSON.stringify(last.progress||last,null,2));
  else showAdminMsg('Borrado pausado para evitar timeout. Tocá Borrar carga otra vez para continuar.\n'+JSON.stringify(last&&last.progress?last.progress:last,null,2));
}
async function adminRelease(id){
  if(!confirm('¿Liberar este prospecto para que vuelva a Disponible?')) return;
  try{const j=await api('/api/admin/release-prospect?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prospectId:id})});alert('Liberado');await openDetail(id);}catch(e){alert(e.error||JSON.stringify(e))}
}
async function adminDeleteProspect(id){
  const mode=prompt('Tipo de borrado:\nprospect_only = solo prospecto/gestiones\ncontact_only = prospecto + contacto\ncontact_and_customs = prospecto + contacto + aduana', 'prospect_only');
  if(!mode) return;
  const c=prompt('Para confirmar escribí BORRAR');
  if(c!=='BORRAR') return alert('Cancelado');
  try{const j=await api('/api/admin/delete-prospect?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prospectId:id,mode,confirm:'BORRAR'})});alert('Borrado: '+JSON.stringify(j.deleted));document.getElementById('detailBox').classList.add('hidden');}catch(e){alert(e.error||JSON.stringify(e))}
}
async function deleteAllData(){
  const c=prompt('PELIGRO. Borra TODO SCB Hunter Campo. Para confirmar escribí BORRAR TODO');
  if(c!=='BORRAR TODO') return alert('Cancelado');
  try{const j=await api('/api/admin/delete-all?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:'BORRAR TODO'})});showAdminMsg(JSON.stringify(j,null,2));await loadAdminJobs();}catch(e){showAdminMsg('ERROR: '+(e.error||e.message||JSON.stringify(e)))}
}
async function reprocessMatch(){
  const c=prompt('Reprocesar match por job. Para confirmar escribí MATCH');
  if(c!=='MATCH') return alert('Cancelado');
  showAdminMsg('Creando job de reproceso de match...');
  try{
    const j=await api('/api/admin/reprocess-match?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:'MATCH'})});
    await reprocessMatchLoop(j.jobId);
  }catch(e){showAdminMsg('ERROR: '+(e.error||e.message||JSON.stringify(e)))}
}
async function reprocessMatchLoop(jobId){
  let done=false,last=null;
  for(let i=0;i<200 && !done;i++){
    try{
      const j=await api('/api/admin/reprocess-match-step?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jobId,maxDocs:100})});
      last=j; const job=j.job||{};
      const total=(Number(job.contactsTotal||0)+Number(job.customsTotal||0))||Number(job.rows||0)||0;
      const doneRows=Number(job.processedContacts||0)+Number(job.processedCustoms||0);
      const pct=total?Math.min(100,Math.round((doneRows/total)*100)):0;
      showAdminMsg('Reprocesando match... '+pct+'%\n'+
        'Etapa: '+(job.stage||'')+' | Estado: '+(job.status||'')+'\n'+
        'Aduana revisada: '+(job.processedCustoms||0)+' / '+(job.customsTotal||0)+'\n'+
        'Contactos revisados: '+(job.processedContacts||0)+' / '+(job.contactsTotal||0)+'\n'+
        'Macheados: '+(job.matched||0)+' | Sin match: '+(job.unmatched||0)+'\n'+
        'Job: '+jobId);
      done=!!j.done;
      if(!done) await new Promise(r=>setTimeout(r,250));
    }catch(e){
      showAdminMsg('ERROR reprocesando match: '+(e.error||e.message||JSON.stringify(e))+'\nPodés continuar desde Historial si quedó el job.');
      await loadAdminJobs();
      return;
    }
  }
  await loadAdminJobs();
  if(done) showAdminMsg('Reprocesar match terminado.\n'+JSON.stringify(last&&last.job?last.job:last,null,2));
  else showAdminMsg('Reproceso pausado para evitar timeout. Tocá Continuar match en Historial.');
}
async function rebuildIndexes(){
  try{const j=await api('/api/admin/rebuild-indexes?user='+encodeURIComponent(user()),{method:'POST'});showAdminMsg(JSON.stringify(j,null,2));}
  catch(e){showAdminMsg('ERROR: '+(e.error||e.message||JSON.stringify(e)))}
}

let lastPurgeFileBase64='';
let lastPurgeFilename='purgado.xlsx';
function downloadLastPurge(){ if(!lastPurgeFileBase64)return alert('No hay archivo generado'); downloadBase64File(lastPurgeFileBase64,lastPurgeFilename,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); }
function downloadBase64File(base64, filename, mime){
  const bin=atob(base64); const len=bin.length; const bytes=new Uint8Array(len);
  for(let i=0;i<len;i++)bytes[i]=bin.charCodeAt(i);
  const blob=new Blob([bytes],{type:mime||'application/octet-stream'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=filename||'archivo.xlsx'; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1000);
}
function renderPurgePreview(title, rows){
  if(!rows||!rows.length)return '<h4>'+esc(title)+'</h4><p class="muted">Sin filas.</p>';
  let h='<h4>'+esc(title)+' <span class="muted small">preview '+rows.length+'</span></h4><div style="overflow:auto;max-height:360px"><table><thead><tr><th>Estado</th><th>Fila</th><th>Importador</th><th>Existe como</th><th>Fuente</th><th>Solo aduana</th></tr></thead><tbody>';
  for(const r of rows){h+='<tr><td><span class="pill">'+esc(r.PurgadorEstado||'')+'</span></td><td>'+esc(r.PurgadorFila||'')+'</td><td><b>'+esc(r.PurgadorImportador||r.Importador||r.Empresa||'')+'</b><br><span class="muted small">'+esc(r.PurgadorMatchKey||'')+'</span></td><td>'+esc(r.PurgadorNombreExistente||r.PurgadorNombreAduana||'')+'</td><td>'+esc(r.PurgadorFuente||'')+'</td><td>'+esc(r.PurgadorSoloAduanaExistente||'')+'</td></tr>'}
  return h+'</tbody></table></div>';
}
async function runImporterPurge(){
  const el=document.getElementById('purgeFile');
  const msg=document.getElementById('purgeMsg');
  const out=document.getElementById('purgeResult');
  if(!el||!el.files[0]) return alert('Elegí el Excel de importadores a purgar');
  msg.classList.remove('hidden'); msg.textContent='Leyendo Excel y comparando contra la base...'; if(out)out.innerHTML='';
  try{
    const file=el.files[0];
    const dataBase64=await fileToBase64(file);
    const j=await api('/api/admin/importer-purge?user='+encodeURIComponent(user()),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:file.name,dataBase64})});
    const c=j.counts||{};
    msg.textContent='PURGADOR TERMINADO\n'+
      'Filas leídas: '+(c.rows||0)+'\n'+
      'Nuevos para Google: '+(c.nuevosParaGoogle||0)+'\n'+
      'Ya existen, NO buscar: '+(c.yaExistenNoBuscar||0)+'\n'+
      'Duplicados dentro del Excel: '+(c.duplicadosEnExcel||0)+'\n'+
      'Sin importador: '+(c.sinImportador||0)+'\n'+
      'Nuevos que ya estaban solo en aduana: '+(c.nuevosQueYaTenianSoloAduana||0)+'\n\n'+
      (j.note||'');
    if(out){
      lastPurgeFileBase64=j.fileBase64||''; lastPurgeFilename=j.outputFilename||'purgado.xlsx';
      out.innerHTML='<div class="card"><button class="ok" onclick="downloadLastPurge()">Descargar Excel purgado</button> <span class="muted small">Usá la hoja NUEVOS_PARA_GOOGLE para cargar en Google API.</span></div>'+renderPurgePreview('Nuevos para Google',j.preview?.nuevos||[])+renderPurgePreview('Ya existen - no buscar',j.preview?.yaExisten||[])+renderPurgePreview('Duplicados en el Excel',j.preview?.duplicadosExcel||[]);
    }
  }catch(e){msg.textContent='ERROR: '+(e.error||e.message||JSON.stringify(e,null,2))}
}

function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
setTimeout(()=>{try{applyRoleUI();}catch(e){console.warn(e)}},0);
`;

function html() {
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${APP_NAME}</title>
<style>
:root{--b:#0f172a;--a:#075985;--g:#f1f5f9;--l:#e2e8f0;--ok:#166534;--bad:#991b1b}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;margin:0;background:#f8fafc;color:#111827}.top{background:var(--b);color:white;padding:16px 24px;display:flex;justify-content:space-between;gap:12px;align-items:center}.top h1{font-size:20px;margin:0}.wrap{padding:20px;max-width:1280px;margin:auto}.card{background:white;border:1px solid var(--l);border-radius:12px;padding:16px;margin-bottom:16px;box-shadow:0 1px 2px #0001}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:12px}.col6{grid-column:span 6}.col4{grid-column:span 4}.col3{grid-column:span 3}.col12{grid-column:span 12}input,select,textarea,button{font:inherit}input,select,textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px}button{border:0;background:var(--a);color:white;border-radius:8px;padding:10px 14px;cursor:pointer}button.secondary{background:#334155}button.bad{background:var(--bad)}button.ok{background:var(--ok)}table{width:100%;border-collapse:collapse;background:white}th,td{padding:9px;border-bottom:1px solid var(--l);text-align:left;vertical-align:top;font-size:13px}th{background:var(--g)}.pill{display:inline-block;border-radius:999px;padding:3px 8px;background:#e0f2fe;color:#075985;font-size:12px}.muted{color:#64748b}.row-actions{display:flex;gap:6px;flex-wrap:wrap}.tabs button{background:#e2e8f0;color:#0f172a}.tabs button.active{background:var(--a);color:white}.hidden{display:none!important}.msg{white-space:pre-wrap;padding:10px;border-radius:8px;background:#eef2ff;margin:8px 0}.money{font-weight:bold}.small{font-size:12px}.kpi{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px}.loginScreen{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;background:linear-gradient(180deg,#f8fafc,#e2e8f0)}.loginCard{width:100%;max-width:430px;background:white;border:1px solid #e2e8f0;border-radius:18px;padding:30px;box-shadow:0 18px 45px #0f172a22;text-align:center}.loginLogo{max-width:310px;width:100%;height:auto;margin:0 auto 18px;display:block}.loginTitle{font-size:24px;font-weight:800;margin:0 0 6px;color:#0f172a}.loginSub{margin:0 0 22px;color:#64748b}.loginCard input{margin-bottom:12px;text-align:center}.loginCard button{width:100%;font-weight:700}.topRight{display:flex;gap:10px;align-items:center}.topRight button{background:#334155}#mineList{max-height:70vh;overflow-y:auto;overflow-x:auto;padding-right:4px}#mineList table thead th{position:sticky;top:0;z-index:2} @media(max-width:800px){.col6,.col4,.col3{grid-column:span 12}.top{display:block}.topRight{margin-top:10px}}
</style></head><body>
<div id="loginScreen" class="loginScreen"><div class="loginCard"><img class="loginLogo" src="${LOGO_DATA_URL}" alt="Sentire Customs Broker"><h1 class="loginTitle">SCB Hunter Campo</h1><p class="loginSub">Ingresá con tu usuario y clave</p><input id="user" placeholder="Usuario"><input id="userPass" placeholder="Clave" type="password" onkeydown="if(event.key==='Enter')saveUser()"><button onclick="saveUser()">Entrar</button></div></div>
<div id="appTop" class="top hidden"><h1>🎯 ${APP_NAME}</h1><div class="topRight"><span class="muted" style="color:#cbd5e1">Usuario: <b id="loggedUserName"></b></span><button onclick="logoutHunter()">Salir</button></div></div>
<div id="appWrap" class="wrap hidden">
<div class="card"><div class="tabs"><button id="tabPanel" class="active adminOnly" onclick="tab('panel',this)">Panel</button> <button class="adminOnly" onclick="tab('importar',this)">Importar Excel</button> <button class="adminOnly" onclick="tab('purgador',this)">Purgador</button> <button class="adminOnly" onclick="openAvailable(this)">Disponibles</button> <button id="tabMios" onclick="tab('mios',this);loadProspects('mine')">Mis prospectos</button> <button id="tabTareas" onclick="tab('tareas',this);loadTasks()">Mis tareas</button> <button class="adminOnly" onclick="tab('dashboard',this);loadStats()">Dashboard</button> <button class="adminOnly" onclick="openDailyReport(this)">Reporte diario</button> <button id="tabVendedores" class="adminOnly" onclick="loadSellerAdmin()">Vendedores</button> <button class="adminOnly" onclick="tab('auditoria',this);loadSellers().then(renderAuditSellerSelect);loadAuditContacts();loadAuditCustoms()">Auditoría</button> <button class="adminOnly" onclick="tab('admin',this);loadAdminJobs()">Admin / Borrado</button></div></div>
<section id="panel" class="view"><div class="card"><h2>Banco de prospectos importadores</h2><p>Subís un Excel de contacto y otro Excel aduanero. El match se hace por <b>nombre normalizado</b>. El vendedor toma empresas de a 10 y no puede tomar más hasta cargar nota y resultado.</p><div class="grid"><div class="col4 kpi"><b>1 empresa = 1 prospecto</b><br><span class="muted">Puede tener muchos ítems aduaneros.</span></div><div class="col4 kpi"><b>Match por nombre</b><br><span class="muted">Guarda score y nombres originales.</span></div><div class="col4 kpi"><b>Bloqueo comercial</b><br><span class="muted">Sin nota/resultado no libera otro lote.</span></div></div></div></section>
<section id="importar" class="view hidden"><div class="grid"><div class="col6 card"><h3>1) Excel de contacto</h3><p class="muted">Columnas: Importador, Telefono, Direccion, EstadoBusqueda, GoogleMaps, Web, Rating, Ciudad, Provincia.</p><input type="file" id="contactFile" accept=".xlsx,.xls,.csv"><br><br><button onclick="uploadFile('contact')">Subir contactos</button></div><div class="col6 card"><h3>2) Excel aduanero</h3><p class="muted">Columnas: Importador, Fecha, Aduana, Descripción, Destinación, Posición, Item, Procedencia, Origen, FOB, SUM de Cantidad, SUM de FOB.</p><input type="file" id="customsFile" accept=".xlsx,.xls,.csv"><br><br><button onclick="uploadFile('customs')">Subir aduana</button></div><div class="col12"><div id="importMsg" class="msg hidden"></div></div></div></section>
<section id="purgador" class="view hidden"><div class="card"><h3>Purgador de importadores</h3><p class="muted">Subí el Excel nuevo antes de gastar Google APIs. El sistema compara por nombre normalizado contra contactos/prospectos ya cargados y te devuelve un Excel separado.</p><div class="grid"><div class="col6"><input type="file" id="purgeFile" accept=".xlsx,.xls,.csv"></div><div class="col3"><button class="ok" onclick="runImporterPurge()">Purgar importadores</button></div></div><div id="purgeMsg" class="msg hidden"></div></div><div id="purgeResult"></div></section>
<section id="disponibles" class="view hidden"><div class="card"><h3>Filtros para tomar prospectos</h3><p class="muted small">Filtrá por zona/NCM/origen y mirá disponibles/asignados. Para asignar, seleccioná solo los que estén disponibles.</p><div class="grid"><div class="col3"><select id="fStatus" onchange="refreshAvailableCount()"><option value="available">Solo disponibles</option><option value="assigned">Solo asignados/en gestión</option><option value="all">Todos</option></select></div><div class="col3"><select id="fProvince" onchange="updateCityOptions();refreshAvailableCount()"><option value="">Todas las provincias</option></select></div><div class="col3"><select id="fCity" onchange="refreshAvailableCount()"><option value="">Todas las ciudades</option></select></div><div class="col3"><select id="fChapter" onchange="refreshAvailableCount()"><option value="">Todos los capítulos</option></select></div><div class="col3"><select id="fOrigin" onchange="refreshAvailableCount()"><option value="">Todos los orígenes</option></select></div><div class="col6"><input id="fDesc" placeholder="Descripción contiene ej: maquinaria"></div><div class="col3"><select id="fFobRange" onchange="refreshAvailableCount()"><option value="">Todos los FOB</option></select></div><div class="col3"><select id="fOrder" onchange="loadProspects('available')"><option value="mix">Mix letras + FOB</option><option value="alpha">Alfabético</option><option value="fob_desc">FOB mayor primero</option><option value="fob_asc">FOB menor primero</option></select></div><div class="col3"><button class="secondary" onclick="loadProspects('available')">Buscar</button> <button class="ok" onclick="takeBatch()">Tomar 10</button></div></div><p><b id="availableCount">Total con filtros: -</b></p></div><div class="card"><h4>Asignación manual rápida</h4><div class="grid"><div class="col3"><select id="assignSeller"><option value="">Elegir vendedor</option></select></div><div class="col2"><input id="assignLimit" value="200" placeholder="Máx. asignar"></div><div class="col7 row-actions"><button onclick="assignSelected()">Asignar seleccionados</button><button class="secondary" onclick="toggleSelectAllVisible(true)">Seleccionar visibles</button><button class="secondary" onclick="clearSelected()">Limpiar selección</button><button class="ok" onclick="assignFiltered()">Asignar todos filtrados</button></div></div><p class="muted small" id="selectedInfo">Seleccionados visibles/manuales: 0</p></div><div class="card"><div id="availableList"></div></div></section>
<section id="mios" class="view hidden"><div class="card"><h3>Mis prospectos asignados</h3><p class="muted">Acá el vendedor trabaja su cartera. Los filtros ayudan a ver rápido qué tiene pendiente, vencido, para hoy o interesado.</p><div class="grid"><div class="col3"><select id="mineStatus" onchange="loadProspects('mine')"><option value="all">Todos</option><option value="sin_gestion">Sin gestión</option><option value="vencidos">Seguimientos vencidos</option><option value="hoy">Seguimientos de hoy</option><option value="proximas">Seguimientos próximos</option><option value="seguimiento">En seguimiento</option><option value="interesados">Interesados / contactados</option><option value="no_responde">No responde</option><option value="cotizacion">Cotización solicitada</option><option value="descartados">Descartados / cerrados</option><option value="gestionados">Gestionados</option></select></div><div class="col4"><input id="mineQ" placeholder="Buscar empresa, ciudad, provincia, NCM" onkeydown="if(event.key==='Enter')loadProspects('mine')"></div><div class="col5 row-actions"><button class="secondary" onclick="loadProspects('mine')">Filtrar</button><button class="ok" onclick="pedirMas()">Pedir 10 más</button><button class="secondary" onclick="tab('tareas',document.getElementById('tabTareas'));loadTasks()">Ver mis tareas</button></div></div><div class="row-actions" style="margin-top:10px"><button class="secondary" onclick="quickMine('sin_gestion')">Sin gestión</button><button class="secondary" onclick="quickMine('vencidos')">Vencidos</button><button class="secondary" onclick="quickMine('hoy')">Hoy</button><button class="secondary" onclick="quickMine('interesados')">Interesados</button><button class="secondary" onclick="quickMine('no_responde')">No responde</button><button class="secondary" onclick="quickMine('all')">Todos</button></div><div id="mineSummary" class="msg"></div></div><div class="card"><div id="mineList"></div></div></section>
<section id="tareas" class="view hidden"><div class="card"><h3>Mis tareas</h3><p class="muted">Agenda de seguimientos: mandar email, volver a llamar, pedir datos o enviar cotización.</p><div class="grid"><div class="col3"><select id="taskMode"><option value="open">Abiertas</option><option value="overdue">Vencidas</option><option value="today">Hoy</option><option value="upcoming">Próximas</option><option value="completed">Completadas</option><option value="all">Todas</option></select></div><div class="col4"><input id="taskQ" placeholder="Buscar empresa / tarea / ciudad"></div><div class="col2"><input id="taskLimit" value="100" placeholder="Límite"></div><div class="col3"><button onclick="loadTasks()">Actualizar tareas</button></div></div><div id="tasksSummary" class="msg"></div></div><div class="card"><div id="tasksList"></div></div></section>
<section id="dashboard" class="view hidden"><div class="card"><h3>Dashboard</h3><button onclick="location.href='/api/export.csv?user='+encodeURIComponent(user())">Exportar CSV</button><div id="stats"></div></div></section>
<section id="vendedores" class="view hidden"><div class="card"><h3>Vendedores</h3><p class="muted">Alta y edición manual rápida de vendedores para asignar prospectos.</p><div id="sellersBox"></div></div></section>
<section id="reporte" class="view hidden"><div class="card"><h3>Reporte comercial</h3><p class="muted">Control por vendedor: gestiones cargadas, resultados, tareas creadas/completadas y tareas vencidas. Podés verlo por día, semana, mes, histórico o rango personalizado.</p><div class="grid"><div class="col2"><label>Período</label><select id="reportPeriod" onchange="updateReportPeriodUI()"><option value="day">Día</option><option value="week">Semana</option><option value="month">Mes</option><option value="history">Histórico</option><option value="custom">Personalizado</option></select></div><div class="col2 reportDateOne"><label>Fecha base</label><input type="date" id="reportDate"></div><div class="col2 reportCustom hidden"><label>Desde</label><input type="date" id="reportFrom"></div><div class="col2 reportCustom hidden"><label>Hasta</label><input type="date" id="reportTo"></div><div class="col3"><label>Vendedor</label><select id="reportSeller"><option value="all">Todos los vendedores</option></select></div><div class="col2"><label>Límite detalle</label><input id="reportLimit" value="1500" placeholder="Límite gestiones"></div><div class="col1"><label>&nbsp;</label><button onclick="loadDailyReport()">Ver</button></div></div><div class="row-actions"><button class="secondary" onclick="setReportPeriodQuick('day')">Día</button><button class="secondary" onclick="setReportPeriodQuick('week')">Semana</button><button class="secondary" onclick="setReportPeriodQuick('month')">Mes</button><button class="secondary" onclick="setReportPeriodQuick('history')">Histórico</button><button class="secondary" onclick="setReportPeriodQuick('custom')">Personalizado</button></div><div id="reportSummary" class="msg"></div></div><div class="grid"><div class="col12 card"><h4>Resumen por vendedor</h4><div id="reportSellersBox"></div></div><div class="col12 card"><h4>Detalle de gestiones</h4><div id="reportDetailBox"></div></div></div></section>
<section id="auditoria" class="view hidden"><div class="card"><h3>Auditoría de cargas</h3><p class="muted">Acá ves contactos, aduana y asignaciones por vendedor para detectar errores o liberar prospectos.</p><div class="grid"><div class="col12 card"><h4>Vendedor / asignaciones</h4><div class="grid"><div class="col3"><select id="auditSellerSelect"></select></div><div class="col3"><select id="auditSellerStatus"><option value="open">Pendientes abiertos</option><option value="all">Todos</option><option value="assigned">Asignados sin gestión</option><option value="in_progress">En gestión</option><option value="completed">Terminados/descartados</option></select></div><div class="col3"><input id="auditSellerQ" placeholder="Buscar empresa / ciudad / NCM"></div><div class="col2"><input id="auditSellerLimit" value="20" placeholder="Límite"></div><div class="col12"><button onclick="loadAuditSellerProspects()">Ver vendedor</button> <button onclick="selectAuditSellerVisible()">Seleccionar visibles</button> <button onclick="clearAuditSellerSelection()">Limpiar</button> <button class="bad" onclick="releaseAuditSellerSelected()">Liberar seleccionados</button> <button class="bad" onclick="releaseAllSellerOpen()">Liberar todos pendientes</button></div></div><div id="auditSellerBox"></div></div><div class="col6 card"><h4>Contactos cargados</h4><div class="grid"><div class="col4"><select id="auditContactMode"><option value="all">Todos</option><option value="matched">Con match</option><option value="unmatched">Sin match</option></select></div><div class="col4"><input id="auditContactQ" placeholder="Buscar importador / ciudad"></div><div class="col3"><input id="auditContactLimit" value="20" placeholder="Límite"></div><div class="col12"><button onclick="loadAuditContacts()">Ver contactos</button></div></div><div id="auditContactsBox"></div></div><div class="col6 card"><h4>Aduana cargada</h4><div class="grid"><div class="col4"><select id="auditCustomsMode"><option value="all">Todos</option><option value="matched">Con match</option><option value="unmatched">Sin match</option></select></div><div class="col4"><input id="auditCustomsQ" placeholder="Buscar importador / NCM / origen"></div><div class="col3"><input id="auditCustomsLimit" value="20" placeholder="Límite"></div><div class="col12"><button onclick="loadAuditCustoms()">Ver aduana</button></div></div><div id="auditCustomsBox"></div><div id="auditCustomsItemsBox" class="msg hidden"></div></div></div></div></section>
<section id="admin" class="view hidden"><div class="card"><h3>Admin / Borrado</h3><p class="muted">Solo admin. Para borrar, escribí BORRAR o BORRAR TODO cuando corresponda.</p><div class="row-actions"><button onclick="loadAdminJobs()">Refrescar historial</button><button class="secondary" onclick="reprocessMatch()">Reprocesar match</button><button class="secondary" onclick="rebuildIndexes()">Reconstruir índices filtros</button><button class="bad" onclick="deleteAllData()">Borrar TODO</button></div><div id="adminMsg" class="msg hidden"></div><h4>Historial de cargas</h4><div id="adminJobs"></div></div></section>
<div id="detailBox" class="card hidden"></div>
</div><script src="/client.js?v=6"></script></body></html>`;
}
async function route(req, res) {
  if (!requireBasic(req, res)) return;
  const path = (req.path || req.url.split('?')[0] || '/').replace(/\/$/, '') || '/';
  if (req.method === 'GET' && path === '/client.js') return res.status(200).set('Content-Type', 'application/javascript; charset=utf-8').send(CLIENT_JS);
  if (req.method === 'GET' && path === '/favicon.ico') return res.status(204).send('');
  if (req.method === 'GET' && path === '/') return res.status(200).set('Content-Type', 'text/html; charset=utf-8').send(html());
  if (req.method === 'GET' && path === '/health') return sendJson(res, { ok: true, service: APP_NAME, target: 'helloHttp', databaseId: FIRESTORE_DATABASE_ID, version: APP_VERSION, time: nowISO() });
  if (req.method === 'POST' && path === '/api/auth/login') return authLogin(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (path.startsWith('/api/') && !(await enforceAppAuth(req, res))) return;
  if (req.method === 'GET' && path === '/debug') return debugStatus(req, res).catch(e => { logEvent('error', 'debug_status_failed', { error: e.message, stack: e.stack }); return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500); });
  if (req.method === 'GET' && path === '/api/debug/status') return debugStatus(req, res).catch(e => { logEvent('error', 'debug_status_failed', { error: e.message, stack: e.stack }); return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500); });
  if (req.method === 'GET' && path === '/api/debug/jobs') return debugJobs(req, res).catch(e => { logEvent('error', 'debug_jobs_failed', { error: e.message, stack: e.stack }); return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500); });
  if (req.method === 'GET' && path === '/api/debug/match') return debugMatch(req, res).catch(e => { logEvent('error', 'debug_match_failed', { error: e.message, stack: e.stack }); return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500); });
  if (req.method === 'GET' && path === '/api/debug/samples') return debugSamples(req, res).catch(e => { logEvent('error', 'debug_samples_failed', { error: e.message, stack: e.stack }); return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500); });
  if (req.method === 'GET' && path === '/api/prospects') return listProspects(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/filter-options') return filterOptions(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/available-count') return availableCount(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/sellers') return listSellers(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/sellers/save') return saveSeller(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/sellers/delete') return deleteSeller(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/detail') return detail(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/stats') return stats(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/daily-report') return adminDailyReport(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/importer-purge') return adminImporterPurge(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/export.csv') return exportCsv(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/audit/contacts') return adminAuditContacts(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/audit/customs') return adminAuditCustoms(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/audit/customs-items') return adminAuditCustomsItems(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/audit/seller-prospects') return adminAuditSellerProspects(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/release-seller-prospects') return adminReleaseSellerProspects(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/release-all-seller-open') return adminReleaseAllSellerOpen(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-contact') return adminDeleteContact(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-customs-group') return adminDeleteCustomsGroup(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/admin/jobs') return adminJobs(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-job-step') return adminDeleteJobStep(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-job') return adminDeleteJob(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-prospect') return adminDeleteProspect(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/release-prospect') return adminReleaseProspect(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/reprocess-match') return adminReprocessMatch(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/reprocess-match-step') return processReprocessMatchJobStep((req.body && (req.body.id || req.body.jobId)) || req.query.id || req.query.jobId, currentUser(req), Math.min(Math.max(Number((req.body && req.body.maxDocs) || req.query.maxDocs || 100), 25), 250)).then(out => sendJson(res, { ok: true, ...out })).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/rebuild-indexes') return rebuildProspectIndexes(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/delete-all') return adminDeleteAll(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/assign-selected') return adminAssignSelected(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/admin/assign-filtered') return adminAssignFiltered(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/take-batch') return takeBatch(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/note') return saveNote(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/tasks') return listTasks(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/task/complete') return completeTask(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/task/reprogram') return reprogramTask(req, res).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'GET' && path === '/api/job/status') return getJobStatus(req.query.id || req.query.jobId).then(job => sendJson(res, { ok: true, job })).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/job/process') return processCustomsJobStep((req.body && (req.body.id || req.body.jobId)) || req.query.id || req.query.jobId, currentUser(req), Math.min(Math.max(Number((req.body && req.body.maxChunks) || req.query.maxChunks || 1), 1), 3)).then(out => sendJson(res, { ok: true, ...out })).catch(e => sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500));
  if (req.method === 'POST' && path === '/api/upload/contact') {
    try {
      const body = req.body || {};
      if (!body.dataBase64) return sendJson(res, { ok: false, error: 'Falta archivo base64' }, 400);
      const filename = body.filename || 'contactos.xlsx';
      const buffer = Buffer.from(String(body.dataBase64), 'base64');
      const r = await importContacts(buffer, filename, currentUser(req));
      return sendJson(res, { ok: true, ...r });
    } catch (e) {
      return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500);
    }
  }
  if (req.method === 'POST' && path === '/api/upload/customs') {
    try {
      const body = req.body || {};
      if (!body.dataBase64) return sendJson(res, { ok: false, error: 'Falta archivo base64' }, 400);
      const filename = body.filename || 'aduana.xlsx';
      const buffer = Buffer.from(String(body.dataBase64), 'base64');
      const u = currentUser(req);
      const rowsCountHint = Number(body.rowsCountHint || 0);
      const asyncMode = body.async === true || body.async === 'true' || rowsCountHint > Number(process.env.CUSTOMS_SYNC_MAX_ROWS || 1000);
      if (asyncMode) {
        const r = await prepareCustomsJob(buffer, filename, u);
        return sendJson(res, { ok: true, ...r });
      }
      const r = await importCustoms(buffer, filename, u);
      return sendJson(res, { ok: true, ...r });
    } catch (e) {
      return sendJson(res, { ok: false, error: e.message, stack: e.stack }, 500);
    }
  }
  return sendJson(res, { ok: false, error: 'Ruta no encontrada', path }, 404);
}

functions.http('helloHttp', route);